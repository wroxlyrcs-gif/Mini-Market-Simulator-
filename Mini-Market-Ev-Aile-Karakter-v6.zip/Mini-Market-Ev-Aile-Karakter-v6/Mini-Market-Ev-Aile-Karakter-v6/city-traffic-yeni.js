/* v3.3: perimeter roads and AI Traffic Collision Avoidance (AI-TCA) with predictive police gap acceptance. */
(function () {
  'use strict';
  const g=window.__mms;
  if(!g || !window.THREE || !window.MMS_VEH)return;
  const T=window.THREE,w=g.world,regions=__req('player').REGIONS;
  const surface=new T.Group();w.scene.add(surface);
  const box=(sx,sz,x,z,color,y=.03)=>{const mesh=w.b(sx,.055,sz,x,y,z,color,{parent:surface,cast:false});mesh.userData.static=true;return mesh;};
  // Outer loop lies outside the central buildings and the police station compound.
  box(243,10,32.5,-22,0x444a50);box(243,10,32.5,112,0x444a50);
  box(10,124,-84,45,0x444a50);box(10,124,149,45,0x444a50);
  box(9,6,-74.5,11.5,0x444a50);box(4,6,142,11.5,0x444a50);
  for(let x=-80;x<148;x+=8){box(2,.13,x,-22,0xf2f1e9,.09);if(x<30 || x>43)box(2,.13,x,112,0xf2f1e9,.09);}
  for(let z=-18;z<110;z+=8){box(.13,2,-84,z,0xf2f1e9,.09);box(.13,2,149,z,0xf2f1e9,.09);}
  w.mergeStatic(surface);
  regions.push({minX:-89,maxX:154,minZ:-27,maxZ:-17},{minX:-89,maxX:154,minZ:107,maxZ:117},
    {minX:-89,maxX:-79,minZ:-27,maxZ:117},{minX:144,maxX:154,minZ:-27,maxZ:117},
    {minX:-88,maxX:-69,minZ:8,maxZ:15},{minX:140,maxX:154,minZ:8,maxZ:15});

  const traffic=w.trafficCars, outside=[], parking=[];
  const bounds=(x,z,yaw,long=2.05,wide=.86)=>{
    const co=Math.abs(Math.cos(yaw)),si=Math.abs(Math.sin(yaw));
    const sx=long*co+wide*si,sz=long*si+wide*co;
    return {minX:x-sx,maxX:x+sx,minZ:z-sz,maxZ:z+sz};
  };
  const overlap=(a,b,extra=0)=>a.minX<b.maxX+extra&&a.maxX>b.minX-extra&&a.minZ<b.maxZ+extra&&a.maxZ>b.minZ-extra;
  const apply=(c,a)=>Object.assign(c,a);
  function trafficSpawnClear(x,z,yaw,ignore,halfLength=2.05,halfWidth=.86) {
    const candidate=bounds(x,z,yaw,halfLength,halfWidth);
    return w.colliders.every(c=>!c.trafficBody || c.vehicleOwner===ignore || !overlap(candidate,c,.18));
  }
  function resolveSpawn(item) {
    if (!(item._nominal>0 || item.nominal>0 || item._policePatrol)) return;
    if (item.route) {
      const start=item.dist||0;
      for(let i=0;i<48;i++) {
        const dist=start+i*5.5, p=point(item.route,dist);
        if(trafficSpawnClear(p.x,p.z,p.yaw,item)) {
          item.dist=dist; item.group.position.set(p.x,item.group.position.y,p.z); item.group.rotation.y=p.yaw; return;
        }
      }
    } else if (item.dir) {
      const start=item.group.position.x, z=item.group.position.z;
      for(let i=0;i<48;i++) {
        let x=start+item.dir*i*5.5;
        if(x>149)x=-84+((x-149)%233);
        if(x< -84)x=149-((-84-x)%233);
        if(trafficSpawnClear(x,z,item.group.rotation.y,item)) { item.group.position.x=x; return; }
      }
    }
  }
  function addCollider(item,owner=item) {
    resolveSpawn(item);
    const p=item.group.position;
    item._trafficCol=Object.assign(bounds(p.x,p.z,item.group.rotation.y),{vehicleOwner:owner,trafficBody:true});
    w.colliders.push(item._trafficCol);
  }
  function sync(item) {
    if(!item._trafficCol)return;
    const p=item.group.position;
    apply(item._trafficCol,bounds(p.x,p.z,item.group.rotation.y));
  }
  for(const car of traffic){car._nominal=car.speed;car._hornWait=0;addCollider(car);}
  // Police cruisers receive the same live collider metadata as traffic, while keeping their existing patrol objects.
  const police=window.MMS_POLICE?.getTrafficCars?.() || [];
  for(const car of police) {
    car._nominal=3.2; car._policePatrol=true; car._trafficCol=car.collider;
    const p=car.group.position;
    apply(car.collider,Object.assign(bounds(p.x,p.z,car.group.rotation.y),{vehicleOwner:car,trafficBody:true,policePatrol:true}));
    if(w.colliders.indexOf(car.collider)<0)w.colliders.push(car.collider);
  }
  // The showroom cars remain solid when parked but the player never collides with their own driven car.
  for(const car of MMS_CARS.cars) addCollider(car,car);
  const delivery=g.depot.delivery, truck=delivery.truck;
  truck._trafficCol=Object.assign(bounds(-40,9.95,0,2.45,1),{vehicleOwner:truck,trafficBody:true});
  const deliveryUpdate=delivery.update.bind(delivery);
  delivery.update=function(dt){
    const r=deliveryUpdate(dt), active=truck.group.visible, index=w.colliders.indexOf(truck._trafficCol);
    if(active){if(index<0)w.colliders.push(truck._trafficCol);
      const p=truck.group.position;apply(truck._trafficCol,bounds(p.x,p.z,0,2.45,1));}
    else if(index>=0)w.colliders.splice(index,1);
    return r;
  };
  const deliveryReset=delivery.reset.bind(delivery);
  delivery.reset=function(){const r=deliveryReset(),i=w.colliders.indexOf(truck._trafficCol);if(i>=0)w.colliders.splice(i,1);return r;};
  const oldDrive=MMS_CARS.step.bind(MMS_CARS);
  MMS_CARS.step=function(game,dt){const r=oldDrive(game,dt);if(MMS_CARS.driving)sync(MMS_CARS.driving);return r;};
  const oldExit=MMS_CARS.exit.bind(MMS_CARS);
  MMS_CARS.exit=function(game){const car=MMS_CARS.driving;const r=oldExit(game);if(car)sync(car);return r;};

  // Two opposing lanes around the perimeter. Positions are distance-based along four segments.
  const routes=[
    [[-81.8,-19.8],[146.8,-19.8],[146.8,109.8],[-81.8,109.8],[-81.8,-19.8]],
    [[-86.2,-24.2],[-86.2,114.2],[151.2,114.2],[151.2,-24.2],[-86.2,-24.2]]
  ];
  // Road routes are immutable. Cache segment lengths to avoid repeated hypot calls
  // on every vehicle tick, without changing collision or signal calculations.
  const routeLengths=new WeakMap();
  function routeInfo(route){
    let info=routeLengths.get(route);
    if(info)return info;
    const segments=[];let total=0;
    for(let i=1;i<route.length;i++){
      const dx=route[i][0]-route[i-1][0],dz=route[i][1]-route[i-1][1];
      const len=Math.hypot(dx,dz);segments.push({dx,dz,len});total+=len;
    }
    info={segments,total};routeLengths.set(route,info);return info;
  }
  function length(route){return routeInfo(route).total;}
  function point(route,d){
    const info=routeInfo(route),total=info.total;d=((d%total)+total)%total;
    for(let i=1;i<route.length;i++){
      const a=route[i-1],{dx,dz,len}=info.segments[i-1];
      if(d<=len){const t=d/len;return{x:a[0]+dx*t,z:a[1]+dz*t,yaw:-Math.atan2(dz,dx)};}
      d-=len;
    }
    return{x:route[0][0],z:route[0][1],yaw:0};
  }
  const colors=[0x1f4e8c,0xe4ba42,0xd65b4b,0xe8eceb,0x6baf9c,0x707b9d];
  for(let lane=0;lane<2;lane++)for(let i=0;i<3;i++){
    const route=routes[lane],len=length(route),dist=len*(i/3)+(lane?50:0),pos=point(route,dist);
    const group=new T.Group();group.position.set(pos.x,.1,pos.z);group.rotation.y=pos.yaw;w.root.add(group);
    const model=['sedan','hatch','taxi'][i],v=MMS_VEH.build(w,group,model,colors[lane*3+i],0x1b1d21,0xd5dadf);
    const car={group,wheels:v.wheels,route,dist,nominal:5.0+i*.35,_hornWait:0};
    addCollider(car);outside.push(car);
  }
  // Arka bulvarda tek araç: doğu bağlantısından çevre yoluna dönerek dolaşır.
  const districtRoute=[[34.2,72],[34.2,122.8],[146.8,122.8],[146.8,109.8],[39,109.8],[39,72],[34.2,72]];
  {
    const pos=point(districtRoute,0), group=new T.Group();
    group.position.set(pos.x,.1,pos.z);group.rotation.y=pos.yaw;w.root.add(group);
    const v=MMS_VEH.build(w,group,'hatch',0x4396af,0x1b1d21,0xd5dadf);
    const car={group,wheels:v.wheels,route:districtRoute,dist:0,nominal:4.4,_hornWait:0};
    addCollider(car);outside.push(car);
  }

  let hornCooldown=0;
  function honk(car,dt,blocked) {
    car._hornWait=blocked?(car._hornWait||0)+dt:0;
    if(blocked && car._hornWait>2 && hornCooldown<=0 && Math.hypot(car.group.position.x-g.player.pos.x,car.group.position.z-g.player.pos.z)<32){
      g.audio.play('horn');hornCooldown=5;car._hornWait=0;
    }
  }
  // AI-TCA: protect same-lane headway, reject overlapping spawns, and reserve clear gaps for police lane crossings.
  function followingBlocked(car,x,z,yaw) {
    if (!(car._nominal>0 || car.nominal>0 || car._policePatrol)) return false;
    const ux=Math.cos(yaw),uz=-Math.sin(yaw),sx=-uz,sz=ux;
    const ownSpeed=Math.max(1,car._nominal||car.nominal||car.speed||3.2);
    const safeGap=Math.max(5.4,Math.min(9.0,ownSpeed*1.25));
    for(const c of w.colliders) {
      if(!c.trafficBody || c.vehicleOwner===car)continue;
      const lead=c.vehicleOwner;if(!lead || !lead.group)continue;
      const oy=lead.group.rotation.y, ox=Math.cos(oy),oz=-Math.sin(oy);
      if(ux*ox+uz*oz<.82)continue;
      const dx=lead.group.position.x-x,dz=lead.group.position.z-z;
      const ahead=dx*ux+dz*uz, lateral=Math.abs(dx*sx+dz*sz);
      if(ahead<=0 || lateral>1.55)continue;
      // A target speed can stay positive while a red light or obstruction
      // holds the car still. Use measured movement for controlled traffic.
      const leadSpeed=Number.isFinite(lead._trafficActualSpeed)?lead._trafficActualSpeed:
        Number.isFinite(lead.speed)?Math.max(0,lead.speed):(lead._nominal||lead.nominal||0);
      if(ahead<5.4 || (ahead<safeGap && leadSpeed<ownSpeed-.35))return true;
    }
    return false;
  }
  function blocked(car,next,x=(next.minX+next.maxX)/2,z=(next.minZ+next.maxZ)/2,yaw=car.group.rotation.y) {
    const current=car._trafficCol || car.collider, moving=MMS_CARS.driving;
    for(const c of w.colliders) {
      if(c===current || c.vehicleOwner===car)continue;
      // Existing solid scenery, parked cars, police cars and other traffic.
      if(!overlap(next,c,.08))continue;
      // If already overlapping, only permit movement that reduces penetration.
      // The old unconditional exemption let cars drive through one another.
      if(current && overlap(current,c,0)){
        const area=(a,b)=>Math.max(0,Math.min(a.maxX,b.maxX)-Math.max(a.minX,b.minX))*Math.max(0,Math.min(a.maxZ,b.maxZ)-Math.max(a.minZ,b.minZ));
        if(area(next,c)<area(current,c)-.00001)continue;
      }
      return true;
    }
    if(!g.player.marketUpper && !moving && !(car.publicBus && g.playerAboard)) {
      const p=g.player.pos,pc={minX:p.x-.42,maxX:p.x+.42,minZ:p.z-.42,maxZ:p.z+.42};
      if(overlap(next,pc,.2)) {
        if(!current || !overlap(current,pc,.2))return true;
        // If already in contact or the safety margin, allow separation but
        // never move further into the player. Center distance also handles a
        // player contained entirely inside the car's larger bounding box.
        const measure=(a)=>{
          const cx=(a.minX+a.maxX)/2,cz=(a.minZ+a.maxZ)/2;
          const dx=cx-p.x,dz=cz-p.z;
          const depth=Math.min((a.maxX-a.minX)/2+.42-Math.abs(dx),(a.maxZ-a.minZ)/2+.42-Math.abs(dz));
          return {depth,distance:dx*dx+dz*dz};
        };
        const before=measure(current),after=measure(next);
        if(after.depth>before.depth+.000001 || after.distance<=before.distance+.000001)return true;
      }
    }
    if(followingBlocked(car,x,z,yaw))return true;
    return false;
  }
  function orientedPenetration(x,z,yaw,halfLength,halfWidth,c) {
    const ux=Math.cos(yaw),uz=-Math.sin(yaw),vx=-uz,vz=ux;
    const cx=(c.minX+c.maxX)/2,cz=(c.minZ+c.maxZ)/2;
    const ax=(c.maxX-c.minX)/2,az=(c.maxZ-c.minZ)/2,dx=x-cx,dz=z-cz;
    // Smallest separating-axis translation. Negative means no overlap.
    return Math.min(
      ax+Math.abs(ux)*halfLength+Math.abs(vx)*halfWidth-Math.abs(dx),
      az+Math.abs(uz)*halfLength+Math.abs(vz)*halfWidth-Math.abs(dz),
      halfLength+ax*Math.abs(ux)+az*Math.abs(uz)-Math.abs(dx*ux+dz*uz),
      halfWidth+ax*Math.abs(vx)+az*Math.abs(vz)-Math.abs(dx*vx+dz*vz));
  }
  function canDrive(car,x,z,yaw,old) {
    const model=MMS_VEH.KINDS[car.s.kind] || MMS_VEH.KINDS.sedan, half=(model.len||4.5)/2;
    for(const c of w.colliders) {
      if(c.vehicleOwner===car)continue;
      const next=orientedPenetration(x,z,yaw,half,.88,c);
      if(next<0)continue;
      const current=orientedPenetration(old.x,old.z,yaw,half,.88,c);
      // A pre-existing overlap may be escaped or slid along, but not deepened.
      if(current<0 || next>current+.000001)return false;
    }
    return true;
  }
  let westJunctionBus=null, eastJunctionBus=null;
  function advanceMain(car,dt) {
    if(!car._nominal)return;
    let x=car.group.position.x+car.dir*car.speed*dt, wrapped=false;
    if(x>149){x=-84;wrapped=true;} if(x< -84){x=149;wrapped=true;}
    const next=bounds(x,car.group.position.z,car.group.rotation.y);
    const heldForBus=(westJunctionBus&&car.dir<0&&car.group.position.x>=-65&&x< -65) ||
      (eastJunctionBus&&car.dir<0&&wrapped);
    const heldForParking=window.__parkingExitReservation&&car.dir>0&&
      car.group.position.x+2.05<=-25&&x+2.05> -25;
    const redLight=window.__trafficSignals?.mustStop(car,x,car.group.position.z,car.group.rotation.y,2.05);
    const isBlocked=heldForBus || heldForParking || redLight || (wrapped && !trafficSpawnClear(x,car.group.position.z,car.group.rotation.y,car)) ||
      blocked(car,next,x,car.group.position.z,car.group.rotation.y);
    car._trafficActualSpeed=isBlocked?0:Math.abs(car.speed);
    if(!isBlocked){car.group.position.x=x;sync(car);for(const wheel of car.wheels||[])wheel.rotation.z-=car.speed*dt/.35;}
    honk(car,dt,isBlocked);
  }
  function busHasWestJunction(bus) {
    const p=bus.group.position;
    if(westJunctionBus===bus){
      if(p.x>-76 || p.z>18 || p.x< -95){westJunctionBus=null;return false;}
      return true;
    }
    // Reserve before the bus nose enters the perpendicular perimeter lane.
    if(p.x< -82 && p.z>=-7 && p.z<5){
      const occupied=outside.concat(parking).some(c=>c!==bus&&Math.abs(c.group.position.x+81.8)<5&&c.group.position.z>-8&&c.group.position.z<25)
        || traffic.some(c=>c._nominal>0&&c.group.position.x< -65&&c.group.position.x> -95);
      if(!occupied){westJunctionBus=bus;return true;}
    }
    return false;
  }
  function busHasEastJunction(bus) {
    const p=bus.group.position;
    if(eastJunctionBus===bus){
      if(p.z< -7 || p.x<120){eastJunctionBus=null;return false;}
      return true;
    }
    if(p.x>=125&&p.x<132&&p.z>8&&p.z<13){
      const occupied=outside.concat(parking).some(c=>c!==bus&&c.group.position.x>142&&c.group.position.x<156&&c.group.position.z>-10&&c.group.position.z<27)
        || traffic.some(c=>c._nominal>0&&c.group.position.x>130);
      if(!occupied){eastJunctionBus=bus;return true;}
    }
    return false;
  }
  function advanceOuter(car,dt) {
    const nextDist=car.dist+car.nominal*dt,p=point(car.route,nextDist);
    const next=bounds(p.x,p.z,p.yaw);
    // A bus holding the west merge gets the junction. Cars already inside
    // finish clearing it; approaching perimeter cars wait before the crossing.
    const atWest=Math.abs(p.x+81.8)<4;
    const holdsBus=westJunctionBus&&atWest&&car.group.position.z>=22&&p.z<22;
    const eastApproach=eastJunctionBus&&p.x>142&&p.x<156&&
      ((car.group.position.z<=-10&&p.z> -10)||(car.group.position.z>=27&&p.z<27));
    const redLight=window.__trafficSignals?.mustStop(car,p.x,p.z,p.yaw,2.05);
    const isBlocked=holdsBus||eastApproach||redLight||blocked(car,next,p.x,p.z,p.yaw);
    car._trafficActualSpeed=isBlocked?0:Math.abs(car.nominal);
    if(!isBlocked){car.dist=nextDist;car.group.position.set(p.x,.1,p.z);car.group.rotation.y=p.yaw;sync(car);
      for(const wheel of car.wheels||[])wheel.rotation.z-=car.nominal*dt/.35;}
    honk(car,dt,isBlocked);
  }
  const oldUpdate=w.update.bind(w);
  w.update=function(dt,player,playing){
    const r=oldUpdate(dt,player,playing);
    if(!playing)return r;
    hornCooldown=Math.max(0,hornCooldown-dt);
    for(const car of MMS_CARS.cars)sync(car);
    for(const car of traffic)advanceMain(car,dt);
    for(const car of outside)advanceOuter(car,dt);
    return r;
  };
  function laneGapClear(car,crossX) {
    const lanes=[10.05,12.95];
    const laneVehicles=traffic.slice(),bus=window.__cityBus?.bus;
    // The bus is not in trafficCars, but it uses the same road as patrols.
    if(bus?.group && bus.group.visible!==false && !laneVehicles.includes(bus))laneVehicles.push(bus);
    for(const other of laneVehicles) {
      if(other===car || !lanes.some(l=>Math.abs(other.group.position.z-l)<1.15))continue;
      const dx=crossX-other.group.position.x, dir=other.dir||Math.sign(Math.cos(other.group.rotation.y));
      const speed=Math.abs(Number.isFinite(other._trafficActualSpeed)?other._trafficActualSpeed:
        Number.isFinite(other.speed)?other.speed:(other._nominal||0));
      if(speed<.2) { if(Math.abs(dx)<12)return false; continue; }
      const eta=(dx*dir)/speed;
      if((eta>=-.75 && eta<4.5) || Math.abs(dx)<7)return false;
    }
    const conflictZ=11.5;
    for(const other of outside.concat(parking)) {
      if(other===car)continue;
      const distance=Math.hypot(other.group.position.x-crossX,other.group.position.z-conflictZ);
      if(distance<9.5)return false;
    }
    for(const other of police) {
      if(other===car)continue;
      if(Math.hypot(other.group.position.x-crossX,other.group.position.z-conflictZ)<7.5)return false;
    }
    return true;
  }
  function needsMergeReservation(car,x,z) {
    if(!car._policePatrol)return false;
    const p=car.group.position;
    const vertical=Math.abs(x-p.x)<.2 && Math.abs(z-p.z)>.03;
    const touchesRoad=q=>q+2.2>=9.0 && q-2.2<=14.0;
    return vertical && (touchesRoad(p.z)||touchesRoad(z));
  }
  function canMove(car,x,z,yaw,dt) {
    const now=(typeof performance!=='undefined'&&performance.now)?performance.now():Date.now();
    let stop=!!window.__trafficSignals?.mustStop(car,x,z,yaw,2.05);
    if(needsMergeReservation(car,x,z) && (car._mergeGrantedUntil||0)<=now) {
      if(!laneGapClear(car,x))stop=true;
      else car._mergeGrantedUntil=now+2200;
    }
    if(!stop)stop=blocked(car,bounds(x,z,yaw),x,z,yaw);
    honk(car,dt,stop);
    return !stop;
  }
  function canMoveVehicle(car,x,z,yaw,dt,halfLength=2.05,halfWidth=.86) {
    const p=car.group.position,dyaw=Math.atan2(Math.sin(yaw-car.group.rotation.y),Math.cos(yaw-car.group.rotation.y));
    if(window.__parkingExitReservation && car!==window.__parkingExitReservation && Math.cos(yaw)>.8 &&
       p.z>8.5&&p.z<11.6&&p.x+halfLength<=-25&&x+halfLength> -25){honk(car,dt,true);return false;}
    if(window.__trafficSignals?.mustStop(car,x,z,yaw,halfLength)){honk(car,dt,true);return false;}
    if(car.publicBus && p.x< -82 && p.z>=-7 && p.z<5 && !busHasWestJunction(car)) {
      honk(car,dt,true);return false;
    }
    if(car.publicBus && westJunctionBus===car)busHasWestJunction(car);
    if(car.publicBus && p.x>=125 && p.x<132 && p.z>8 && p.z<13 && !busHasEastJunction(car)) {
      honk(car,dt,true);return false;
    }
    if(car.publicBus && eastJunctionBus===car)busHasEastJunction(car);
    const steps=Math.max(1,Math.ceil(Math.hypot(x-p.x,z-p.z)/.65),Math.ceil(Math.abs(dyaw)/.18));
    let stop=false;
    for(let i=1;i<=steps;i++){
      const t=i/steps,px=p.x+(x-p.x)*t,pz=p.z+(z-p.z)*t,angle=car.group.rotation.y+dyaw*t;
      if(blocked(car,bounds(px,pz,angle,halfLength,halfWidth),px,pz,angle)){stop=true;break;}
    }
    honk(car,dt,stop);
    return !stop;
  }
  window.__cityTraffic={outer:outside,main:traffic,police,parking,sync,bounds,canDrive,canMove,canMoveVehicle,
    canSpawnAt:(x,z,yaw,ignore,halfLength,halfWidth)=>trafficSpawnClear(x,z,yaw,ignore,halfLength,halfWidth),
    AI_TCA:{laneGapClear,followingBlocked},laneGapClear:(x)=>laneGapClear(null,x)};
})();
