/* Existing city restaurant interface: tr, en, az, ru. */
(function(root){
  'use strict';
  const entries={
    exitMarket:['Önce marketin üst katından in.','Leave the market upper floor first.','Əvvəlcə marketin üst mərtəbəsindən en.','Сначала спуститесь с верхнего этажа магазина.'],
    wentUp:['Manzaralı üst kata çıktın. Masaya bakıp etkileşime bas.','You reached the scenic floor. Look at the table and interact.','Mənzərəli mərtəbəyə qalxdın. Masaya baxıb qarşılıqlı əlaqə düyməsinə bas.','Вы поднялись на видовой этаж. Посмотрите на стол и взаимодействуйте.'],
    skyTitle:['🥂 Manzaralı Üst Kat','🥂 Scenic Upper Floor','🥂 Mənzərəli Üst Mərtəbə','🥂 Видовой верхний этаж'],
    skyBalance:['Şehir manzaralı cam kenarı masa · Bakiye: {balance} $','Window table with city view · Balance: ${balance}','Şəhər mənzərəli pəncərə masası · Balans: {balance} $','Столик у окна с видом на город · Баланс: {balance} $'],
    skySolo:['Tek kişilik akşam yemeği · 60 $','Dinner for one · $60','Bir nəfərlik axşam yeməyi · 60 $','Ужин на одного · 60 $'],
    skyDate:['Eşinle/sevgilinle manzaralı yemek · 120 $','Scenic dinner with your partner · $120','Sevgilinlə mənzərəli yemək · 120 $','Ужин с видом для пары · 120 $'],
    skyPartner:['Davet ettiğin kişi masada sana katılacak. (+10 ❤️)','Your invited partner will join you at the table. (+10 ❤️)','Dəvət etdiyin şəxs masada sənə qoşulacaq. (+10 ❤️)','Ваш партнёр присоединится за столом. (+10 ❤️)'],
    noPartner:['Birlikte yemek için önce bir sevgili edin.','Find a partner before dining together.','Birlikdə yemək üçün əvvəlcə sevgili tap.','Для совместного ужина сначала найдите пару.'],
    close:['Kapat','Close','Bağla','Закрыть'],
    skyStarted:['Manzaralı akşam yemeği başladı! ❤️ (+10 ilişki)','Scenic dinner has started! ❤️ (+10 relationship)','Mənzərəli axşam yeməyi başladı! ❤️ (+10 münasibət)','Ужин с видом начался! ❤️ (+10 к отношениям)'],
    enjoySky:['Afiyet olsun! 🥂','Enjoy your meal! 🥂','Nuş olsun! 🥂','Приятного аппетита! 🥂'],
    title:['🍽️ Şehir Lokantası','🍽️ City Restaurant','🍽️ Şəhər Restoranı','🍽️ Городской ресторан'],
    balance:['Bakiye: {balance} $','Balance: ${balance}','Balans: {balance} $','Баланс: {balance} $'],
    solo:['Tek kişilik yemek · 45 $','Meal for one · $45','Bir nəfərlik yemək · 45 $','Обед на одного · 45 $'],
    date:['Baş başa yemek · 90 $','Dinner for two · $90','İki nəfərlik yemək · 90 $','Обед на двоих · 90 $'],
    nearby:['Sevgilin yanında: birlikte yemek yiyebilirsiniz. (+10 ilişki)','Your partner is nearby: you can dine together. (+10 relationship)','Sevgilin yanındadır: birlikdə yemək yeyə bilərsiniz. (+10 münasibət)','Ваш партнёр рядом: вы можете поесть вместе. (+10 к отношениям)'],
    invite:['Sevgilini konuşma menüsünden yemeğe davet edip yanına getir.','Invite your partner to dinner from the conversation menu and bring them along.','Sevgilini söhbət menyusundan yeməyə dəvət edib yanına gətir.','Пригласите партнёра на ужин через меню разговора и приведите сюда.'],
    together:['Birlikte yemek yiyorsunuz! ❤️ (+10 ilişki)','You are dining together! ❤️ (+10 relationship)','Birlikdə yemək yeyirsiniz! ❤️ (+10 münasibət)','Вы ужинаете вместе! ❤️ (+10 к отношениям)'],
    enjoy:['Afiyet olsun! 🍽️','Enjoy your meal! 🍽️','Nuş olsun! 🍽️','Приятного аппетита! 🍽️']
  };
  const langs=['tr','en','az','ru'];
  function t(lang,key,vars){
    const index=Math.max(0,langs.indexOf(lang)),row=entries[key];
    let text=row&&row[index]||row&&row[0]||['Metin kullanılamıyor','Text unavailable','Mətn mövcud deyil','Текст недоступен'][index];
    if(vars)for(const name of Object.keys(vars))text=text.split('{'+name+'}').join(String(vars[name]));
    return text.replace(/\{[A-Za-z0-9_]+\}/g,'');
  }
  const api={entries,t};
  if(root)root.MMS_RESTAURANT_TRANSLATIONS=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:null);
