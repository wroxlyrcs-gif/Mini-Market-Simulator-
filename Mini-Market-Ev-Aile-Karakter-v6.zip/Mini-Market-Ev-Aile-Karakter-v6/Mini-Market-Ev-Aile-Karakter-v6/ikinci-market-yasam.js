/* İkinci market: bağımsız müşteri, stok ve çalışan sistemi. */
(function () {
  'use strict';
  if (window.__MMS_SECOND_DEPOT_ACTIVE) return;
  const g=window.__mms, T=window.THREE, people=window.__mmsPeople;
  if(!g||!T||!people||window.__ikinciMarket)return;
  const w=g.world, KEY='mms_citymarket_staff_v1', OWN='mms_citymarket_v1';
  const PRICE=20, HIRE_CASHIER=120, HIRE_STOCKER=100, BUY_STOCK=40, BUY_AMOUNT=20, MAX_SHELF=24;
  const defaults={cashier:false,stocker:false,shelf:12,reserve:20,sales:0};
  let saved={};try {saved=JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch(_){}
  const st={cashier:saved.cashier===true,stocker:saved.stocker===true,
    shelf:Math.max(0,Math.min(MAX_SHELF,Math.floor(Number.isFinite(saved.shelf)?saved.shelf:defaults.shelf))),
    reserve:Math.max(0,Math.min(999,Math.floor(Number.isFinite(saved.reserve)?saved.reserve:defaults.reserve))),
    sales:Math.max(0,Math.floor(Number.isFinite(saved.sales)?saved.sales:0))};
  let own=false,ownTimer=0,spawnTimer=6,stockTimer=0,checkoutTimer=0,ui=null,uiOpen=false,created=0;
  const shoppers=[]; let cashier=null,stocker=null;
  function save(){try{localStorage.setItem(KEY,JSON.stringify(st));}catch(_){} if(g.data&&g.saveNow)g.saveNow();}
  function owned(){try{return JSON.parse(localStorage.getItem(OWN)||'{}').owned===true;}catch(_){return false;}}
  const words={
    tr:{title:'Süper Market Yönetimi',locked:'Önce Süper Marketi satın al.',money:'Para',shelf:'Raftaki ürün',reserve:'Depodaki ürün',waiting:'Kasada bekleyen',sales:'Tamamlanan satış',cashier:'Kasiyer',stocker:'Raf görevlisi',hired:'Çalışıyor',none:'Yok',hire:'İşe al',fire:'İşten çıkar',cost:'tek seferlik',buy:'20 ürün al',fill:'Rafa ürün koy',pay:'Sıradaki müşteriyi öde',close:'Kapat',hint:'Müşteri satışları bakiyene eklenir. Önceki günlük market geliri ayrıca devam eder.',nomoney:'Yeterli paran yok.',empty:'Depo boş veya raf dolu.',noqueue:'Kasada bekleyen müşteri yok.',paid:'Müşteri ödemesi alındı.',purchased:'Depoya 20 ürün eklendi.'},
    en:{title:'Supermarket Management',locked:'Buy the supermarket first.',money:'Money',shelf:'On shelves',reserve:'In stockroom',waiting:'Waiting at checkout',sales:'Completed sales',cashier:'Cashier',stocker:'Shelf worker',hired:'Working',none:'Not hired',hire:'Hire',fire:'Dismiss',cost:'one-time',buy:'Buy 20 items',fill:'Restock shelves',pay:'Check out next customer',close:'Close',hint:'Customer sales go to your balance. Existing daily market income continues separately.',nomoney:'Not enough money.',empty:'Stockroom empty or shelves full.',noqueue:'No customer is waiting.',paid:'Customer payment received.',purchased:'20 items added to stockroom.'},
    az:{title:'Supermarket idarəsi',locked:'Əvvəlcə supermarketi alın.',money:'Pul',shelf:'Rəfdəki məhsul',reserve:'Anbardakı məhsul',waiting:'Kassada gözləyən',sales:'Tamamlanan satış',cashier:'Kassir',stocker:'Rəf işçisi',hired:'İşləyir',none:'Yoxdur',hire:'İşə al',fire:'İşdən çıxar',cost:'birdəfəlik',buy:'20 məhsul al',fill:'Rəfi doldur',pay:'Növbəti müştərini hesabla',close:'Bağla',hint:'Müştəri satışları balansınıza əlavə olunur. Mövcud gündəlik gəlir ayrıca davam edir.',nomoney:'Kifayət qədər pul yoxdur.',empty:'Anbar boşdur və ya rəf doludur.',noqueue:'Kassada gözləyən müştəri yoxdur.',paid:'Müştərinin ödənişi alındı.',purchased:'Anbara 20 məhsul əlavə edildi.'},
    ru:{title:'Управление супермаркетом',locked:'Сначала купите супермаркет.',money:'Деньги',shelf:'Товар на полках',reserve:'Товар на складе',waiting:'Ждут у кассы',sales:'Завершено продаж',cashier:'Кассир',stocker:'Работник полок',hired:'Работает',none:'Не нанят',hire:'Нанять',fire:'Уволить',cost:'разовый платёж',buy:'Купить 20 товаров',fill:'Пополнить полки',pay:'Обслужить покупателя',close:'Закрыть',hint:'Продажи зачисляются на баланс. Прежний ежедневный доход начисляется отдельно.',nomoney:'Недостаточно денег.',empty:'Склад пуст или полки заполнены.',noqueue:'У кассы никто не ждёт.',paid:'Оплата получена.',purchased:'На склад добавлено 20 товаров.'}
  };
  const tx=k=>(words[g.ui?.lang]||words.tr)[k]||k;
  function toast(k){g.ui.toast(tx(k));}
  function model(options,x,z){
    const h=people.buildHuman({...options,lod:true});
    h.group.position.set(x,0,z);h.group.visible=false;w.root.add(h.group);
    if(h.lowGroup){h.lowGroup.position.set(x,0,z);h.lowGroup.visible=false;w.root.add(h.lowGroup);}
    return h;
  }
  function appearance(h,x,z,rot,show){
    const dist=Math.hypot(g.player.pos.x-x,g.player.pos.z-z), high=show&&dist<23, low=show&&dist>=23&&dist<55;
    h.group.position.set(x,0,z);h.group.rotation.y=rot;h.group.visible=high;
    if(h.lowGroup){h.lowGroup.position.set(x,0,z);h.lowGroup.rotation.y=rot;h.lowGroup.visible=low;}
  }
  function ensureStaff(){
    if(st.cashier&&!cashier)cashier=model({shirt:0xc52f2a,pants:0x333c46,apron:0x283c34,skin:0xe0ac69,hair:0x30251d},57.3,68.9);
    if(st.stocker&&!stocker)stocker=model({shirt:0x3e714c,pants:0x30383f,apron:0x5f7447,skin:0xf1c27d,hair:0x35231e},48.7,70.8);
  }
  // The system uses its own compact inventory, separate from the first market.
  function refill(){const n=Math.min(6,st.reserve,MAX_SHELF-st.shelf);if(n<=0)return false;st.reserve-=n;st.shelf+=n;save();return true;}
  function spend(n){if(!g.data||g.data.money<n){toast('nomoney');return false;}g.data.money-=n;return true;}
  function hire(role){if(st[role]){st[role]=false;save();draw();return;}
    const cost=role==='cashier'?HIRE_CASHIER:HIRE_STOCKER;if(!spend(cost))return;
    st[role]=true;ensureStaff();save();draw();
  }
  function buyStock(){if(st.reserve>979||!spend(BUY_STOCK))return;st.reserve+=BUY_AMOUNT;save();toast('purchased');draw();}
  function manualStock(){if(!refill())toast('empty');draw();}
  function open(){
    if(!owned()){toast('locked');return;}
    if(!ui){ui=document.createElement('div');ui.id='second-shop-panel';document.body.appendChild(ui);
      for(const ev of ['pointerdown','touchstart','mousedown','click'])ui.addEventListener(ev,e=>e.stopPropagation());}
    uiOpen=true;g.setInputLocked(true);draw();
  }
  function close(){uiOpen=false;if(ui)ui.classList.remove('open');g.setInputLocked(false);}
  function draw(){if(!uiOpen)return;const q=shoppers.filter(c=>c.state==='waiting').length;
    const button=(id,label)=>`<button type="button" data-action="${id}">${label}</button>`;
    ui.innerHTML=`<section class="ss-card"><h2>${tx('title')}</h2><p>${tx('money')}: <b>${Math.floor(g.data.money)} $</b></p><div class="ss-grid"><span>${tx('shelf')}: <b>${st.shelf}/${MAX_SHELF}</b></span><span>${tx('reserve')}: <b>${st.reserve}</b></span><span>${tx('waiting')}: <b>${q}</b></span><span>${tx('sales')}: <b>${st.sales}</b></span></div>
      ${button('cashier',tx('cashier')+': '+(st.cashier?tx('hired')+' · '+tx('fire'):tx('hire')+' '+HIRE_CASHIER+' $ ('+tx('cost')+')'))}
      ${button('stocker',tx('stocker')+': '+(st.stocker?tx('hired')+' · '+tx('fire'):tx('hire')+' '+HIRE_STOCKER+' $ ('+tx('cost')+')'))}
      ${button('buy',tx('buy')+' · '+BUY_STOCK+' $')}${button('fill',tx('fill'))}${button('pay',tx('pay'))}<p class="ss-hint">${tx('hint')}</p>${button('close',tx('close'))}</section>`;
    ui.classList.add('open');for(const b of ui.querySelectorAll('button')) b.onclick=()=>{
      switch(b.dataset.action){case 'cashier':hire('cashier');break;case 'stocker':hire('stocker');break;case 'buy':buyStock();break;case 'fill':manualStock();break;case 'pay':if(!checkout())toast('noqueue');draw();break;case 'close':close();break;}
    };
  }
  // Walkway coordinates pass through the open door, around the gondola and to the checkout aisle.
  const routeIn=[[51,65.5],[51,68],[50.5,70.7],[48.7,70.7]],routeOut=[[50.5,70.7],[51,68],[51,65.5],[51,63.7]];
  function spawn(){if(shoppers.length>=2||st.shelf<=0)return false;
    const shirts=[0x698dac,0xc58d69,0xb487ad,0x8eaa77];
    const h=model({shirt:shirts[created%shirts.length],pants:0x374653,skin:people.SKINS[created%people.SKINS.length],hair:0x382820},51,63.7);created++;
    shoppers.push({h,x:51,z:63.7,rot:0,state:'enter',points:routeIn.map(p=>p.slice()),timer:0,queueOrder:0});return true;
  }
  function move(c,dt){
    const p=c.points[0];if(!p)return true;
    const dx=p[0]-c.x,dz=p[1]-c.z,d=Math.hypot(dx,dz),step=1.1*dt;
    if(d<=step||d<.02){c.x=p[0];c.z=p[1];c.points.shift();return c.points.length===0;}
    c.x+=dx/d*step;c.z+=dz/d*step;c.rot=Math.atan2(dx,dz);return false;
  }
  function checkout(){const c=shoppers.find(c=>c.state==='waiting');if(!c)return false;
    g.data.money+=PRICE;st.sales++;c.state='leave';c.points=routeOut.map(p=>p.slice());
    c.h.setCarry(false);save();if(uiOpen)draw();return true;
  }
  function step(dt){
    if(g.state!=='playing'||!g.data)return;
    ownTimer+=dt;if(ownTimer>=.5){ownTimer=0;own=owned();}
    if(!own){for(const h of [cashier,stocker])if(h)appearance(h,0,0,0,false);for(const c of shoppers)appearance(c.h,c.x,c.z,c.rot,false);return;}
    ensureStaff();
    if(cashier)appearance(cashier,57.3,68.9,-Math.PI/2,st.cashier);
    if(stocker){appearance(stocker,48.7,70.8,Math.PI/2,st.stocker);stocker.walk(dt,0);}
    if(st.stocker){stockTimer+=dt;if(stockTimer>=7){stockTimer=0;if(refill()&&uiOpen)draw();}}else stockTimer=0;
    spawnTimer-=dt;if(spawnTimer<=0){spawnTimer=15;spawn();}
    for(let i=shoppers.length-1;i>=0;i--){const c=shoppers[i];let walking=false;
      if(c.state==='enter'){walking=true;if(move(c,dt)){c.state='browse';c.timer=2.5;}}
      else if(c.state==='browse'){c.timer-=dt;if(c.timer<=0){
        if(st.shelf>0){st.shelf--;save();c.h.setCarry(true);c.state='queue';c.points=[[50.5,70.7],[52.4,70.7],[52.4,69.7]];}
        else{c.state='leave';c.points=routeOut.map(p=>p.slice());}
      }}
      else if(c.state==='queue'){
        // One person at a time moves to the register; others wait in the aisle.
        const busy=shoppers.some(o=>o!==c&&o.state==='waiting');
        if(!busy){walking=true;if(move(c,dt)){c.state='waiting';checkoutTimer=0;if(uiOpen)draw();}}
      }
      else if(c.state==='leave'){walking=true;if(move(c,dt)){w.root.remove(c.h.group);if(c.h.lowGroup)w.root.remove(c.h.lowGroup);shoppers.splice(i,1);continue;}}
      c.h.walk(dt,walking?1:0);appearance(c.h,c.x,c.z,c.rot,true);
    }
    if(st.cashier&&shoppers.some(c=>c.state==='waiting')){checkoutTimer+=dt;if(checkoutTimer>=2){checkoutTimer=0;checkout();}}else checkoutTimer=0;
  }
  const css=document.createElement('style');css.textContent=`#second-shop-panel{display:none;position:fixed;inset:0;z-index:140;background:#11251dcb;align-items:center;justify-content:center;padding:12px;font:15px system-ui;color:#243b31}#second-shop-panel.open{display:flex}#second-shop-panel .ss-card{width:min(480px,95vw);max-height:90vh;overflow:auto;background:#f4f5e8;padding:18px;border-radius:16px;border:2px solid #e1b641}#second-shop-panel h2{font-size:21px;margin:0 0 8px}#second-shop-panel p{margin:6px 0}#second-shop-panel .ss-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}#second-shop-panel button{width:100%;min-height:42px;border:0;border-radius:9px;margin:3px 0;background:#28674b;color:white;font:700 14px system-ui}#second-shop-panel .ss-hint{font-size:13px;color:#4b6156}`;document.head.appendChild(css);
  w.addInteractable({id:'second-shop-manager',label:{tr:'🛒 Süper Market yönetimi',en:'🛒 Supermarket management',az:'🛒 Supermarket idarəsi',ru:'🛒 Управление супермаркетом'},box:[1.3,1.8,.6,49.7,.1,67.7],action:open});
  // The management point is mounted on the wall by the entrance, not in the walkway.
  const button=w.b(.8,.58,.10,49.7,1.0,67.31,0x278259,{parent:w.root,cast:false,receive:false});button.userData.secondShop=true;
  const label=w.canvasTex(256,96,(c,x,y)=>{c.fillStyle='#206d4c';c.fillRect(0,0,x,y);c.fillStyle='#ffffff';c.textAlign='center';c.textBaseline='middle';c.font='bold 38px sans-serif';c.fillText('YÖNETİM',x/2,y/2);});
  w.sign(label,.72,.27,49.7,1.31,67.38,0);
  const prior=w.update.bind(w);w.update=function(dt,...args){const result=prior(dt,...args);step(Math.min(.1,Math.max(0,dt)));return result;};
  window.__ikinciMarket={inspect:()=>({owned:own,staff:{cashier:st.cashier,stocker:st.stocker},shelf:st.shelf,reserve:st.reserve,sales:st.sales,shoppers:shoppers.map(c=>({state:c.state,x:c.x,z:c.z})),waiting:shoppers.filter(c=>c.state==='waiting').length}),open};
})();
