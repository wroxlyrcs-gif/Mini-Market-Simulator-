/* v3.3: connected southern city edge, neighborhood amenities and low-cost outskirts vegetation. */
(function () {
  'use strict';
  const g = window.__mms;
  if (!g || !window.THREE || window.__mmsOutskirtsBuilt) return;
  window.__mmsOutskirtsBuilt = true;
  const T = window.THREE, w = g.world, regions = __req('player').REGIONS;
  const group = new T.Group();
  w.scene.add(group);
  const solid = (sx, sy, sz, x, y, z, color) => {
    const mesh = w.b(sx, sy, sz, x, y, z, color, { parent: group, cast: false, receive: false });
    mesh.userData.static = true;
    return mesh;
  };
  const asphalt = 0x4b4f55, curb = 0xd8d4cb, white = 0xf4f4ec;
  const green = 0x6f9e4f, parkGreen = 0x65b96b, concrete = 0xa9ada9;
  const warmGlass = MMS_NIGHT.reg(w.mat(0x86bdca, { emissive: 0xffd68a, emissiveIntensity: 0 }));

  // The existing cross-city arterial continues south from the old perimeter road to a signed city exit.
  // The single underlying terrain plane is continuous; these road/sidewalk overlays have no coplanar duplicates.
  solid(10, .06, 100, 36.5, .015, 180, asphalt); // z=130..230
  solid(1.3, .07, 96, 29.9, -.005, 180, curb);
  solid(1.3, .07, 96, 43.1, -.005, 180, curb);
  for (let z = 137; z <= 221; z += 8) solid(.14, .018, 2.4, 36.5, .055, z, white);
  // Small neighborhood cross street and a compact junction, separated from the through lanes.
  solid(114, .055, 7, 96, .01, 190, asphalt); // x=39..153
  solid(112, .045, 1.2, 96, -.005, 185.9, curb);
  solid(112, .045, 1.2, 96, -.005, 194.1, curb);
  for (let x = 47; x <= 146; x += 8) solid(2.4, .018, .13, x, .05, 190, white);
  // Roadside apron for the service center.
  solid(21, .06, 15, 58.5, -.005, 151.5, concrete);

  // Decorative, non-enterable repair garage with two visible service bays.
  const service = { x: 59, z: 150, w: 14, d: 9, h: 4.6 };
  solid(service.w, service.h, service.d, service.x, 0, service.z, 0xd5d7d3);
  solid(service.w + .5, .28, service.d + .5, service.x, service.h, service.z, 0x384956);
  solid(service.w, .42, .14, service.x, 3.15, service.z + service.d / 2 + .09, 0x256b75);
  for (const x of [55.5, 62.5]) {
    solid(4.5, 2.8, .12, x, .02, service.z + service.d / 2 + .14, 0x687a82);
    for (let y = .65; y < 2.65; y += .5) solid(4.25, .06, .16, x, y, service.z + service.d / 2 + .23, 0xaebdc0);
    solid(4.45, .12, .3, x, 2.95, service.z + service.d / 2 + .18, 0x384956);
  }
  // Office glazing, roof ventilation and a legible roadside sign.
  solid(2.2, 1.25, .08, 64, 1.35, service.z + service.d / 2 + .18, 0x79b6c6);
  solid(1.3, .7, 1.1, 54, service.h + .22, service.z - 2.5, 0x899294);
  w.colliders.push({ minX: service.x - service.w / 2, maxX: service.x + service.w / 2,
    minZ: service.z - service.d / 2, maxZ: service.z + service.d / 2 });

  // Park: open lawns, a curved-feel path, benches and warm low-cost lamps.
  solid(27, .045, 24, 88, -.08, 157, parkGreen);
  solid(1.8, .035, 21, 88, -.015, 157, 0xcbb99b);
  solid(19, .035, 1.4, 88, -.01, 157, 0xcbb99b);
  const bench = (x, z) => {
    solid(1.7, .13, .48, x, .47, z, 0x8a5a36);
    solid(1.7, .13, .12, x, .65, z + .18, 0x8a5a36);
    for (const dx of [-.65, .65]) solid(.12, .5, .12, x + dx, .03, z, 0x454545);
  };
  bench(80, 152); bench(96, 162); bench(80, 163);
  for (const [x, z] of [[78, 146], [98, 146], [78, 168], [98, 168]]) {
    solid(.1, 3.2, .1, x, .02, z, 0x42464d);
    solid(.48, .16, .48, x, 3.23, z, warmGlass);
    MMS_NIGHT.light(w, x, 3.5, z, 0xffd28a, 2.8, 18);
  }

  // A proper small football pitch, separate from the market's basketball court and the main stadium.
  const fx = 118, fz = 164, fw = 32, fd = 22;
  solid(fw + 1, .05, fd + 1, fx, -.04, fz, 0x4c6b43);
  solid(fw, .06, fd, fx, .01, fz, 0x287d43);
  for (let i = 0; i < 8; i++) solid(4, .012, fd - .4, fx - 14 + i * 4, .047, fz, i % 2 ? 0x328c4c : 0x26763e);
  for (const z of [fz - fd / 2 + .5, fz + fd / 2 - .5]) solid(fw - .8, .018, .09, fx, .06, z, white);
  for (const x of [fx - fw / 2 + .5, fx + fw / 2 - .5]) solid(.09, .018, fd - .8, x, .06, fz, white);
  solid(.08, .018, fd - 1, fx, .06, fz, white);
  // Penalty boxes and small goals.
  for (const side of [-1, 1]) {
    const gx = fx + side * (fw / 2 - 2.8);
    for (const dz of [-2.5, 2.5]) solid(.12, 1.55, .12, gx, .07, fz + dz, white);
    solid(.12, .12, 5.1, gx, 1.62, fz, white);
    solid(4.6, .018, .08, fx + side * 11.4, .06, fz - 4.2, white);
    solid(4.6, .018, .08, fx + side * 11.4, .06, fz + 4.2, white);
    solid(.08, .018, 8.4, fx + side * 9.1, .06, fz, white);
  }
  solid(.12, .018, .12, fx, .06, fz, white);

  // Four modest homes along the side street. All buildings are decorative and safely collidable.
  const houses = [
    { x: 56, z: 178, wall: 0xe7dfd0, roof: 0x49535a, accent: 0x9b6d4d },
    { x: 77, z: 178, wall: 0xcbd6d8, roof: 0x344550, accent: 0x527c78 },
    { x: 101, z: 207, wall: 0xe8e5dc, roof: 0x4e514a, accent: 0xb7835d },
    { x: 127, z: 207, wall: 0xd6d9d5, roof: 0x344550, accent: 0x718e9c },
    { x: 145, z: 178, wall: 0xeaddc9, roof: 0x564b44, accent: 0x9c7357 }
  ];
  for (const [houseIndex,h] of houses.entries()) {
    solid(8.2, 3.7, 6.8, h.x, 0, h.z, h.wall);
    solid(8.6, .24, 7.2, h.x, 3.7, h.z, h.roof);
    solid(1.2, 2.1, .12, h.x, .02, h.z + 3.48, h.roof);
    for (const dx of [-2.5, 2.2]) {
      solid(1.65, 1.35, .08, h.x + dx, 1.25, h.z + 3.52, warmGlass);
      solid(.08, 1.45, .12, h.x + dx, 1.25, h.z + 3.57, h.accent);
    }
    solid(3.0, .18, 1.35, h.x, 2.3, h.z + 3.7, h.accent);
    // Interior-facing warm windows are emissive at night; one low-cost porch light per home.
    if (houseIndex % 2 === 0) MMS_NIGHT.light(w, h.x, 2.0, h.z + 4.0, 0xffd28a, 1.8, 12);
    w.colliders.push({ minX: h.x - 4.1, maxX: h.x + 4.1, minZ: h.z - 3.4, maxZ: h.z + 3.4 });
  }

  // Clear directional signs: city exit, service center, park and pitch. All signs are double-sided.
  const makeSign = (text, width, height, x, y, z, color, turn = 0) => {
    const tex = w.canvasTex(512, 128, (ctx, cw, ch) => {
      ctx.fillStyle = color; ctx.fillRect(0, 0, cw, ch);
      ctx.strokeStyle = '#f6f2df'; ctx.lineWidth = 8; ctx.strokeRect(5, 5, cw - 10, ch - 10);
      ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '900 46px Arial'; ctx.fillText(text, cw / 2, ch / 2);
    });
    const mesh = new T.Mesh(w.geo('plane'), new T.MeshBasicMaterial({ map: tex, side: T.DoubleSide }));
    mesh.scale.set(width, height, 1); mesh.position.set(x, y, z); mesh.rotation.y = turn;
    mesh.userData.static = true; mesh.castShadow = false; mesh.receiveShadow = false; group.add(mesh);
  };
  const signpost = (x, z, boardY, text, width, color, face = 0) => {
    solid(.12, boardY + .25, .12, x, 0, z, 0x35434b);
    solid(width + .25, 1.2, .18, x, boardY, z, 0x35434b);
    makeSign(text, width, .82, x, boardY + .6, z + (face === 0 ? .105 : -.105), color, face);
  };
  signpost(58, 142, 3.1, 'CITY AUTO SERVICE', 7.8, '#17636b', 0);
  signpost(72, 145, 2.7, 'CITY PARK', 4.8, '#2d7440', Math.PI);
  signpost(100, 153, 2.7, 'CITY FC', 4.0, '#1f5e38', Math.PI);
  signpost(45, 220, 4.0, 'CITY EXIT  →', 7.2, '#1c5b3b', Math.PI);

  // A secondary two-lane frontage gives the new homes a natural street connection.
  regions.push(
    { minX: 30.5, maxX: 154, minZ: 130, maxZ: 230 },
    { minX: 39, maxX: 154, minZ: 186, maxZ: 194 },
    { minX: 48, maxX: 71, minZ: 141, maxZ: 162 },
    { minX: 73, maxX: 103, minZ: 143, maxZ: 171 },
    { minX: 101, maxX: 135, minZ: 152, maxZ: 176 }
  );

  // Two instanced meshes, not one draw call per tree: keeps the mobile rendering budget intact.
  const treeSpots = [
    [48, 144], [70, 145], [104, 143], [137, 145], [50, 164], [69, 167],
    [106, 147], [138, 159], [50, 198], [68, 212], [88, 204], [95, 219],
    [117, 193], [137, 212], [149, 202], [48, 176], [89, 180], [144, 164],
    [64, 193], [106, 183], [134, 183], [149, 153]
  ];
  const trunkGeo = new T.CylinderGeometry(.12, .23, 2.35, 6);
  const crownGeo = new T.ConeGeometry(1.55, 3.35, 7, 1);
  const trunkMat = new T.MeshLambertMaterial({ color: 0x70513a });
  const crownMat = new T.MeshLambertMaterial({ color: 0x477b3d });
  const trunks = new T.InstancedMesh(trunkGeo, trunkMat, treeSpots.length);
  const crowns = new T.InstancedMesh(crownGeo, crownMat, treeSpots.length);
  const dummy = new T.Object3D();
  treeSpots.forEach(([x, z], i) => {
    const scale = .78 + (i % 4) * .08;
    dummy.position.set(x, 1.17 * scale, z); dummy.rotation.set(0, i * .71, 0); dummy.scale.setScalar(scale); dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    dummy.position.set(x, 3.15 * scale, z); dummy.rotation.set(0, i * .71, 0); dummy.updateMatrix();
    crowns.setMatrixAt(i, dummy.matrix);
  });
  for (const mesh of [trunks, crowns]) {
    mesh.instanceMatrix.needsUpdate = true; mesh.castShadow = false; mesh.receiveShadow = false;
    mesh.frustumCulled = false; w.scene.add(mesh);
  }
  w.mergeStatic(group);

  window.__cityOutskirtsMap = [
    { x0: 31.5, x1: 41.5, z0: 130, z1: 230, c: '#4b4f55' },
    { x0: 39, x1: 154, z0: 186, z1: 194, c: '#4b4f55' }
  ];
})();
