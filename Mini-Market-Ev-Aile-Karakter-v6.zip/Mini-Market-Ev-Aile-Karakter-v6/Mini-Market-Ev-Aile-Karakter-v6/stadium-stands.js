/* CITY STADIUM: düşük maliyetli koltuklar, merdivenler, çatı makasları ve maç günü taraftarları. */
(function () {
  'use strict';
  const g = window.__mms;
  if (!g || !window.THREE || !g.world) return;
  const T = window.THREE, w = g.world, stadium = new T.Group(), crowd = new T.Group();
  stadium.name = 'stadium-seating';
  crowd.name = 'matchday-crowd';
  w.scene.add(stadium, crowd);
  const blocks = [{z0:53.4,n:6},{z0:59.4,n:9},{z0:68.7,n:9},{z0:78.4,n:6}];
  const seats = [], bodies = [], heads = [];
  const skins = [0xe9b99a,0xc68962,0xf0c3a8,0x9c694e,0xd8a27c];
  const shirts = [0xf0efea,0x20272d,0xd5d9d7,0x343b42,0x3a5368,0xb2b5b2];
  let index = 0;
  const pick = (arr, seed) => arr[Math.abs(seed) % arr.length];
  // Same row coordinates as the ticketing system. Even rows stay free of
  // spectators so every assigned ticket has a clear seat and camera position.
  for (const side of [-1,1]) for(let row=0;row<8;row++) {
    const x=side*(19.6+row*1.3), top=.7+row*.42;
    for(const block of blocks) for(let k=0;k<block.n;k++) {
      // Taraftar sıraları biletli koltuklara göre yarım koltuk kaydırılır;
      // seyirci tam göz hizasına gelmez ve önündeki iki kişi arasından saha görünür.
      const z=block.z0+k*.9+(row%2 ? .45 : 0);
      const light=(row+k+index)%6<3;
      seats.push({x,y:top+.13,z,sx:.50,sy:.24,sz:.62,c:light?0xe9eae5:0x2f3940});
      seats.push({x:x+side*.32,y:top+.40,z,sx:.11,sy:.55,sz:.62,c:light?0xe9eae5:0x2f3940});
      if(row%2===1 && (index%9)!==0) {
        const color=pick(shirts,index*7+row), skin=pick(skins,index*11+row);
        bodies.push({x,y:top+.68,z,sx:.39,sy:.68,sz:.44,c:color});
        heads.push({x,y:top+1.20,z,sx:.32,sy:.32,sz:.32,c:skin});
      }
      index++;
    }
  }
  // North and south stands retain the central passage.
  for (let row=0;row<3;row++) {
    const top=.7+row*.42;
    for(let i=0;i<36;i++) {
      const x=-17.5+i;
      for(const end of [-1,1]) {
        if(end<0 && Math.abs(x)<5.5) continue;
        const z=end>0?81.65+row*1.2:54.6-row*1.2;
        const light=(i+row+(end>0?0:1))%4<2;
        seats.push({x,y:top+.13,z,sx:.64,sy:.24,sz:.48,c:light?0xe9eae5:0x2f3940});
        seats.push({x,y:top+.40,z:z+end*.30,sx:.64,sy:.55,sz:.11,c:light?0xe9eae5:0x2f3940});
        if ((i+row*3)%5!==0) {
          bodies.push({x,y:top+.68,z,sx:.44,sy:.68,sz:.39,c:pick(shirts,i*7+row)});
          heads.push({x,y:top+1.20,z,sx:.32,sy:.32,sz:.32,c:pick(skins,i*11+row)});
        }
      }
    }
  }
  function instances(items,parent,geometry='box') {
    const mesh = new T.InstancedMesh(w.geo(geometry),w.mat(0xffffff),items.length);
    const temp = new T.Object3D(), color = new T.Color();
    items.forEach((a,i)=>{
      temp.position.set(a.x,a.y,a.z);temp.rotation.set(0,0,0);temp.scale.set(a.sx,a.sy,a.sz);temp.updateMatrix();
      mesh.setMatrixAt(i,temp.matrix);mesh.setColorAt(i,color.setHex(a.c));
    });
    mesh.instanceMatrix.needsUpdate=true;
    if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
    mesh.castShadow=false;mesh.receiveShadow=true;mesh.frustumCulled=false;
    parent.add(mesh);
    return mesh;
  }
  instances(seats,stadium);
  const bodyMesh=instances(bodies,crowd);
  const headMesh=instances(heads,crowd,'sphere');
  const hairColors=[0x2e2726,0x4d3428,0x89725b,0x211f21];
  const hair=heads.map((h,i)=>({x:h.x,y:h.y+.13,z:h.z,sx:.33,sy:.15,sz:.33,c:hairColors[i%hairColors.length]}));
  const hairMesh=instances(hair,crowd,'sphere');
  // Yan tribünlerde kollar Z, kale arkalarında X yönünde omuzlara yerleşir.
  // Tek paylaşımlı instanced mesh, her taraftar için ayrı çizim çağrısı oluşturmaz.
  const arms=[];
  bodies.forEach((body,i)=>{
    const alongZ=Math.abs(body.x)>18.5;
    for(const side of [-1,1]) arms.push({x:body.x+(alongZ?0:side*.29),y:body.y+.2,
      z:body.z+(alongZ?side*.29:0),sx:.14,sy:.56,sz:.14,c:body.c,alongZ,side,fan:i});
  });
  const armMesh=instances(arms,crowd);
  let lastSeat='', elapsed=0, refresh=0;
  const tmp=new T.Object3D();
  function animateCrowd(dt) {
    const seated=!!(window.MMS_STADIUM && MMS_STADIUM.seated && g.player);
    const p=seated?g.player.pos:null;
    const key=p ? p.x.toFixed(2)+','+p.z.toFixed(2) : 'none';
    // 12 güncelleme/saniye, basit beden ve kollarla mobil yükü sınırlı tutar.
    elapsed+=Math.max(0,Math.min(dt,.1));refresh+=Math.max(0,Math.min(dt,.1));
    if(key===lastSeat && refresh<1/12)return;
    refresh=0;lastSeat=key;
    const sound=window.__stadiumCrowdSound && window.__stadiumCrowdSound.audio;
    const rhythm=sound && !sound.paused ? sound.currentTime : elapsed;
    const beat=2*Math.PI*105/60;
    const hidden=(a)=>!!p && Math.abs(a.x-p.x)<1.8 && Math.abs(a.z-p.z)<1.45;
    const bounce=(i)=>.055*(.5+.5*Math.sin(rhythm*beat+(i%13)*.20));
    for(const [mesh,arr] of [[bodyMesh,bodies],[headMesh,heads],[hairMesh,hair]]) {
      arr.forEach((a,i)=>{
        const hide=hidden(a), bob=bounce(i);
        tmp.position.set(a.x,a.y+bob,a.z);tmp.rotation.set(0,0,0);
        tmp.scale.set(hide?0:a.sx,hide?0:a.sy,hide?0:a.sz);tmp.updateMatrix();
        mesh.setMatrixAt(i,tmp.matrix);
      });
      mesh.instanceMatrix.needsUpdate=true;
    }
    arms.forEach((a,i)=>{
      const body=bodies[a.fan], hide=hidden(body), bob=bounce(a.fan);
      // Bazıları ritme göre kollarını kaldırıp indirir, hareketler faz kaymalıdır.
      const wave=1.65+.95*Math.sin(rhythm*beat/2+(a.fan%17)*.20+a.side*.22);
      const angle=a.side*wave, half=a.sy/2;
      tmp.rotation.set(a.alongZ?angle:0,0,a.alongZ?0:-angle);
      tmp.position.set(a.x+(a.alongZ?0:-Math.sin(angle)*half),
        a.y+bob-Math.cos(angle)*half,a.z+(a.alongZ?-Math.sin(angle)*half:0));
      tmp.scale.set(hide?0:a.sx,hide?0:a.sy,hide?0:a.sz);tmp.updateMatrix();
      armMesh.setMatrixAt(i,tmp.matrix);
    });
    armMesh.instanceMatrix.needsUpdate=true;
  }

  // Stair nosings, railings and lightweight roof trusses remain decorative
  // and never alter ticket seating, entrance collision or the match pitch.
  const part = (sx,sy,sz,x,y,z,c) => w.b(sx,sy,sz,x,y,z,c,{parent:stadium,cast:false,receive:false});
  for(const side of [-1,1]) {
    for(let row=0;row<8;row++) for(const dz of [-9.5,0,9.5]) {
      const x=side*(19.6+row*1.3), top=.7+row*.42;
      part(1.1,.035,.08,x,top+.035,68+dz-.30,0xe7bf46);
      part(1.1,.035,.08,x,top+.035,68+dz+.30,0xe7bf46);
    }
    // Steel cross-bracing under the roof; no pillars in front of spectators.
    for(const z of [53.7,59.7,68,76.4,82.3]) {
      part(10.4,.10,.10,side*24.0,5.12,z,0x717d80);
      for(let n=0;n<4;n++) {
        const strut=part(2.55,.09,.09,side*(20.1+n*2.3),5.02,z,0x889393);
        strut.rotation.z=side*(n%2?-.23:.23);
      }
    }
    part(.16,.55,31.3,side*18.84,.55,68,0x303b40);
  }
  const bannerTex=w.canvasTex(1024,128,(ctx,width,height)=>{
    ctx.fillStyle='#252c31';ctx.fillRect(0,0,width,height);
    ctx.fillStyle='#f7f6ef';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.font='900 74px Arial';ctx.fillText('CITY FC  •  BİRLİKTE DAHA GÜÇLÜ',width/2,height/2);
  });
  for(const side of [-1,1]) {
    w.put('plane',16,1.15,1,side*29.34,4.65,68,
      new T.MeshBasicMaterial({map:bannerTex,side:T.DoubleSide}),
      {parent:stadium,ry:Math.PI/2,cast:false,receive:false});
  }
  crowd.visible=false;
  const oldUpdate=w.update.bind(w);
  w.update=function(dt,player,playing) {
    const result=oldUpdate(dt,player,playing);
    const m=g.clock && g.clock.minutes;
    crowd.visible=!!(playing && Number.isFinite(m) && m>=1180 && m<1320);
    if (crowd.visible) animateCrowd(dt);
    return result;
  };
  window.__stadiumStands={stadium,crowd,seatPieces:seats.length,spectators:bodies.length};
})();
