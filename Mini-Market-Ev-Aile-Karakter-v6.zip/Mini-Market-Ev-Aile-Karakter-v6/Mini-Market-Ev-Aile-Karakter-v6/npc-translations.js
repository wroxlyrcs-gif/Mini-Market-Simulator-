/* City NPC dialogue. Kept separate from game saves and loaded offline. */
(function (root) {
  'use strict';
  const entries = {
    greeting1: {tr:'Merhaba! Bugün hava çok güzel.',en:'Hi! The weather is lovely today.',az:'Salam! Bu gün hava çox gözəldir.',ru:'Привет! Сегодня прекрасная погода.'},
    greeting2: {tr:'Marketin yeni mi açıldı? Uğrarım!',en:'Did the market just open? I will drop by!',az:'Marketin təzə açılıb? Baş çəkərəm!',ru:'Твой магазин недавно открылся? Обязательно зайду!'},
    greeting3: {tr:'Stadyumdaki maçlar çok güzel oluyor.',en:'The matches at the stadium are great.',az:'Stadiondakı oyunlar çox maraqlı olur.',ru:'Матчи на стадионе проходят замечательно.'},
    greeting4: {tr:'ZUNEX CARS’ta süper arabalar var diyorlar!',en:'They say ZUNEX CARS has great supercars!',az:'Deyirlər, ZUNEX CARS-da əla maşınlar var!',ru:'Говорят, в ZUNEX CARS отличные машины!'},
    greeting5: {tr:'Şehir Merkezi’ndeki gökdelenleri gördün mü?',en:'Have you seen the skyscrapers downtown?',az:'Şəhər mərkəzindəki göydələnləri görmüsən?',ru:'Ты видел небоскрёбы в центре города?'},
    greeting6: {tr:'Parkta oturmak çok huzurlu.',en:'Sitting in the park is so peaceful.',az:'Parkda oturmaq çox rahatdır.',ru:'В парке так спокойно сидеть.'},
    welcome: {tr:'Hoş geldin, bugün nasılsın? ❤️',en:'Welcome home, how was your day? ❤️',az:'Xoş gəldin, bu gün necəsən? ❤️',ru:'С возвращением! Как прошёл день? ❤️'},
    talkTo: {tr:'💬 {name} ile konuş',en:'💬 Talk to {name}',az:'💬 {name} ilə danış',ru:'💬 Поговорить: {name}'},
    spouse: {tr:'Eşin 💍',en:'Spouse 💍',az:'Həyat yoldaşın 💍',ru:'Супруг(а) 💍'},
    partner: {tr:'Sevgilin ❤️',en:'Partner ❤️',az:'Sevgilin ❤️',ru:'Пара ❤️'},
    closeFriend: {tr:'Yakın arkadaş',en:'Close friend',az:'Yaxın dost',ru:'Близкий друг'},
    friend: {tr:'Arkadaş',en:'Friend',az:'Dost',ru:'Друг'},
    acquaintance: {tr:'Tanıdık',en:'Acquaintance',az:'Tanış',ru:'Знакомый'},
    chat: {tr:'💬 Sohbet et',en:'💬 Chat',az:'💬 Söhbət et',ru:'💬 Поболтать'},
    chatSoon: {tr:'Az önce konuştuk 😊',en:'We just talked 😊',az:'Az əvvəl danışdıq 😊',ru:'Мы только что поговорили 😊'},
    coffee: {tr:'☕ Kahve ısmarla (20 $)',en:'☕ Buy coffee ($20)',az:'☕ Qəhvə al (20 $)',ru:'☕ Угостить кофе (20 $)'},
    noMoney: {tr:'Yeterli paran yok!',en:'Not enough money!',az:'Kifayət qədər pulun yoxdur!',ru:'Не хватает денег!'},
    coffeeThanks: {tr:'Teşekkürler, çok naziksin! ☕ (+8 ❤️)',en:'Thank you, that is so kind! ☕ (+8 ❤️)',az:'Təşəkkür edirəm, çox mehribansan! ☕ (+8 ❤️)',ru:'Спасибо, очень мило! ☕ (+8 ❤️)'},
    flowers: {tr:'🌹 Çiçek al (60 $)',en:'🌹 Buy flowers ($60)',az:'🌹 Gül al (60 $)',ru:'🌹 Купить цветы (60 $)'},
    flowersThanks: {tr:'Çiçekler çok güzel! 🌹 (+15 ❤️)',en:'The flowers are beautiful! 🌹 (+15 ❤️)',az:'Güllər çox gözəldir! 🌹 (+15 ❤️)',ru:'Какие красивые цветы! 🌹 (+15 ❤️)'},
    askOut: {tr:'💌 Çıkma teklif et',en:'💌 Ask on a date',az:'💌 Görüş təklif et',ru:'💌 Предложить встречаться'},
    alreadyPartner: {tr:'Zaten bir sevgilin var! Önce onunla konuş 💔',en:'You already have a partner! Talk to them first 💔',az:'Artıq sevgilin var! Əvvəlcə onunla danış 💔',ru:'У тебя уже есть пара! Сначала поговори с ней 💔'},
    need70: {tr:'Önce birbirimizi daha iyi tanıyalım… (en az 70 ❤️ gerekir)',en:'Let us get to know each other better first… (at least 70 ❤️ required)',az:'Əvvəlcə bir-birimizi daha yaxşı tanıyaq… (ən az 70 ❤️ lazımdır)',ru:'Давай сначала узнаем друг друга лучше… (нужно не менее 70 ❤️)'},
    accepted: {tr:'Evet! Ben de seni seviyorum 💖 Artık sevgiliyiz!',en:'Yes! I love you too 💖 We are together now!',az:'Bəli! Mən də səni sevirəm 💖 Artıq sevgiliyik!',ru:'Да! Я тоже тебя люблю 💖 Теперь мы вместе!'},
    propose: {tr:'💍 Evlilik teklifi (500 $)',en:'💍 Propose ($500)',az:'💍 Evlilik təklifi et (500 $)',ru:'💍 Сделать предложение (500 $)'},
    need95: {tr:'Önce ilişkinizi güçlendirin. En az 95 ❤️ gerekli.',en:'Strengthen your relationship first. At least 95 ❤️ required.',az:'Əvvəlcə münasibətinizi gücləndirin. Ən az 95 ❤️ lazımdır.',ru:'Сначала укрепите отношения. Нужно не менее 95 ❤️.'},
    weddingCost: {tr:'Nikâh ve yüzük için 500 $ gerekiyor.',en:'The wedding and ring cost $500.',az:'Nikah və üzük üçün 500 $ lazımdır.',ru:'На свадьбу и кольцо нужно 500 $.'},
    married: {tr:'Evet! Artık evliyiz. Eve gelince sana yemek hazırlayacağım. 💍🏠',en:'Yes! We are married now. I will make you dinner at home. 💍🏠',az:'Bəli! Artıq evliyik. Evə gələndə sənə yemək hazırlayacağam. 💍🏠',ru:'Да! Теперь мы семья. Я приготовлю ужин дома. 💍🏠'},
    marriedNotice: {tr:'{name} ile evlendiniz! 💍',en:'You married {name}! 💍',az:'{name} ilə evləndiniz! 💍',ru:'Вы поженились: {name}! 💍'},
    parkWalk: {tr:'🌳 Parkta yürüyüş',en:'🌳 Walk in the park',az:'🌳 Parkda gəzinti',ru:'🌳 Прогуляться в парке'},
    restWalk: {tr:'Biraz dinlenelim, sonra yeniden yürürüz. 😊',en:'Let us rest a little, then walk again. 😊',az:'Bir az dincələk, sonra yenə gəzərik. 😊',ru:'Давай немного отдохнём, потом снова прогуляемся. 😊'},
    walked: {tr:'Parkta uzun bir yürüyüş yaptınız. (+5 ❤️)',en:'You took a long walk in the park. (+5 ❤️)',az:'Parkda uzun gəzintiyə çıxdınız. (+5 ❤️)',ru:'Вы долго гуляли в парке. (+5 ❤️)'},
    cityTour: {tr:'🚌 Şehir turu',en:'🚌 City tour',az:'🚌 Şəhər turu',ru:'🚌 Прогулка по городу'},
    tourLater: {tr:'Biraz sonra yeniden gezebiliriz. 😊',en:'We can explore again in a little while. 😊',az:'Bir az sonra yenə gəzə bilərik. 😊',ru:'Скоро сможем снова погулять. 😊'},
    toured: {tr:'Birlikte şehri gezdiniz. (+5 ❤️)',en:'You explored the city together. (+5 ❤️)',az:'Birlikdə şəhəri gəzdiniz. (+5 ❤️)',ru:'Вы вместе погуляли по городу. (+5 ❤️)'},
    spouseChat: {tr:'🗣️ Eşinle konuş',en:'🗣️ Talk to your spouse',az:'🗣️ Həyat yoldaşınla danış',ru:'🗣️ Поговорить с супругом'},
    chatLater: {tr:'Biraz sonra tekrar konuşalım. 😊',en:'Let us talk again in a little while. 😊',az:'Bir az sonra yenə danışaq. 😊',ru:'Давай поговорим чуть позже. 😊'},
    sharedDay: {tr:'Gününüzü birbirinize anlattınız. (+5 ❤️)',en:'You told each other about your day. (+5 ❤️)',az:'Gününüzü bir-birinizə danışdınız. (+5 ❤️)',ru:'Вы рассказали друг другу о своём дне. (+5 ❤️)'},
    dinner: {tr:'🥘 Akşam yemeği hazırla',en:'🥘 Prepare dinner',az:'🥘 Axşam yeməyi hazırla',ru:'🥘 Приготовить ужин'},
    cooking: {tr:'Mutfağa geçti ve sizin için yemek hazırlıyor. (+4 ❤️)',en:'They went to the kitchen to prepare a meal. (+4 ❤️)',az:'Mətbəxə keçib sizin üçün yemək hazırlayır. (+4 ❤️)',ru:'На кухне готовится ужин для вас. (+4 ❤️)'},
    familyTime: {tr:'👨‍👩‍👧 Ailecek vakit geçir',en:'👨‍👩‍👧 Spend family time',az:'👨‍👩‍👧 Ailə ilə vaxt keçir',ru:'👨‍👩‍👧 Провести время с семьёй'},
    restLater: {tr:'Biraz dinlenelim, sonra tekrar. 😊',en:'Let us rest a little, then try again. 😊',az:'Bir az dincələk, sonra yenə. 😊',ru:'Давай немного отдохнём и повторим позже. 😊'},
    familyEnjoyed: {tr:'Hep birlikte keyifli vakit geçirdiniz. (+6 ❤️)',en:'You enjoyed time together as a family. (+6 ❤️)',az:'Hamınız birlikdə xoş vaxt keçirdiniz. (+6 ❤️)',ru:'Вы отлично провели время всей семьёй. (+6 ❤️)'},
    evening: {tr:'Birlikte güzel bir akşam geçirdiniz. (+6 ❤️)',en:'You spent a lovely evening together. (+6 ❤️)',az:'Birlikdə gözəl axşam keçirdiniz. (+6 ❤️)',ru:'Вы вместе провели прекрасный вечер. (+6 ❤️)'},
    child: {tr:'👶 Çocuk sahibi ol (700 $)',en:'👶 Have a child ($700)',az:'👶 Uşaq sahibi ol (700 $)',ru:'👶 Завести ребёнка (700 $)'},
    familyComplete: {tr:'Aileniz şimdilik tamam. ❤️',en:'Your family is complete for now. ❤️',az:'Ailəniz hələlik tamamdır. ❤️',ru:'Пока ваша семья полная. ❤️'},
    childCost: {tr:'Aileye yeni bir üye için 700 $ gerekiyor.',en:'A new family member costs $700.',az:'Ailəyə yeni üzv üçün 700 $ lazımdır.',ru:'Для нового члена семьи нужно 700 $.'},
    childJoined: {tr:'{name} aileye katıldı! Artık {n} çocuğunuz var. 👶❤️',en:'{name} joined the family! You now have {n} children. 👶❤️',az:'{name} ailəyə qoşuldu! Artıq {n} uşağınız var. 👶❤️',ru:'{name} теперь в семье! Теперь у вас детей: {n}. 👶❤️'},
    goHome: {tr:'🏠 Eve dön',en:'🏠 Go home',az:'🏠 Evə qayıt',ru:'🏠 Вернуться домой'},
    sendHome: {tr:'🏠 Evine gönder',en:'🏠 Send home',az:'🏠 Evə göndər',ru:'🏠 Отправить домой'},
    walkTogether: {tr:'🚶 Birlikte gezintiye çık',en:'🚶 Go for a walk together',az:'🚶 Birlikdə gəzintiyə çıx',ru:'🚶 Погулять вместе'},
    takeWalk: {tr:'🚶 Gezintiye çık',en:'🚶 Go for a walk',az:'🚶 Gəzintiyə çıx',ru:'🚶 Отправиться на прогулку'},
    follows: {tr:'{name} seninle geliyor! 💕',en:'{name} is coming with you! 💕',az:'{name} səninlə gəlir! 💕',ru:'{name} идёт с тобой! 💕'},
    spendTime: {tr:'💞 Vakit geçir',en:'💞 Spend time together',az:'💞 Birlikdə vaxt keçir',ru:'💞 Провести время вместе'},
    againLater: {tr:'Biraz sonra tekrar… 😊',en:'Let us try again later… 😊',az:'Bir az sonra yenə… 😊',ru:'Давай немного позже… 😊'},
    enjoyed: {tr:'Birlikte çok güzel vakit geçirdik 💕 (+2 ❤️)',en:'We had a wonderful time together 💕 (+2 ❤️)',az:'Birlikdə çox gözəl vaxt keçirdik 💕 (+2 ❤️)',ru:'Мы прекрасно провели время вместе 💕 (+2 ❤️)'},
    hug: {tr:'🤗 Sarıl',en:'🤗 Hug',az:'🤗 Qucaqlamaq',ru:'🤗 Обнять'},
    hugged: {tr:'Sana sarıldı! 🤗 (+3 ❤️)',en:'You got a hug! 🤗 (+3 ❤️)',az:'Səni qucaqladı! 🤗 (+3 ❤️)',ru:'Тебя обняли! 🤗 (+3 ❤️)'},
    compliment: {tr:'💌 İltifat et',en:'💌 Give a compliment',az:'💌 İltifat et',ru:'💌 Сделать комплимент'},
    smiled: {tr:'Gülümseyerek teşekkür etti. 💕 (+2 ❤️)',en:'They smiled and thanked you. 💕 (+2 ❤️)',az:'Gülümsəyərək təşəkkür etdi. 💕 (+2 ❤️)',ru:'В ответ улыбнулись и поблагодарили. 💕 (+2 ❤️)'},
    inviteDinner: {tr:'🍽️ Yemeğe davet et',en:'🍽️ Invite to dinner',az:'🍽️ Yeməyə dəvət et',ru:'🍽️ Пригласить на ужин'},
    dinnerAccepted: {tr:'{name} davetini kabul etti! Birlikte Şehir Lokantası’na git. 💕',en:'{name} accepted! Go to the City Restaurant together. 💕',az:'{name} dəvətini qəbul etdi! Birlikdə Şəhər Restoranına gedin. 💕',ru:'{name} принимает приглашение! Сходите вместе в городской ресторан. 💕'},
    gift: {tr:'🎁 Sürpriz hediye (150 $)',en:'🎁 Surprise gift ($150)',az:'🎁 Sürpriz hədiyyə (150 $)',ru:'🎁 Подарок-сюрприз (150 $)'},
    surprised: {tr:'Bunu hiç beklemiyordum! 😍 (+5 ❤️)',en:'I did not expect this! 😍 (+5 ❤️)',az:'Bunu heç gözləmirdim! 😍 (+5 ❤️)',ru:'Я совсем не ожидал(а)! 😍 (+5 ❤️)'},
    breakUp: {tr:'💔 Ayrıl',en:'💔 Break up',az:'💔 Ayrıl',ru:'💔 Расстаться'},
    sad: {tr:'Çok üzgünüm… 💔',en:'I am so sorry… 💔',az:'Çox üzgünəm… 💔',ru:'Мне очень жаль… 💔'}
  };
  const missing = {tr:'Metin kullanılamıyor',en:'Text unavailable',az:'Mətn mövcud deyil',ru:'Текст недоступен'};
  function t(lang,key,vars) {
    const code=Object.prototype.hasOwnProperty.call(missing,lang)?lang:'tr';
    const row=entries[key];
    let text=row && (row[code] || row.en || row.tr) || missing[code];
    if(vars)for(const name of Object.keys(vars))text=text.split('{'+name+'}').join(String(vars[name]));
    return text.replace(/\{[a-zA-Z0-9_]+\}/g,'');
  }
  const api={entries,t};
  if(root)root.MMS_NPC_TRANSLATIONS=api;
  if(typeof module!=='undefined' && module.exports)module.exports=api;
})(typeof window!=='undefined'?window:null);
