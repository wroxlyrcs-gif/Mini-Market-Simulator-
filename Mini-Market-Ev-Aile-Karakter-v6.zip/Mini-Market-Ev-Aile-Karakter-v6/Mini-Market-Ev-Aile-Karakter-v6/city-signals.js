/* Stage 1: coordinated pedestrian crossings on the existing road network. */
(function () {
  'use strict';
  const g=window.__mms,T=window.THREE;
  if(!g||!T||!window.__cityTraffic||window.__trafficSignals)return;
  const w=g.world;
  // axis is the direction vehicles travel; lo/hi are the road edges.
  // The two arterial crossings serve the existing pedestrian route graph.
  const crossings=[
    {id:'west',axis:'x',at:-32.3,lo:8.2,hi:14.6,existing:true},
    {id:'avenue',axis:'z',at:16,lo:-3.5,hi:3.5},
    {id:'district',axis:'z',at:100,lo:31.5,hi:41.5}
  ];
  const marks=new T.Group(), signals=new T.Group();marks.name='PEDESTRIAN CROSSING MARKINGS';signals.name='TRAFFIC SIGNALS';w.scene.add(marks,signals);
  const red=new T.MeshBasicMaterial({color:0x52221b}),amber=new T.MeshBasicMaterial({color:0x594214}),green=new T.MeshBasicMaterial({color:0x17402b});
  const pedRed=new T.MeshBasicMaterial({color:0x52221b}),pedGreen=new T.MeshBasicMaterial({color:0x17402b});
  const beam=(parent,sx,sy,sz,x,y,z,color)=>{
    const m=w.b(sx,sy,sz,x,y,z,color,{parent,cast:false,receive:false});
    if(parent===marks)m.userData.static=true;return m;
  };
  function occupied(x,z){
    return w.colliders.some(c=>x>c.minX-.45&&x<c.maxX+.45&&z>c.minZ-.45&&z<c.maxZ+.45);
  }
  function lamp(x,z,yaw) {
    const group=new T.Group();group.position.set(x,0,z);group.rotation.y=yaw;signals.add(group);
    beam(group,.10,3.1,.10,0,0,0,0x303b3d);
    beam(group,.47,1.25,.20,0,1.9,0,0x26343a);
    for(const [y,mat] of [[2.89,red],[2.55,amber],[2.21,green]]) {
      const dot=new T.Mesh(new T.SphereGeometry(.11,8,6),mat);dot.position.set(0,y,-.12);group.add(dot);
    }
    beam(group,.46,.55,.20,.40,1.5,0,0x26343a);
    for(const [y,mat] of [[1.86,pedRed],[1.66,pedGreen]]) {
      const dot=new T.Mesh(new T.SphereGeometry(.08,8,6),mat);dot.position.set(.4,y,-.12);group.add(dot);
    }
  }
  for(const c of crossings){
    if(!c.existing){
      for(let p=c.lo+.45;p<c.hi;p+=.85){
        if(c.axis==='x')beam(marks,3.3,.025,.42,c.at,.083,p,0xf7f7ed);
        else beam(marks,.42,.025,3.3,p,.083,c.at,0xf7f7ed);
      }
    }
    // Put the posts off the road, and skip a candidate if it would intersect
    // an existing solid building or street object.
    const choices=c.axis==='x'
      ? [[c.at-2.4,c.lo-1.3,0],[c.at+2.4,c.hi+1.3,Math.PI]]
      : [[c.lo-1.3,c.at+2.4,Math.PI/2],[c.hi+1.3,c.at-2.4,-Math.PI/2]];
    for(const [x,z,yaw] of choices)if(!occupied(x,z))lamp(x,z,yaw);
  }
  w.mergeStatic(marks);
  // 16s green, 2s amber, 3s all-red, 11s walk and 6s clearance.
  const CYCLE=38, active=new Map();
  let elapsed=0,lastPhase='';
  const phase=()=>elapsed<16?'drive':elapsed<18?'amber':elapsed<21?'all-red':elapsed<32?'walk':'clear';
  const inZone=(c,x,z,margin=0)=>c.axis==='x'
    ? Math.abs(x-c.at)<1.7+margin&&z>c.lo-margin&&z<c.hi+margin
    : Math.abs(z-c.at)<1.7+margin&&x>c.lo-margin&&x<c.hi+margin;
  const overlaps=(a,b)=>a.minX<b.maxX&&a.maxX>b.minX&&a.minZ<b.maxZ&&a.maxZ>b.minZ;
  const area=c=>c.axis==='x'
    ? {minX:c.at-1.85,maxX:c.at+1.85,minZ:c.lo,maxZ:c.hi}
    : {minX:c.lo,maxX:c.hi,minZ:c.at-1.85,maxZ:c.at+1.85};
  function clearForPedestrian(c){
    const region=area(c);
    return !w.colliders.some(b=>b.trafficBody&&overlaps(region,b));
  }
  function canPedestrianMove(p,nx,nz){
    // Adjacent crossing zones meet at the junction. Someone already clearing
    // one zone must be allowed to finish through the adjoining zone, even if
    // the walk phase ended in the meantime.
    const alreadyCrossing=crossings.some(c=>active.get(c.id)?.has(p)&&inZone(c,p.x,p.z,.12));
    for(const c of crossings){
      const inside=inZone(c,p.x,p.z,.03), entering=inZone(c,nx,nz,.03);
      if(!inside&&!entering)continue;
      let walkers=active.get(c.id);
      if(!walkers){walkers=new Set();active.set(c.id,walkers);}
      if(inside||walkers.has(p)||alreadyCrossing){walkers.add(p);continue;}
      if(phase()!=='walk'||!clearForPedestrian(c))return false;
      walkers.add(p);
    }
    return true;
  }
  function mustStop(car,x,z,yaw,halfLength=2.05){
    if(!car?.group)return false;
    const p=car.group.position, ux=Math.cos(yaw),uz=-Math.sin(yaw);
    for(const c of crossings){
      const along=c.axis==='x'?ux:uz, lateral=c.axis==='x'?z:x;
      if(Math.abs(along)<.8||lateral<c.lo-.8||lateral>c.hi+.8)continue;
      const pedHere=active.get(c.id)?.size>0;
      if(phase()==='drive'&&!pedHere)continue;
      const sign=Math.sign(along),now=(c.at-(c.axis==='x'?p.x:p.z))*sign-halfLength,
        after=(c.at-(c.axis==='x'?x:z))*sign-halfLength;
      // Don't stop a vehicle already crossing; let it clear the striped area.
      if(now>=-.05&&after<1.85)return true;
    }
    return false;
  }
  function repaint(){
    const current=phase();if(current===lastPhase)return;lastPhase=current;
    red.color.setHex(current==='drive'||current==='amber'?0x52221b:0xff483a);
    amber.color.setHex(current==='amber'?0xffc342:0x594214);
    green.color.setHex(current==='drive'?0x32eb7b:0x17402b);
    pedRed.color.setHex(current==='walk'?0x52221b:0xff483a);
    pedGreen.color.setHex(current==='walk'?0x32eb7b:0x17402b);
  }
  function step(dt){
    for(const c of crossings){
      const walkers=active.get(c.id);if(!walkers)continue;
      for(const p of walkers)if(!inZone(c,p.x,p.z,.12))walkers.delete(p);
    }
    const next=elapsed+Math.max(0,dt);
    // Do not display vehicle green while a pedestrian is still clearing.
    const occupied=[...active.values()].some(set=>set.size>0);
    elapsed=next>=CYCLE&&occupied?CYCLE-.001:next%CYCLE;
    repaint();
  }
  repaint();
  const original=w.update.bind(w);
  w.update=function(dt,pos,playing){if(playing)step(dt);return original(dt,pos,playing);};
  window.__trafficSignals={crossings,phase,step,mustStop,canPedestrianMove,clearForPedestrian,
    inspect:()=>({phase:phase(),elapsed,lamps:signals.children.length,crossings:crossings.map(c=>({id:c.id,clear:clearForPedestrian(c),pedestrians:active.get(c.id)?.size||0,
      waiting:[...(active.get(c.id)||[])].map(p=>({id:p.id,state:p.state,x:+p.x.toFixed(2),z:+p.z.toFixed(2)}))}))})};
})();
