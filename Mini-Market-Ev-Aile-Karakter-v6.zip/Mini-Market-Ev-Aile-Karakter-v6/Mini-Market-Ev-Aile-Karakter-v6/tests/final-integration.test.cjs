'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const bundled={};vm.runInNewContext(fs.readFileSync(path.join(root,'three-local.js'),'utf8'),{window:bundled,console,performance});const T=bundled.THREE;
function stubCtx(){return {fillRect(){},strokeRect(){},fillText(){},beginPath(){},arc(){},fill(){},lineTo(){},moveTo(){},stroke(){},closePath(){},createLinearGradient(){return {addColorStop(){}}}};}
function makeWorld(){
 const root=new T.Group(),scene=new T.Scene(),hitboxes=[],colliders=[];
 return {root,scene,hitboxes,colliders,homeEast:{plug:{visible:true},collider:{minX:19,maxX:19.2,minZ:1.5,maxZ:3.3}},
  b(sx,sy,sz,x,y,z,c,o={}){const m=new T.Mesh(new T.BoxGeometry(1,1,1),new T.MeshBasicMaterial());m.scale.set(sx,sy,sz);m.position.set(x,y+sy/2,z);(o.parent||root).add(m);return m;},
  geo(name){return name==='plane'?new T.PlaneGeometry(1,1):new T.BoxGeometry(1,1,1);},
  mat(){return new T.MeshBasicMaterial();},canvasTex(w,h,draw){draw(stubCtx(),w,h);return new T.Texture();},mergeStatic(){},
  addInteractable(o){const m=new T.Mesh(new T.BoxGeometry(1,1,1),new T.MeshBasicMaterial());m.scale.set(o.box[0],o.box[1],o.box[2]);m.position.set(o.box[3],o.box[4]+o.box[1]/2,o.box[5]);m.userData.interactable=o;root.add(m);hitboxes.push(m);},update(){return 42;}};
}
function human(){return {group:new T.Group(),lowGroup:new T.Group(),armL:new T.Group(),armR:new T.Group(),legL:new T.Group(),legR:new T.Group(),elbowL:new T.Group(),elbowR:new T.Group(),walk(){}};}
function gameWithWorld(w){return {world:w,state:'playing',data:{money:3000,homeExpansion:{owned:false,room1:false,room2:false,decor:false},cafe:{drinks:0}},
 player:{pos:{x:0,z:0},vel:{x:0,z:0},setPosition(x,z){this.pos.x=x;this.pos.z=z;},update(){}},fpsCam:{yaw:0,eyeHeight:1.62,setAngles(y){this.yaw=y;},update(){}},
 ui:{lang:'tr',toast(){}},audio:{play(){}},setInputLocked(){},currentAction(){return null},toMenu(){this.state='menu'},saveNow(){this.saved=(this.saved||0)+1;}};}
const doc={head:{appendChild(){}},body:{appendChild(){}},createElement(){return {style:{},classList:{add(){},remove(){},contains(){return false}},addEventListener(){},querySelector(){return {}},innerHTML:''};}};
function run(file,win,extra={}){vm.runInNewContext(fs.readFileSync(path.join(root,file),'utf8'),{window:win,document:doc,THREE:T,Math,Number,Object,Array,JSON,Set,Map,console,...extra},{filename:file});}
function homeExtension(win,regions){
 const html=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');const a=html.indexOf("__def('home', function () {"),b=html.indexOf('\n});',a)+4;assert.ok(a>=0&&b>a);let home;
 const TX={tr:{},en:{},az:{},ru:{}};
 vm.runInNewContext(html.slice(a,b),{window:win,document:doc,THREE:T,Math,Number,Object,Array,JSON,Set,Map,console,__def:(n,f)=>{home=f()},__req:(n)=>n==='player'?{REGIONS:regions}:{TX,makeT:()=>()=>''}});
 home.installHomeExtension(win.__mms);return home;
}


test('FINAL entry integrates the current second-market modules, casino, map, café, and home',()=>{
 const h=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');
 for(const n of ['city-traffic-yeni.js','city-signals-yeni.js','ikinci-market-computer.js','gym-interior.js','city-bus.js','casino-system.js','final-cafe.js']) assert.ok(h.includes(`src="${n}"`),n);
 for(const n of ['MMS_CASINO.build','MMS_CASINO.update','MMS_CASINO.safeSave','installHomeExtension',"'Casino', '🎰'","'Kafe', '☕'","id: 'home-door'"])assert.ok(h.includes(n),n);
 const map=require('../map-translations.js');for(const lang of ['tr','en','az','ru'])for(const n of ['Casino','Kafe'])assert.ok(map.place(lang,n));
});

test('home purchases use existing balance and correctly activate doorway, rooms and region',()=>{
 const w=makeWorld(),g=gameWithWorld(w),regions=[];w.colliders.push(w.homeEast.collider);
 const win={__mms:g,THREE:T,addEventListener(){}};
 homeExtension(win,regions);const api=win.MMS_HOME_FINAL;assert.ok(api);
 assert.equal(api.buy('room1'),false);g.data.money=1499;assert.equal(api.buy('owned'),false);assert.equal(g.data.money,1499);
 g.data.money=3000;assert.equal(api.buy('owned'),true);assert.equal(g.data.money,1500);assert.equal(w.homeEast.plug.visible,false);assert.ok(!w.colliders.includes(w.homeEast.collider));assert.equal(regions.length,3);assert.equal(api.inside(24,2),true);
 assert.equal(api.buy('room1'),true);assert.equal(api.buy('room2'),true);assert.equal(api.buy('decor'),true);assert.equal(g.data.money,650);assert.equal(g.saved,4);assert.equal(api.buy('decor'),false);
 g.data.homeExpansion={owned:false,room1:false,room2:false,decor:false};api.sync(g.data);assert.equal(w.homeEast.plug.visible,true);assert.ok(w.colliders.includes(w.homeEast.collider));assert.equal(regions.length,2);assert.equal(api.inside(24,2),false);
});

test('café drinks charge correctly, save, and refuse insufficient funds',()=>{
 const w=makeWorld(),g=gameWithWorld(w),people={buildHuman:human};const win={__mms:g,THREE:T,__mmsPeople:people,addEventListener(){}};
 run('final-cafe.js',win);const api=win.MMS_CAFE_FINAL;assert.equal(api.inspect().people,3);assert.equal(api.buy('coffee'),true);assert.equal(api.buy('tea'),true);assert.equal(api.buy('lemon'),true);assert.equal(g.data.money,2957);assert.equal(g.data.cafe.drinks,3);assert.equal(g.saved,3);g.data.money=1;assert.equal(api.buy('coffee'),false);assert.equal(api.buy('invalid'),false);assert.equal(g.data.cafe.drinks,3);
});

test('main save sanitizes and restores home and café data, including legacy saves',()=>{
 const h=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');const start=h.indexOf("__def('save', function () {");const end=h.indexOf("\n});",start)+4;assert.ok(start>=0&&end>start);let exported;
 const dep={cleanCounts:v=>v||{},starterFixtures:()=>[],cleanFixtures:v=>v,migrateShelves:()=>({fixtures:[],overflow:{}}),emptyLogistics:()=>({}),sanitizeLogistics:v=>v||{},defaultRegister:()=>({}),sanitizeRegister:v=>v||{}};
 vm.runInNewContext(h.slice(start,end),{__def:(n,f)=>{exported=f()},__req:()=>dep,navigator:{language:'tr'},localStorage:{getItem(){return null},setItem(){}},Number,Math,Object,Array,JSON});
 const v=exported.sanitizeGame({money:22,homeExpansion:{owned:true,room1:true,room2:false,decor:true},cafe:{drinks:4.7}});assert.equal(v.homeExpansion.owned,true);assert.equal(v.homeExpansion.room1,true);assert.equal(v.cafe.drinks,4);assert.equal(v.money,22);
 const old=exported.sanitizeGame({money:15});assert.equal(old.homeExpansion.owned,false);assert.equal(old.cafe.drinks,0);
});

test('all bus shelters face the road and each platform boards via its curb-side door',()=>{
 const w=makeWorld(),g=gameWithWorld(w),regions=[],traffic={bounds(x,z){return {minX:x-1,maxX:x+1,minZ:z-1,maxZ:z+1}},canSpawnAt(){return true},canMoveVehicle(){return true}};
 const people={buildHuman:human,SKINS:[0,1,2,3],HAIRS:[0,1,2,3]};
 const win={__mms:g,THREE:T,__cityTraffic:traffic,__mmsPeople:people,MMS_VEH:{},addEventListener(){}};
 run('city-bus.js',win,{__req:()=>({REGIONS:regions})});const api=win.__cityBus;assert.ok(api);const bus=api.bus;assert.equal(api.stops.length,5);
 for(let i=0;i<api.stops.length;i++){
   const stop=api.stops[i],p=api.pointAt(stop.distance);bus.group.position.set(p.x,0,p.z);bus.group.rotation.y=p.yaw;bus.stoppedAt=i;bus.doorsOpen=1;bus.doorTarget=1;
   const dx=stop.point[0]-stop.platform.x,dz=stop.point[1]-stop.platform.z,fx=-Math.sin(stop.shelterYaw),fz=-Math.cos(stop.shelterYaw);
   assert.ok(dx*fx+dz*fz>0,`stop ${i} faces road`);
   g.player.pos.x=stop.platform.x;g.player.pos.z=stop.platform.z;assert.equal(api.boardPlayer((i+1)%api.stops.length),true,`stop ${i} boarding`);assert.equal(g.playerAboard,true);api.exitPlayer();assert.equal(g.playerAboard,false);
 }
});

test('home sleep advances the day and restores the spouse and player camera',()=>{
 const h=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');const start=h.indexOf("__def('home', function () {");const end=h.indexOf("\n});",start)+4;assert.ok(start>=0&&end>start);
 const timers=[],fade={classList:{add(){},remove(){},toggle(){}}};let family={sleep:false},homeModule;
 const people={beginSleep(){family.sleep=true;return true;},endSleep(){family.sleep=false;}};
 const win={THREE:T,MMS_PEOPLE:people,MMS_HOME_FINAL:{inside(){return false}}};
 const depot={lg:{tick(){return []}},_onStatus(){},customers:{enabled:true,reset(){}},closeOverlays(){},dirty:false};
 const g={state:'playing',data:{day:1,shopClosed:true},clock:{minutes:1320,set(n){this.minutes=n}},world:{setShopOpen(){},setNight(){}},depot,player:{pos:{},setPosition(x,z){this.pos={x,z}}},fpsCam:{eyeHeight:1.62,setAngles(){}},ui:{lang:'tr',toast(){}},setInputLocked(){},saveNow(){this.saved=true}};
 vm.runInNewContext(h.slice(start,end),{window:win,THREE:T,MMS_PEOPLE:people,MMS_HOME_FINAL:win.MMS_HOME_FINAL,__def:(n,f)=>{homeModule=f()},__req:()=>({TX:{tr:{},en:{},az:{},ru:{}},makeT:()=>()=>''}),document:{getElementById:()=>fade},setTimeout:fn=>timers.push(fn),Math,Number,Object,Array,console});
 assert.equal(homeModule.inHouse(12,-100),false);assert.equal(homeModule.inHouse(12,0),true);
 const home=new homeModule.HomeSystem(g);home.closed=true;home.sleep(false);assert.equal(family.sleep,true);assert.equal(g.fpsCam.eyeHeight,.95);assert.equal(home.busy,true);
 while(timers.length)timers.shift()();assert.equal(family.sleep,false);assert.equal(g.data.day,2);assert.equal(g.clock.minutes,480);assert.equal(g.fpsCam.eyeHeight,1.62);assert.equal(g.saved,true);assert.equal(home.busy,false);
 g.data.day=3;g.clock.minutes=1320;home.sleep(false);assert.equal(family.sleep,true);home.reset();while(timers.length)timers.shift()();assert.equal(g.data.day,3,'stale sleep timers cannot advance another session');assert.equal(family.sleep,false);
});

test('scripted bus riders board and alight at their selected stop',()=>{
 const w=makeWorld(),g=gameWithWorld(w),regions=[],traffic={bounds(x,z){return {minX:x-1,maxX:x+1,minZ:z-1,maxZ:z+1}},canSpawnAt(){return true},canMoveVehicle(){return true}};
 const people={buildHuman:human,SKINS:[0,1,2,3],HAIRS:[0,1,2,3]};const win={__mms:g,THREE:T,__cityTraffic:traffic,__mmsPeople:people,MMS_VEH:{},addEventListener(){}};
 run('city-bus.js',win,{__req:()=>({REGIONS:regions})});const api=win.__cityBus,b=api.bus;
 function arrive(i){b.stoppedAt=-1;b.dwell=0;b.doorTarget=0;b.doorsOpen=0;b.nextStop=i;b.distance=api.stops[i].distance-.01;b.speed=1;w.update(.05,g.player.pos,true);assert.equal(b.stoppedAt,i);for(let n=0;n<300;n++)w.update(.05,g.player.pos,true);}
 arrive(0);assert.ok(b.boardedTotal>=1,'at least one waiting rider boarded: '+JSON.stringify(b.passengers.map(p=>({id:p.id,state:p.state,origin:p.origin,target:p.target,elapsed:p.elapsed}))));
 const rider=b.passengers.find(p=>p.state==='riding'&&p.target===2);assert.ok(rider,'rider for stop 2 is on board');
 arrive(2);assert.ok(b.alightedTotal>=1,'the rider alighted at target stop');
});

test('actual home colliders allow passage through the purchased extension doorway',()=>{
 const html=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');
 function section(name){const start=html.indexOf(`__def('${name}', function () {`),end=html.indexOf('\n});',start)+4;assert.ok(start>=0&&end>start);return html.slice(start,end);}
 let playerModule,homeModule;const win={THREE:T};const TGame={tr:{},en:{},az:{},ru:{}};
 const ctx={window:win,THREE:T,MMS_NIGHT:{reg:x=>x},__def:(n,f)=>{const out=f();if(n==='player')playerModule=out;else homeModule=out},__req:()=>({TX:TGame,makeT:()=>()=>''}),Math,Number,Object,Array,console};
 vm.runInNewContext(section('player'),ctx);vm.runInNewContext(section('home'),ctx);
 const w=makeWorld();w.colliders.length=0;w.ceilGroup=new T.Group();w.houseLights=[];
 w.mat=(color,o={})=>new T.MeshLambertMaterial({color,transparent:!!o.transparent||o.opacity<1,opacity:o.opacity??1});
 w.b=function(sx,sy,sz,x,y,z,color,o={}){
   const material=typeof color==='number'?w.mat(color,o):color;const m=new T.Mesh(new T.BoxGeometry(1,1,1),material);m.scale.set(sx,sy,sz);m.position.set(x,y+sy/2,z);(o.parent||w.root).add(m);
   const add=()=>w.colliders.push({minX:x-sx/2,maxX:x+sx/2,minZ:z-sz/2,maxZ:z+sz/2});
   if(o.collide)add();else if(!o.parent&&!o.dynamic&&!material.transparent&&y>=-.01&&y<=.16&&sy>=.5&&sx>=.38&&sz>=.38&&sx<=10&&sz<=8)add();return m;
 };
 w.cyl=(r,h,x,y,z,color,o={})=>w.b(r*2,h,r*2,x,y,z,color,{...o,parent:o.parent||w.root});
 w.put=(kind,sx,sy,sz,x,y,z,material,o={})=>w.b(sx,sy,sz,x,y-sy/2,z,material,{...o,parent:o.parent||w.root});
 w.sign=()=>new T.Mesh();w.canvasTex=(x,y,fn)=>{fn(stubCtx(),x,y);return new T.Texture();};
 homeModule.buildHome(w);const g=gameWithWorld(w);win.__mms=g;win.addEventListener=()=>{};
 homeExtension(win,playerModule.REGIONS);assert.equal(win.MMS_HOME_FINAL.buy('owned'),true);
 const p=new playerModule.Player(w.colliders);p.setPosition(18.2,2.4);for(let n=0;n<62;n++){p.pos.x+=.05;p._resolve();}assert.ok(p.pos.x>20.5,'player crosses east doorway');
 p.setPosition(24.4,1.0);for(let n=0;n<42;n++){p.pos.z-=.05;p._resolve();}assert.ok(p.pos.z<-.6,'player crosses to the second room');
});

test('new home furniture blocks the player and the eastern outside path stays connected',()=>{
 const html=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');
 const section=name=>{const a=html.indexOf(`__def('${name}', function () {`),b=html.indexOf('\n});',a)+4;assert.ok(a>=0&&b>a);return html.slice(a,b)};
 let pm,hm;const win={THREE:T};const ctx={window:win,THREE:T,MMS_NIGHT:{reg:x=>x},__def:(n,f)=>{const value=f();if(n==='player')pm=value;else hm=value},__req:()=>({TX:{tr:{},en:{},az:{},ru:{}},makeT:()=>()=>''}),Math,Number,Object,Array,console};
 vm.runInNewContext(section('player'),ctx);vm.runInNewContext(section('home'),ctx);
 const w=makeWorld();w.colliders.length=0;w.ceilGroup=new T.Group();w.houseLights=[];
 w.mat=(color,o={})=>new T.MeshLambertMaterial({color,transparent:!!o.transparent||o.opacity<1,opacity:o.opacity??1});
 w.b=function(sx,sy,sz,x,y,z,color,o={}){const material=typeof color==='number'?w.mat(color,o):color;const m=new T.Mesh(new T.BoxGeometry(1,1,1),material);m.scale.set(sx,sy,sz);m.position.set(x,y+sy/2,z);(o.parent||w.root).add(m);const add=()=>w.colliders.push({minX:x-sx/2,maxX:x+sx/2,minZ:z-sz/2,maxZ:z+sz/2});if(o.collide)add();else if(!o.parent&&!o.dynamic&&!material.transparent&&y>=-.01&&y<=.16&&sy>=.5&&sx>=.38&&sz>=.38&&sx<=10&&sz<=8)add();return m;};
 w.cyl=(r,h,x,y,z,c,o={})=>w.b(r*2,h,r*2,x,y,z,c,{...o,parent:o.parent||w.root});w.put=(k,sx,sy,sz,x,y,z,m,o={})=>w.b(sx,sy,sz,x,y-sy/2,z,m,{...o,parent:o.parent||w.root});w.sign=()=>new T.Mesh();
 hm.buildHome(w);const g=gameWithWorld(w);win.__mms=g;win.addEventListener=()=>{};homeExtension(win,pm.REGIONS);
 const player=new pm.Player(w.colliders);player.setPosition(30,6.4);for(let i=0;i<110;i++){player.pos.z-=.08;player._resolve();}assert.ok(player.pos.z < -1,'walkable east path connects from sidewalk');
 assert.equal(win.MMS_HOME_FINAL.buy('owned'),true);assert.equal(win.MMS_HOME_FINAL.buy('room1'),true);assert.equal(win.MMS_HOME_FINAL.buy('room2'),true);
 const shell=w.scene.getObjectByName('HOME EXTENSION');assert.ok(shell&&shell.visible);assert.ok(shell.children.some(m=>Math.abs(m.scale.x-9.8)<.01&&Math.abs(m.scale.z-10.2)<.01&&m.position.y<.2),'extension has a visible ground surface');
 player.setPosition(27.5,2);for(let i=0;i<35;i++){player.pos.x+=.05;player._resolve();}assert.ok(player.pos.x<28.7,'outer wall blocks escape');
 player.setPosition(25,-4.15);for(let i=0;i<40;i++){player.pos.x+=.05;player._resolve();}assert.ok(player.pos.x<26,'bed collider blocks penetration');
 assert.deepEqual(JSON.parse(JSON.stringify(win.MMS_HOME_FINAL.safeSave({x:23,z:2}))),{x:20.35,z:2.4});
 g.data.homeExpansion.owned=false;assert.deepEqual(JSON.parse(JSON.stringify(win.MMS_HOME_FINAL.safeLoad({x:23,z:2}))),{x:18.35,z:2.4});
});

test('reference-inspired women use articulated 3D rigs, preserve NPC ids, and family state round-trips',()=>{
 const html=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');
 const moduleBody=name=>{const a=html.indexOf(`__def('${name}', function () {`),b=html.indexOf('\n});',a)+4;assert.ok(a>=0&&b>a);return html.slice(a,b)};
 const win={THREE:T,MMS_NPC_TRANSLATIONS:{t:(lang,key)=>key},MMS_PEDESTRIAN_STEERING:{frame:()=>({}),choose:()=>({moved:false,arrived:false})}};
 let P;vm.runInNewContext(moduleBody('characters'),{window:win,THREE:T,__def:(n,f)=>{P=f()},Math,Map,Object,Array,Number,console});assert.ok(P.buildHuman);win.__mmsPeople=P;
 const records=new Map([['mms_rel_v1',JSON.stringify({rel:{w6:100},gf:'w6',married:'w6',children:[{name:'Mina',girl:true},{name:'Ege',girl:false}],familyState:{spouse:{state:'spouse_home',x:15.7,z:1.55},children:[{x:22.3,z:-2.3,phase:1},{x:22.2,z:2.3,phase:2}]}})]]);
 const storage={getItem:k=>records.get(k)||null,setItem:(k,v)=>records.set(k,v)};
 const srcStart=html.indexOf('window.MMS_PEOPLE = (() => {'),srcEnd=html.indexOf('\n</script>',srcStart);assert.ok(srcStart>=0&&srcEnd>srcStart);
 const veg={add(){},pick(){return 'oak'}},night={reg:m=>m,light(){},glow(){}};
 const globals={window:win,THREE:T,localStorage:storage,document:doc,MMS_VEG:veg,MMS_NIGHT:night,__req:()=>({inHouse:(x,z)=>x>7&&x<29&&z>-5&&z<5}),Math,Number,Object,Array,JSON,Set,Map,console};
 vm.runInNewContext(html.slice(srcStart,srcEnd),globals);const people=win.MMS_PEOPLE;assert.ok(people);
 const w=makeWorld();w.houseLights=[];w.cyl=(r,h,x,y,z,c,o={})=>w.b(r*2,h,r*2,x,y,z,c,o);w.put=(k,sx,sy,sz,x,y,z,c,o={})=>w.b(sx,sy,sz,x,y-sy/2,z,c,o);w.sign=()=>new T.Mesh();w.trafficCars=[];
 const g=gameWithWorld(w);g.data.homeExpansion={owned:true,room1:true,room2:true,decor:true};g.clock={minutes:720};g.player.pos={x:16,z:2};g.ui.setLanguage=function(lang){this.lang=lang};
 people.build(w,g);people.restoreFamilyState();assert.equal(people.family().children,2);assert.equal(people.family().married,true);
 const roster=people.womenRoster();assert.equal(roster.length,12);assert.equal(roster[0].shirt,0x1a1b1f);assert.equal(roster[1].shirt,0xf3f1ec);assert.equal(roster[2].shirt,0x7a1f32);assert.equal(roster[3].hairStyle,'bunFringe');
 const styled=[];w.root.traverse(x=>{if(x.userData.referenceStyle)styled.push(x)});assert.equal(styled.length,20,'all adult women in city and on park benches use the reference-derived rig');
 const styles=new Set(styled.map(x=>x.userData.referenceStyle));assert.equal(styles.size,4);for(const group of styled){let meshes=0;group.traverse(x=>{if(x.isMesh)meshes++});assert.ok(meshes>8);}
 const before=people.inspect().find(p=>p.id==='w6');assert.equal(before.state,'spouse_home');assert.equal(before.x,15.7);
 for(let i=0;i<80;i++)people.update(.05,g);const after=people.inspect().find(p=>p.id==='w6');assert.notEqual(after.x,before.x,'spouse moves while at home');
 people.saveFamilyState();let saved=JSON.parse(storage.getItem('mms_rel_v1'));assert.equal(saved.familyState.children.length,2);assert.equal(saved.familyState.spouse.state,'spouse_home');assert.ok(Number.isFinite(saved.familyState.children[0].x));
 assert.equal(people.beginSleep(),true);people.update(.05,g);assert.equal(people.inspect().find(p=>p.id==='w6').state,'spouse_sleep');const kids=w.root.children.filter(x=>Number.isInteger(x.userData.familyChildIndex));assert.equal(kids.length,2);assert.ok(kids.every(k=>Math.abs(k.rotation.x-Math.PI/2)<.001),'children sleep in their furnished rooms');people.endSleep();people.update(.05,g);assert.ok(kids.every(k=>Math.abs(k.rotation.x)<.001),'children wake and return to normal');people.saveFamilyState();saved=JSON.parse(storage.getItem('mms_rel_v1'));assert.equal(saved.familyState.spouse.state,'spouse_home');
 const adult=P.buildHuman({female:true,shirt:0x35554d,hair:0x3e302b,scale:1});assert.ok(adult.group.userData.referenceStyle,'ordinary adult women receive reference styling');
 const child=P.buildHuman({female:true,fit:{child:true},scale:.58});assert.equal(child.group.userData.referenceStyle,null,'children keep age-appropriate outfits');
 const worker=P.buildHuman({female:true,apron:0x1f8b40,scale:1});assert.equal(worker.group.userData.referenceStyle,null,'uniformed staff keep their uniforms');
 // Recreate the actual family module with the saved localStorage, as on reload.
 const win2={THREE:T,__mmsPeople:P,MMS_NPC_TRANSLATIONS:win.MMS_NPC_TRANSLATIONS,MMS_PEDESTRIAN_STEERING:win.MMS_PEDESTRIAN_STEERING};
 vm.runInNewContext(html.slice(srcStart,srcEnd),{...globals,window:win2});const people2=win2.MMS_PEOPLE;
 const w2=makeWorld();w2.houseLights=[];w2.cyl=(r,h,x,y,z,c,o={})=>w2.b(r*2,h,r*2,x,y,z,c,o);w2.put=(k,sx,sy,sz,x,y,z,c,o={})=>w2.b(sx,sy,sz,x,y-sy/2,z,c,o);w2.sign=()=>new T.Mesh();w2.trafficCars=[];
 const g2=gameWithWorld(w2);g2.data.homeExpansion={owned:true,room1:true,room2:true,decor:true};g2.clock={minutes:480};g2.player.pos={x:16,z:2};g2.ui.setLanguage=function(lang){this.lang=lang};
 people2.build(w2,g2);people2.restoreFamilyState();assert.equal(people2.family().children,2);const restored=people2.inspect().find(p=>p.id==='w6');assert.equal(restored.state,'spouse_home');assert.ok(Math.abs(restored.x-saved.familyState.spouse.x)<.001);
});
