'use strict';
// Exercise the real construction extension with minimal DOM/world substitutes.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const dictionary=require('../build-translations.js');
const languages=['tr','en','az','ru'];
const placeholders=s=>[...new Set([...s.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map(m=>m[1]))].sort().join(',');
for(const [key,rows] of Object.entries(dictionary.entries)){
  assert.equal(rows.length,4,`${key} has four languages`);
  for(const [i,row] of rows.entries()){
    assert.ok(typeof row==='string'&&row.trim(),`${key} empty ${languages[i]}`);
    assert.equal(placeholders(row),placeholders(rows[0]),`${key} placeholders differ`);
    assert.ok(!/\b(?:undefined|null)\b/.test(dictionary.t(languages[i],key)));
  }
}
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
assert.ok(html.indexOf('src="build-translations.js"')<html.indexOf('src="market-build.js"'),'dictionary loads before construction system');

class SiteUI {_renderNav(){}}
class DepotSystem {resolveAction(){}}
const fixtures=[];
const Save={load:()=>({fixtures:{}}),createNew:()=>({fixtures:{}}),write(){}};
const fakeNodes=Object.fromEntries(['editor','ground','upper','rotate','cancel','save','help'].map(k=>[k,{dataset:{buildText:k},textContent:''}]));
const classes=new Set();
const floor0={classList:{toggle(){}}},floor1={classList:{toggle(){}}};
const status={textContent:''},list={innerHTML:''},canvas={addEventListener(){}};
const editor={
  classList:{add(c){classes.add(c);},remove(c){classes.delete(c);},contains(c){return classes.has(c);}},
  addEventListener(){},querySelectorAll(){return Object.values(fakeNodes);},
  querySelector(sel){return {'#mb-map':canvas,'#mb-status':status,'#mb-items':list,'[data-mb="floor0"]':floor0,'[data-mb="floor1"]':floor1}[sel];}
};
const doc={head:{appendChild(){}},body:{appendChild(){}},createElement(tag){return tag==='div'?editor:{};}};
const storage={getItem(){return JSON.stringify({marketBuild:{upper:false,items:[{id:'build_1',type:'shelf',x:1,z:1,floor:0,rot:0}]},upgrades:[]});}};
const site={root:{addEventListener(){}},isOpen:false,close(){},retext(){this.retextCount=(this.retextCount||0)+1;},render(){this.renderCount=(this.renderCount||0)+1;},_snack(v){this.snack=v;}};
class Group {
  constructor(){this.children=[];this.userData={};this.position={set(x,y,z){this.x=x;this.y=y;this.z=z;}};this.scale={set(x,y,z){this.x=x;this.y=y;this.z=z;}};}
  add(x){this.children.push(x);}
}
class Mesh extends Group {constructor(geometry,material){super();this.geometry=geometry;this.material=material;}}
const game={
  ui:{lang:'tr',setLanguage(lang){this.lang=lang;},toast(){}},fpsCam:{update(){}},
  depot:{site,attach(){},reset(){}},expand:{applyWorld(){}},audio:{play(){}},
  player:{pos:{x:0,z:0}},world:{colliders:[],hitboxes:[],geo:()=>({}),canvasTex:()=>({})},saveNow(){this.saveCount=(this.saveCount||0)+1;},setInputLocked(){}
};
const window={__mms:game,THREE:{MeshLambertMaterial:class {},MeshBasicMaterial:class {constructor(opts){this.opts=opts;}},Group,Mesh,DoubleSide:2},MMS_BUILD_TRANSLATIONS:dictionary,addEventListener(){}};
const modules={save:{Save},fixtures:{FIXTURES:fixtures},expand:{effectsFor:()=>({mult:1}),backDepth:ups=>ups?.includes('back2')?6:ups?.includes('back1')?3:0},site:{SiteUI},depot:{DepotSystem},pathing:{findPath:(colliders,from,to)=>[{x:to.x,z:to.z}]}};
const ctx={window,document:doc,localStorage:storage,__req:name=>modules[name],MMS_NIGHT:{reg:m=>m},console,Math,JSON,Set};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','market-build.js'),'utf8'),ctx,{filename:'market-build.js'});
const feature=game.marketBuild;
assert.ok(feature,'construction module loads');
feature.data={money:1000,upgrades:[],marketBuild:{upper:false,items:[],seq:1},fixtures:{}};
feature.draw=()=>{};
const nav={page:'build',$nav:{insertAdjacentHTML(_,s){this.html=s;}}};
for(const lang of languages){
  game.ui.setLanguage(lang);
  SiteUI.prototype._renderNav.call(nav);
  assert.ok(nav.$nav.html.includes(dictionary.t(lang,'title')),`${lang} navigation translated`);
  const html=feature.catalogHTML();
  assert.ok(html.includes(dictionary.t(lang,'shelf')),`${lang} shelf translated`);
  assert.ok(html.includes(dictionary.t(lang,'openEditor')),`${lang} placement button translated`);
}
feature.open();
for(const lang of languages){
  game.ui.setLanguage(lang);
  assert.equal(fakeNodes.editor.textContent,dictionary.t(lang,'editor'),`${lang} open editor refreshed`);
  assert.equal(fakeNodes.help.textContent,dictionary.t(lang,'help'),`${lang} editor instructions refreshed`);
  assert.equal(feature.data.money,1000,'language change preserves balance');
}
feature.setStatus('chooseFirst');
game.ui.setLanguage('ru');
assert.equal(status.textContent,dictionary.t('ru','chooseFirst'),'open status refreshes in Russian');
const buy={disabled:false,dataset:{act:'mb-buy',kind:'shelf'}};
feature.siteClick({target:{closest(){return buy;}}});
assert.equal(feature.data.money,820,'item purchase retains its original price');
assert.equal(feature.data.marketBuild.items[0].id,'build_1','item uses original save schema');
assert.ok(site.snack.includes(dictionary.t('ru','shelf')),'purchase notification translated');
feature.updateEditor();
assert.ok(list.innerHTML.includes(dictionary.t('ru','inventory')),'inventory translated');
Save.load();
assert.equal(fixtures.length,1,'existing fixture restored');
assert.equal(fixtures[0].name.en,dictionary.t('en','shelf'),'stored fixture has English name');
assert.equal(fixtures[0].name.ru,dictionary.t('ru','shelf'),'stored fixture has Russian name');
feature.group=new Group();
feature.buildLockedPreview(0,false);
const preview=feature.group.children[0];
assert.equal(preview.name,'LOCKED MARKET EXPANSION PREVIEW');
assert.ok(preview.children.length>25,'locked preview has walls, floors and window geometry');
assert.ok(preview.children.some(m=>m.position.y>3.2),'upper floor is visible before buying');
assert.ok(preview.children.some(m=>m.position.y<1),'rear hall floor is visible before buying');
assert.equal(game.world.colliders.length,0,'preview adds no new gameplay collision');
feature.group=new Group();feature.buildLockedPreview(6,true);
assert.equal(feature.group.children.length,0,'preview is removed after both areas are purchased');
feature.group=new Group();
const frames=[];feature.box=(parent,x,y,z,...rest)=>{frames.push({x,y,z});};
feature.buildRearUpperFacade(-11.2);
assert.equal(frames.length,24,'rear facade has six complete window frames');
assert.ok(frames.every(f=>Math.abs(f.z-(-11.32))<1e-9),'frames are at the rear facade rather than the shop interior');
feature.data={money:5000,upgrades:['back1'],marketBuild:{upper:false,items:[],seq:1},fixtures:{}};
feature.rebuild=()=>{};
const upperButton={disabled:false,dataset:{act:'mb-upper'}};
feature.siteClick({target:{closest:()=>upperButton}});
assert.equal(feature.data.marketBuild.upper,false,'cannot buy upper floor before second rear expansion');
assert.equal(feature.data.money,5000,'blocked purchase does not charge money');
feature.data.upgrades=['back1','back2'];
feature.siteClick({target:{closest:()=>upperButton}});
assert.equal(feature.data.marketBuild.upper,true,'upper floor opens after purchase');
assert.equal(feature.data.money,1500,'upper floor retains original $3500 price');
feature.data.marketBuild.items=[{id:'build_8',type:'shelf',x:-2,z:-7,floor:1,rot:0}];
feature.upperCols=[];
const route=feature.workerRoute({x:-5.6,z:3.2,y:0},'build_8');
assert.ok(route&&route.length>5&&route.some(p=>p.y===3.2),'worker route reaches upper floor by stairs');
game.player.setPosition=(x,z)=>{game.player.pos={x,z};};
feature.finishStairs(true);
assert.ok(game.player.marketUpper&&game.fpsCam.eyeHeight===4.82,'stair interaction reaches purchased floor');
feature.finishStairs(false);
assert.equal(game.player.marketUpper,null,'stairs allow return to ground floor');
console.log(`OK: ${Object.keys(dictionary.entries).length} construction phrases, purchases, fixtures and preview/facade geometry`);
