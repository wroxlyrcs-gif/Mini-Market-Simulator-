'use strict';
// Runs the real workforce module with light stock and renderer substitutes.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
const fixtureList=[
  {id:'base',manualOnly:false},
  {id:'rear-shelf',manualOnly:true},
  {id:'upper-shelf',manualOnly:true}
];
const mods={
  cashier:{DENOMS:[],cashTotal:()=>0,available:()=>0},
  fixtures:{FIXTURES:fixtureList,accepts:()=>true},
  products:{getProduct:id=>({id})},
  expand:{backDepth:ups=>ups?.includes('back2')?6:ups?.includes('back1')?3:0}
};
let factory;
const sandbox={__def:(name,fn)=>{if(name==='workers')factory=fn;},__req:name=>mods[name],Math,Set,Map,console};
const start=html.indexOf("__def('workers', function () {"),end=html.indexOf("\n__def('world',",start);
assert.ok(start>=0&&end>start);
vm.runInNewContext(html.slice(start,end),sandbox);
const {Workforce,sanitizeWorkers,planShelving}=factory();
const data={money:1000,day:3,upgrades:[],marketBuild:{upper:false,items:[]}};
const wf=new Workforce(data),rand=()=>0.2;
assert.equal(wf.canHire('stocker','rear').reason,'rearLocked','rear hire unavailable before purchase');
assert.equal(wf.canHire('stocker','upper').reason,'upperLocked','upper hire unavailable before purchase');
assert.equal(wf.hire('stocker',rand,'upper').ok,false,'cannot bypass locked upper floor through direct hire');
const main=wf.hire('stocker',rand,'main');assert.equal(main.worker.zone,'main');
data.upgrades=['back1'];
const rear=wf.hire('stocker',rand,'rear');assert.equal(rear.worker.zone,'rear');
assert.equal(wf.canHire('stocker','upper').reason,'upperLocked');
data.upgrades=['back1','back2'];data.marketBuild.upper=true;
const upper=wf.hire('stocker',rand,'upper');assert.equal(upper.worker.zone,'upper');
assert.equal(wf.staff.length,3);assert.equal(wf.dailyCost(),75,'existing daily wage retained');
const fourth=wf.hire('stocker',rand,'rear');assert.equal(fourth.ok,true);
assert.equal(wf.canHire('stocker','upper').reason,'full','existing four-stocker limit remains');
const reloaded=sanitizeWorkers(JSON.parse(JSON.stringify(data.workers)),3);
assert.deepEqual(Array.from(reloaded.staff,s=>s.zone),['main','rear','upper','rear'],'chosen zones survive save/reload');
const old=sanitizeWorkers({staff:[{id:9,job:'stocker',name:'Old',wage:25},{id:10,job:'stocker',name:'Other',wage:25}]},3);
assert.deepEqual(Array.from(old.staff,s=>s.zone),['main','rearUpper'],'legacy missing zones remain compatible');
const poor={money:24,day:1,upgrades:['back1'],marketBuild:{upper:false}},poorWf=new Workforce(poor);
assert.equal(poorWf.canHire('stocker','rear').reason,'money','worker needs at least one day wage');
const lg={fixtureFree:()=>20,fixtureCount:()=>0,depotQty:()=>10};
const items=[{id:'rear-shelf',x:0,z:-7,floor:0,type:'shelf'},{id:'upper-shelf',x:0,z:-7,floor:1,type:'shelf'}];
const rearPlan=planShelving(lg,{milk:5},'rear',items),upperPlan=planShelving(lg,{milk:5},'upper',items);
assert.ok(rearPlan['rear-shelf']&&!rearPlan['upper-shelf']&&!rearPlan.base,'rear worker stocks only rear');
assert.ok(upperPlan['upper-shelf']&&!upperPlan['rear-shelf']&&!upperPlan.base,'upper worker stocks only upper');

// Exercise the real PC employee panel and hire handler without 3D rendering.
let translationFactory;
const txCtx={__def:(name,fn)=>{if(name==='i18n-workers')translationFactory=fn;}};
const txStart=html.indexOf("__def('i18n-workers', function () {"),txEnd=html.indexOf("\n__def('",txStart+1);
vm.runInNewContext(html.slice(txStart,txEnd),txCtx);
const {makeWT}=translationFactory();
const workerCtx={...sandbox,makeWT,JOBS:factory().JOBS,JOB_IDS:factory().JOB_IDS,
  esc:s=>String(s),cap:s=>s[0].toUpperCase()+s.slice(1),jobKey:s=>'job'+s[0].toUpperCase()+s.slice(1)};
const uiStart=html.indexOf('class WorkersFeature {'),uiEnd=html.indexOf('\n// ---------------------------------------------------------------- bağlantı',uiStart);
assert.ok(uiStart>0&&uiEnd>uiStart);
vm.runInNewContext(html.slice(uiStart,uiEnd)+'\nglobalThis.WorkersFeature=WorkersFeature;',workerCtx);
const feature=Object.create(workerCtx.WorkersFeature.prototype);
const g={ui:{lang:'tr',toast(){}},audio:{play(){}},depot:{dirty:false,site:{isOpen:false,_snack(){}}},saveNow(){this.saves=(this.saves||0)+1;}};
const udata={money:1000,day:1,upgrades:[],marketBuild:{upper:false}};
feature.g=g;feature.data=udata;feature.wf=new Workforce(udata);feature.t=makeWT(()=>g.ui.lang);feature.armed=null;
feature.sync=()=>{};feature.refreshTab=()=>{};
let panel=feature.tabHTML();
assert.match(panel,/data-zone="main"[^>]*>/);
assert.match(panel,/data-zone="rear"[^>]*disabled/);
assert.match(panel,/data-zone="upper"[^>]*disabled/);
assert.ok(panel.includes('Önce arka salonu satın al.')&&panel.includes('Önce üst katı inşa et.'));
udata.upgrades=['back1','back2'];udata.marketBuild.upper=true;
panel=feature.tabHTML();
assert.ok(!/data-zone="upper"[^>]*disabled/.test(panel),'upper button enabled after purchase');
feature.onClick({target:{closest:()=>({disabled:false,dataset:{act:'w-hire',job:'stocker',zone:'upper'}})}});
assert.equal(feature.wf.staff[0].zone,'upper','clicked upper-floor button hires an upper worker');
assert.equal(g.saves,1,'hiring saves the existing game');
for(const lang of ['tr','en','az','ru']){g.ui.lang=lang;panel=feature.tabHTML();assert.ok(panel.includes(feature.t('wChooseZone')),`${lang} zone choices translated`);}
console.log('OK: PC zone buttons, locked areas, wages, legacy saves and zone-specific shelf plans');
