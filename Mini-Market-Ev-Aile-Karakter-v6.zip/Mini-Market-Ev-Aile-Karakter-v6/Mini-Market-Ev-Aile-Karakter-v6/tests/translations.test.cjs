'use strict';
// Node-only checks: actual language dictionaries and NPC interaction code.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'mini-market-simulator.html'),'utf8');
const npc=require('../npc-translations.js');
const languages=['tr','en','az','ru'];
const placeholders=s=>[...new Set([...s.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map(m=>m[1]))].sort().join(',');

for(const [key,row] of Object.entries(npc.entries)){
  for(const language of languages){
    assert.equal(typeof row[language],'string',`${key} missing ${language}`);
    assert.ok(row[language].trim(),`${key} empty ${language}`);
    assert.equal(placeholders(row[language]),placeholders(row.tr),`${key} placeholders differ in ${language}`);
    assert.ok(!/\b(?:undefined|null)\b/.test(npc.t(language,key)),`${key} exposes invalid text`);
  }
}
for(const language of languages){
  const child=npc.t(language,'childJoined',{name:'Mina',n:2});
  assert.ok(child.includes('Mina')&&child.includes('2'),`${language} retains child and count`);
  assert.ok(!/\{[^{}]+\}/.test(child),`${language} has no leftover placeholders`);
  assert.ok(npc.t(language,'unknown-key').length>0,'unknown key has visible fallback');
}
assert.ok(html.includes('<script src="npc-translations.js"></script>'),'NPC translations are bundled in the HTML');

// Load the unchanged in-game catalogue modules, not a re-created dictionary.
const sandbox={};
vm.runInNewContext('var __defs={},__mods={};function __def(n,f){__defs[n]=f}; function __req(n){return __mods[n]||(__mods[n]=__defs[n]())}',sandbox);
const defs=['i18n-az','i18n-ru','i18n-home','i18n-depot','i18n-expand','i18n-workers'];
for(const name of defs){
  const start=html.indexOf(`__def('${name}', function () {`);
  assert.ok(start>=0,`module ${name} exists`);
  const end=html.indexOf("\n__def('",start+1);
  assert.ok(end>start,`module ${name} has an end`);
  vm.runInNewContext(html.slice(start,end),sandbox,{filename:name});
}
const catalogues=[['i18n-depot','TX'],['i18n-expand','XTX'],['i18n-home','HOME_TX'],['i18n-workers','WTX']];
for(const [module,name] of catalogues){
  const cat=sandbox.__req(module)[name];
  const all=[...new Set(languages.flatMap(lang=>Object.keys(cat[lang])))];
  for(const key of all)for(const lang of languages){
    assert.equal(typeof cat[lang][key],'string',`${module}.${key} missing ${lang}`);
    assert.ok(cat[lang][key].trim(),`${module}.${key} empty ${lang}`);
    assert.equal(placeholders(cat[lang][key]),placeholders(cat.tr[key]),`${module}.${key} placeholders differ in ${lang}`);
  }
}
const uiStart=html.indexOf('const STR = {',html.indexOf("__def('ui',"));
const uiEnd=html.indexOf('\n};',uiStart);
assert.ok(uiStart>0&&uiEnd>uiStart,'UI dictionary found');
const uiCat=vm.runInNewContext(`(${html.slice(uiStart+'const STR = '.length,uiEnd+2)})`);
const uiKeys=[...new Set(languages.flatMap(lang=>Object.keys(uiCat[lang])))];
for(const key of uiKeys)for(const lang of languages)
  assert.ok(typeof uiCat[lang][key]==='string'&&uiCat[lang][key].trim(),`UI ${key} missing ${lang}`);
for(const match of html.matchAll(/data-i18n="([^"]+)"/g))
  for(const lang of languages)assert.ok(uiCat[lang][match[1]],`data-i18n ${match[1]} missing ${lang}`);
const moduleStart=html.indexOf("__def('ui', function () {"),moduleEnd=html.indexOf("\n__def('",moduleStart+1);
sandbox.setTimeout=()=>0;sandbox.clearTimeout=()=>{};
vm.runInNewContext(html.slice(moduleStart,moduleEnd),sandbox);
const UI=sandbox.__req('ui').UI,toastElement={textContent:'',classList:{add(){},remove(){}}};
const fakeUI={lang:'tr',$:()=>toastElement,pick:UI.prototype.pick};
const message={tr:'İndin',en:'Exited',az:'Düşdün',ru:'Вы вышли'};
for(const lang of languages){fakeUI.lang=lang;UI.prototype.toast.call(fakeUI,message);assert.equal(toastElement.textContent,message[lang],`${lang} notification picks language`);}

// Run actual NPC open/render callbacks with a minimal DOM, without WebGL.
const buttons=[];
const panel={
  style:{},addEventListener(){},_html:'',
  set innerHTML(value){this._html=value;buttons.length=0;},get innerHTML(){return this._html;},
  querySelector(selector){if(selector==='.x')return {};if(selector==='.grid')return {appendChild(b){buttons.push(b);}};throw Error(selector);}
};
const document={
  head:{appendChild(){}},body:{appendChild(){}},
  createElement(tag){if(tag==='div')return panel;return {style:{},addEventListener(){}};}
};
const storage={data:{},getItem(k){return this.data[k]||null;},setItem(k,v){this.data[k]=v;}};
const win={MMS_NPC_TRANSLATIONS:npc};
const ctx={window:win,document,localStorage:storage,Math,THREE:{},console};
let start=html.indexOf('window.MMS_PEOPLE = (() => {'),end=html.indexOf('\n</script>',start);
assert.ok(start>=0&&end>start,'NPC module found');
let code=html.slice(start,end);
const anchor='return { build, update, inspect: () => people.map';
assert.ok(code.includes(anchor),'NPC test injection point exists');
code=code.replace(anchor,"return { __test:{setContext(w,g){W=w;G=g;bindLanguageRefresh();},open,render,setStore(s){store=s;}}, build, update, inspect: () => people.map");
vm.runInNewContext(code,ctx,{filename:'npc-module'});
const test=win.MMS_PEOPLE.__test;
const world={hooks:{say(){}},trafficCars:[]};
const game={ui:{lang:'tr',setLanguage(lang){this.lang=lang;}},data:{money:1000},saveNow(){},clock:{minutes:600}};
const p={id:'p1',name:'Ayşe',state:'route',girl:true,rel:0,cd:0,h:{setMood(){}},heart:{visible:false}};
test.setContext(world,game);
test.open(p);
const chosen=Object.keys(npc.entries).find(k=>k.startsWith('greeting')&&panel.innerHTML.includes(npc.entries[k].tr));
assert.ok(chosen,'NPC greeting is shown');
assert.ok(buttons.some(b=>b.textContent===npc.t('tr','chat')),'Turkish chat button is shown');
for(const lang of ['en','az','ru','tr']){
  game.ui.setLanguage(lang);
  assert.ok(panel.innerHTML.includes(npc.entries[chosen][lang]),`open greeting refreshes in ${lang}`);
  assert.ok(panel.innerHTML.includes(npc.t(lang,'acquaintance')),`relationship status translates in ${lang}`);
  assert.ok(buttons.some(b=>b.textContent===npc.t(lang,'coffee')),`coffee button translates in ${lang}`);
  assert.equal(game.data.money,1000,'changing language does not change game money');
}
const coffee=buttons.find(b=>b.textContent===npc.t('tr','coffee'));
coffee.onclick();
assert.equal(game.data.money,980,'coffee interaction still charges its original price');
assert.equal(p.rel,8,'coffee interaction still increases relationship');
assert.ok(panel.innerHTML.includes(npc.t('tr','coffeeThanks')),'coffee result is translated');
game.ui.setLanguage('ru');
assert.ok(panel.innerHTML.includes(npc.t('ru','coffeeThanks')),'open result refreshes when language changes');
test.setStore({rel:{p1:95},gf:'p1',married:'p1',children:[]});p.rel=95;p.state='spouse_home';
test.open(p);
assert.ok(panel.innerHTML.includes(npc.t('ru','spouse')),'spouse status translates');
assert.ok(buttons.some(b=>b.textContent===npc.t('ru','familyTime')),'family action translates');
test.render('childJoined',{name:'Mina',n:2});
assert.ok(panel.innerHTML.includes('Mina')&&panel.innerHTML.includes('2'),'family message uses values');
game.ui.setLanguage('az');
assert.ok(panel.innerHTML.includes(npc.t('az','childJoined',{name:'Mina',n:2})),'family message refresh preserves values');

// Actual car helper uses the four provided translations and localized names.
start=html.indexOf('window.MMS_CARS = (() => {');end=html.indexOf('\n</script>',start);
assert.ok(start>=0&&end>start,'car module found');
vm.runInNewContext(html.slice(start,end),ctx,{filename:'car-module'});
const exit=win.MMS_CARS.exitAction({}).label;
assert.equal(exit.az,'Maşından düş');assert.equal(exit.ru,'Выйти из машины');
assert.equal(win.MMS_CARS.carName({id:'taxi',name:'Sarı Taksi'},'ru'),'Жёлтое такси');
assert.equal(win.MMS_CARS.carName({id:'taxi',name:'Sarı Taksi'},'en'),'Yellow Taxi');
console.log(`OK: ${Object.keys(npc.entries).length} NPC translations, existing catalogues, live language switching and car labels`);
