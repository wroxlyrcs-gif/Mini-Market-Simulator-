'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
let factory;
const sandbox={__def:(name,fn)=>{if(name==='expand')factory=fn;},__req:name=>name==='fixtures'?{FIXTURES:[]}:{CFG:{departDelay:10,travelBase:12,maxOrderUnits:100,line:20}},Math,Set,Object,Number};
const start=html.indexOf("__def('expand', function () {"),end=html.indexOf("\n__def('fixtures',",start);
vm.runInNewContext(html.slice(start,end),sandbox);
const expand=factory(),data={money:5000,upgrades:[]};
assert.equal(expand.backDepth(data.upgrades),0);
assert.equal(expand.buy(data,'back').ok,true);
assert.equal(expand.backDepth(data.upgrades),3);
assert.equal(data.money,4400);
assert.equal(expand.buy(data,'back').ok,true);
assert.equal(expand.backDepth(data.upgrades),6);
assert.equal(data.money,3200);
assert.deepEqual(Array.from(data.upgrades),['back1','back2'],'expansion retains existing save schema');
const reload=JSON.parse(JSON.stringify(data));assert.equal(expand.backDepth(reload.upgrades),6,'purchased depth survives serialization');

// Exercise the real World.setBackDepth method with simple geometry substitutes.
const methodStart=html.indexOf('  setBackDepth(d) {'),methodEnd=html.indexOf('\n  _buildBackHall(d)',methodStart);
assert.ok(methodStart>=0&&methodEnd>methodStart);
const WorldStub=vm.runInNewContext('class WorldStub {'+html.slice(methodStart,methodEnd)+'}; WorldStub');
const collider={},mesh={visible:true};
const world={backPlug:{meshes:[mesh],collider},_backDepth:-1,colliders:[collider],_extColliders:[],
  scene:{remove(){}},ceilGroup:{remove(){}},_buildBackHall(d){this.builtDepth=d;}};
WorldStub.prototype.setBackDepth.call(world,0);
assert.equal(mesh.visible,true);assert.ok(world.colliders.includes(collider),'locked rear wall remains solid');
WorldStub.prototype.setBackDepth.call(world,3);
assert.equal(mesh.visible,false);assert.ok(!world.colliders.includes(collider),'purchase opens rear wall collider');
assert.equal(world.builtDepth,3,'purchased rear hall is constructed');
WorldStub.prototype.setBackDepth.call(world,0);
assert.equal(mesh.visible,true);assert.ok(world.colliders.includes(collider),'wall closes correctly for unexpanded saves');
console.log('OK: rear expansion pricing, save format and locked/unlocked back wall');
