'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
for (const name of ['mini-market-final.html', 'mini-market-ikinci-market.html']) {
  const html = fs.readFileSync(path.join(root, name), 'utf8');
  assert.doesNotMatch(html, /x <= 3\.1; x \+= 0\.9\) w\.b\(0\.48, 0\.025, 2\.6, x, 0\.215, 16\.0/, `${name}: z=16 zebra stripes removed`);
  const node = html.split('\n').find(l => l.includes('const NODE ='));
  assert.ok(node && !/\bB: \[0, 16\]/.test(node), `${name}: no pedestrian node in the middle of the stadium road`);
  const edge = html.split('\n').find(l => l.includes('const EDGE ='));
  assert.ok(edge && !/\['B', 'B[WE]'\]/.test(edge), `${name}: no pedestrian edge across the stadium road`);
  assert.match(html, /const COMP = \{\}/, `${name}: pedestrians choose destinations on their own side`);
  assert.match(html, /m\.castShadow = false; \/\/ gölge haritası/, `${name}: vehicles do not cast lagging shadow-map shadows`);
  assert.match(html, /blobShadow\(g, len, wid/, `${name}: vehicles use an attached soft shadow`);
}
const signals = fs.readFileSync(path.join(root, 'city-signals-yeni.js'), 'utf8');
assert.doesNotMatch(signals, /id:'avenue'/);
const bus = fs.readFileSync(path.join(root, 'city-bus.js'), 'utf8');
assert.match(bus, /mesh\.castShadow=false/);
assert.match(bus, /blobShadow\(root/);
// Both HTML entries stay identical.
assert.equal(fs.readFileSync(path.join(root, 'mini-market-final.html'), 'utf8'), fs.readFileSync(path.join(root, 'mini-market-ikinci-market.html'), 'utf8'));
console.log('OK: market-front crossing removed, soft vehicle shadows');
