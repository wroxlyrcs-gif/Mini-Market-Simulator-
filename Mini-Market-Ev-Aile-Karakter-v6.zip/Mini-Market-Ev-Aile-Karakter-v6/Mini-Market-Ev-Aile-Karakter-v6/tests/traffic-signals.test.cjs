'use strict';
// Run with: node tests/traffic-signals.test.cjs
// This tests the actual signal module with a small renderer/world substitute.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

class Obj {
  constructor() {
    this.children = [];
    this.position = {x:0,y:0,z:0,set(x,y,z){this.x=x;this.y=y;this.z=z;}};
    this.rotation = {x:0,y:0,z:0};
    this.userData = {};
  }
  add(...objects) { this.children.push(...objects); }
}
class Color { constructor(value){this.value=value;} setHex(value){this.value=value;} }
class Material { constructor({color}){this.color=new Color(color);} }
class Mesh extends Obj { constructor(geometry,material){super();this.geometry=geometry;this.material=material;} }
const THREE = {Group:Obj,Mesh,MeshBasicMaterial:Material,SphereGeometry:class {}};
const world = {
  scene:new Obj(),colliders:[],
  b(){return new Obj();},geo(){return {};},mergeStatic(){},update(){}
};
const window = {THREE,__cityTraffic:{},__mms:{world}};
const script=fs.readFileSync(path.join(__dirname,'..','city-signals.js'),'utf8');
vm.runInNewContext(script,{window,Math,Set,Map});
const s=window.__trafficSignals;
assert.equal(s.crossings.length,3, 'market-front crossing is removed');
assert.equal(s.phase(),'drive');
const car={group:{position:{x:-36.3,z:10.05}}};
const pedestrian={id:'test',x:-32.3,z:7.8};
assert.equal(s.mustStop(car,-36.1,10.05,0),false);
assert.equal(s.canPedestrianMove(pedestrian,-32.3,8.25),false);
s.step(16.5);
assert.equal(s.phase(),'amber');
assert.equal(s.mustStop(car,-36.1,10.05,0),true);
s.step(5);
assert.equal(s.phase(),'walk');
assert.equal(s.mustStop(car,-36.1,10.05,0),true);
world.colliders.push({trafficBody:true,minX:-33,maxX:-32,minZ:9,maxZ:11});
assert.equal(s.canPedestrianMove(pedestrian,-32.3,8.25),false);
world.colliders.length=0;
assert.equal(s.canPedestrianMove(pedestrian,-32.3,8.25),true);
pedestrian.z=9;
s.step(20);
assert.equal(s.phase(),'clear');
assert.equal(s.mustStop(car,-36.1,10.05,0),true);
pedestrian.z=15.3;
s.step(.1);
assert.equal(s.phase(),'drive');
assert.equal(s.mustStop(car,-36.1,10.05,0),false);
console.log('OK: phases, road clearance, pedestrian protection and vehicle stop/release');
