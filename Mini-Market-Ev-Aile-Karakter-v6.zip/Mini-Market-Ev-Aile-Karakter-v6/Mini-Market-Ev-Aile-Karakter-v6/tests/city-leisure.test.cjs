'use strict';
const assert=require('node:assert/strict');
const {PitchBall,result,install}=require('../city-leisure');
for(let p=0;p<3;p++)for(let q=0;q<3;q++){
  assert.equal(result(p,q),p===q?0:(p-q+3)%3===1?1:-1);
}
assert.equal(result(3,0),null);
const shot=new PitchBall();shot.kick({x:117,z:164});
for(let i=0;i<40;i++)shot.update(.05);
assert.ok(shot.x>118,'kick moves the ball');
shot.x=131.1;shot.z=164;shot.vx=9;shot.vz=0;
assert.equal(shot.update(.05),true,'ball scores between the posts');
assert.equal(shot.goals,1);assert.equal(shot.x,118);assert.equal(shot.z,164);
shot.x=133.2;shot.z=170;shot.vx=9;
assert.equal(shot.update(.05),false);assert.ok(shot.vx<0,'ball outside the goal bounces at boundary');
for(let i=0;i<1000;i++)shot.update(.05);
assert.ok(Number.isFinite(shot.x)&&shot.x>=102.7&&shot.x<=133.3);

class Obj {
  constructor(){this.position={x:0,y:0,z:0,set(x,y,z){this.x=x;this.y=y;this.z=z;}};this.rotation={x:0,y:0,z:0};this.scale={set(){}};this.userData={};this.children=[];}
  add(o){this.children.push(o);}
}
class Node {
  constructor(){this.handlers={};this.classList={add(){},remove(){}};this.dataset={};this.textContent='';}
  addEventListener(k,f){this.handlers[k]=f;}
  appendChild(){}
}
let modal;
const doc={head:new Node(),body:new Node(),createElement(tag){
  const el=new Node();
  if(tag==='div'){
    modal=el;el.fields=Object.fromEntries(['h2','.status','.message','.again','.close'].map(k=>[k,new Node()]));
    el.buttons=[0,1,2].map(n=>{const b=new Node();b.dataset.choice=String(n);return b;});
    el.querySelector=k=>el.fields[k];el.querySelectorAll=()=>el.buttons;
  }
  return el;
}};
const hits=[],notices=[],world={scene:new Obj(),root:new Obj(),colliders:[],hitboxes:[],
  b(){return new Obj();},geo(){return {};},mat(){return {};},mergeStatic(){},
  addInteractable(o){hits.push(o);this.hitboxes.push(new Obj());},update(){return 42;}};
const locks=[];
const game={world,state:'playing',ui:{lang:'tr',toast:s=>notices.push(s)},player:{pos:{x:-10.4,z:29.4}},
  audio:{play(){}},setInputLocked:v=>locks.push(v),pause(){this.state='paused';},toMenu(){this.state='menu';}};
const win={__mms:game,THREE:{Group:Obj,Mesh:Obj},document:doc,addEventListener(){}};
const api=install(win);assert.ok(api);
assert.ok(hits.some(h=>h.id==='park-picnic'));
assert.ok(hits.some(h=>h.id==='park-table-game'));
assert.ok(hits.some(h=>h.id==='outskirts-football'));
assert.equal(api.startPicnic(),true);
for(let i=0;i<161;i++)assert.equal(world.update(.05),42);
assert.equal(api.inspect().picnicRemaining,0);
assert.ok(notices.some(s=>s.includes('Piknik bitti')));
game.player.pos={x:-10.4,z:29.4};api.startPicnic();game.player.pos.x=100;world.update(.05);
assert.equal(api.inspect().picnicRemaining,0,'picnic cancels if player leaves');
api.openGame();assert.equal(api.inspect().gameOpen,true);assert.equal(locks.at(-1),true);
for(let i=0;i<3;i++)modal.buttons[0].handlers.click();
assert.equal(api.inspect().round,3);
modal.buttons[0].handlers.click();assert.equal(api.inspect().round,3,'fourth round cannot be played');
game.pause();assert.equal(api.inspect().gameOpen,false);assert.equal(locks.at(-1),false);
console.log('OK: 3-round game, picnic completion/cancellation, football, goal and menu cleanup');
