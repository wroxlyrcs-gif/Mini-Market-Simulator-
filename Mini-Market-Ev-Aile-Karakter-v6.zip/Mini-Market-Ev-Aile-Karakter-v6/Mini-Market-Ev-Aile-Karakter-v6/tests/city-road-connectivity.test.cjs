'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'mini-market-ikinci-market.html'),'utf8');
const road=fs.readFileSync(path.join(root,'city-outskirts-guvenli.js'),'utf8');
assert.doesNotMatch(html,/id:\s*'city-carousel'/,'old carousel interaction is removed');
assert.match(html,/city-leisure\.js/,'activities are linked in the active build');
assert.match(road,/solid\(10, \.055, 56\.5, 155, \.02, 158\.25, asphalt\)/,'east link is constructed');
assert.match(road,/minX:\s*149\.5,\s*maxX:\s*160,\s*minZ:\s*120,\s*maxZ:\s*194/,'road is within a player region');
assert.match(road,/solid\(\.14, \.018, 2\.4, 36\.5, \.082, z, white\)/,'trunk lane paint is above the asphalt');
assert.match(road,/solid\(2\.4, \.018, \.13, x, \.082, 190, white\)/,'street lane paint is above the asphalt');

// Road footprints for the existing main road, both sides of the ring,
// stadium and two independent connections to the neighborhood.
const rects=[
  ['main',-70,70,8.5,14.5],['west-link',-79,-70,8.5,14.5],
  ['west-ring',-89,-79,-17,107],['north-ring',-89,154,-27,-17],
  ['south-ring',-89,154,107,117],['east-ring',144,154,-17,107],
  ['district',60,100,8.2,14.6],['police',99,147,8.2,14.6],
  ['stadium-entry',-3.5,3.5,11.65,41.1],['stadium-road',-3.5,43.75,41.1,46.5],
  ['stadium-parking',31.25,43.75,46.5,66],['stadium-rear',31.5,41.5,66,107],
  ['south-connector',31.5,41.5,117,120],['south-road',31.5,154,120,130],
  ['city-exit',31.5,41.5,130,230],['neighborhood',41.5,153,186.5,193.5],
  ['east-corner',154,160,120,130],['east-branch',150,160,130,186.5],
  ['east-end',153,160,186.5,193.5],
];
const touch=(a,b)=>a[1]<=b[2]&&a[2]>=b[1]&&a[3]<=b[4]&&a[4]>=b[3];
const seen=new Set([0]),queue=[0];
while(queue.length){const i=queue.shift();for(let j=0;j<rects.length;j++)if(!seen.has(j)&&touch(rects[i],rects[j])){seen.add(j);queue.push(j);}}
assert.equal(seen.size,rects.length,'main, ring, stadium and both neighborhood links form one network');
const branch=rects.find(r=>r[0]==='east-branch'),house=['house',140.9,149.1,174.6,181.4];
assert.equal(touch(branch,house),false,'new road does not run through the existing house');
assert.ok(.082>.015+.06,'lane paint is not buried in the trunk road');
assert.ok(.082>.01+.055,'lane paint is not buried in the side street');
const start=html.indexOf("__def('save', function () {"),end=html.indexOf("\n__def('site'",start);
assert.ok(start>=0&&end>start);
let save;
const sandbox={
  __def:(_name,f)=>{save=f();},
  __req:name=>name==='logistics'?{
    cleanCounts:x=>x||{},starterFixtures:()=>({}),cleanFixtures:x=>x||{},
    migrateShelves:()=>({fixtures:{},overflow:{}}),emptyLogistics:()=>({}),
    sanitizeLogistics:x=>x||{},
  }:{defaultRegister:()=>({}),sanitizeRegister:x=>x||{}},
  navigator:{language:'tr'},localStorage:{},Number,Math,Array,Object,JSON,
};
vm.runInNewContext(html.slice(start,end),sandbox);
const resumed=save.sanitizeGame({player:{x:158,z:190,yaw:0}});
assert.equal(resumed.player.x,158,'position on the added road survives load');
assert.equal(resumed.player.z,190,'outskirts position survives load');
const collisions=fs.readFileSync(path.join(root,'sehir-carpisma.js'),'utf8');
assert.match(collisions,/\[149\.5,160,120,194\]/,'new road receives the same tree-clearance protection');
console.log('OK: major road footprints connect, east link clears house, paint heights and carousel removal');
