'use strict';
// Node-only tests against the actual city-traffic-yeni.js with minimal world stubs.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

class Group {
  constructor() {
    this.position = {x:0,y:0,z:0,set(x,y,z){this.x=x;this.y=y;this.z=z;}};
    this.rotation = {x:0,y:0,z:0};
    this.userData = {};
    this.visible = true;
    this.children = [];
  }
  add(...items) { this.children.push(...items); }
}
const world = {
  scene:new Group(), root:new Group(), colliders:[], trafficCars:[],
  b(){return new Group();}, mergeStatic(){}, update(){}
};
const cars = {cars:[],driving:null,step(){},exit(){}};
const vehicles = {KINDS:{sedan:{len:4.5}},build(){return {wheels:[]};}};
const delivery = {truck:{group:new Group()},update(){},reset(){}};
const game = {world,player:{pos:{x:-9999,z:-9999}},depot:{delivery},audio:{play(){}}};
const window = {THREE:{Group},__mms:game,MMS_VEH:vehicles};
const sandbox = {window,MMS_CARS:cars,MMS_VEH:vehicles,__req:()=>({REGIONS:[]}),Math,Date,performance};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','city-traffic-yeni.js'),'utf8'),sandbox);
const traffic = window.__cityTraffic;
assert.ok(traffic, 'traffic controller loads');

// Isolate collision checks from generated route cars.
world.colliders.length=0;
const playerCar={s:{kind:'sedan'},group:new Group()};
const wall={minX:1002,maxX:1003,minZ:990,maxZ:1010};
world.colliders.push(wall);
assert.equal(traffic.canDrive(playerCar,999.6,1000,0,{x:999.6,z:1000}),true,'clear position remains driveable');
assert.equal(traffic.canDrive(playerCar,999.8,1000,0,{x:999.6,z:1000}),false,'cannot enter a wall');
assert.equal(traffic.canDrive(playerCar,1000.1,1000,0,{x:1000,z:1000}),false,'cannot move deeper when already overlapping');
assert.equal(traffic.canDrive(playerCar,999.9,1000,0,{x:1000,z:1000}),true,'can reverse out of an overlap');
assert.equal(traffic.canDrive(playerCar,1000,1000.1,0,{x:1000,z:1000}),true,'can slide parallel to a wall');

// Police merging across the road must consider an approaching public bus.
world.colliders.length=0;
assert.equal(traffic.laneGapClear(500),true,'empty road is clear');
const bus={group:new Group(),speed:6};
bus.group.position.set(480,0,10.05);
window.__cityBus={bus};
assert.equal(traffic.laneGapClear(500),false,'bus approaching the crossing blocks police merge');
bus.group.position.x=510;
assert.equal(traffic.laneGapClear(500),true,'bus already moving away does not block');
bus.group.position.x=495; bus.speed=0;
assert.equal(traffic.laneGapClear(500),false,'stopped bus near crossing blocks police merge');
bus.group.visible=false;
assert.equal(traffic.laneGapClear(500),true,'hidden bus does not block');
bus.group.visible=true; bus.group.position.x=520; bus.group.rotation.y=Math.PI; bus.speed=6;
assert.equal(traffic.laneGapClear(500),false,'bus approaching from the other lane direction blocks merge');

// Spawn checks and a long proposed bus-like move cannot skip a vehicle or wall.
delete window.__cityBus;
world.colliders.length=0;
const vehicle={group:new Group(),_nominal:5};
vehicle.group.position.set(0,0,50);
vehicle._trafficCol=Object.assign(traffic.bounds(0,50,0),{vehicleOwner:vehicle,trafficBody:true});
world.colliders.push(vehicle._trafficCol);
assert.equal(traffic.canSpawnAt(0,50,0,null),false,'occupied spawn is rejected');
assert.equal(traffic.canSpawnAt(0,50,0,vehicle),true,'vehicle ignores its own collider');
assert.equal(traffic.canSpawnAt(20,50,0,null),true,'empty spawn is accepted');
world.colliders.push({minX:6,maxX:6.3,minZ:49,maxZ:51});
assert.equal(traffic.canMoveVehicle(vehicle,12,50,0,.05),false,'swept movement cannot tunnel through a wall');

// An AI vehicle already intersecting the player may move away but must not
// keep moving further into the player.
world.colliders.length=0;
world.colliders.push(vehicle._trafficCol);
game.player.pos.x=2; game.player.pos.z=50;
assert.equal(traffic.canMove(vehicle,.1,50,0,.05),false,'AI cannot drive further into an overlapping player');
assert.equal(traffic.canMove(vehicle,-.1,50,0,.05),true,'AI can retreat from an overlapping player');
assert.equal(traffic.canMoveVehicle(vehicle,.1,50,0,.05),false,'bus-like vehicle cannot drive further into player');
vehicle.publicBus=true; game.playerAboard=true;
assert.equal(traffic.canMoveVehicle(vehicle,.1,50,0,.05),true,'a bus can move with its own passenger on board');
vehicle.publicBus=false; game.playerAboard=false;
game.player.pos.x=2.5;
assert.equal(traffic.canMove(vehicle,-.1,50,0,.05),true,'AI can leave the player safety margin');
assert.equal(traffic.canMove(vehicle,.1,50,0,.05),false,'AI cannot move toward a player in the safety margin');
game.player.pos.x=5;
assert.equal(traffic.canMoveVehicle(vehicle,3,50,0,.05),false,'swept vehicle cannot drive into a player');
game.player.pos.x=-9999; game.player.pos.z=-9999;

// Simulate a faster follower for two minutes through repeated road wrapping.
world.colliders.length=0; traffic.main.length=0; traffic.outer.length=0;
function makeMain(x,speed) {
  const car={group:new Group(),dir:1,speed,_nominal:speed,wheels:[]};
  car.group.position.set(x,0,40);
  car._trafficCol=Object.assign(traffic.bounds(x,40,0),{vehicleOwner:car,trafficBody:true});
  world.colliders.push(car._trafficCol);traffic.main.push(car);return car;
}
const waitingFollower=makeMain(0,6),waitingLeader=makeMain(7,6);
window.__trafficSignals={mustStop:car=>car===waitingLeader};
world.update(.05,game.player.pos,true);
assert.equal(traffic.AI_TCA.followingBlocked(waitingFollower,waitingFollower.group.position.x,40,0),true,
  'follower maintains extra distance when the lead vehicle is stopped at a signal');
window.__trafficSignals.mustStop=()=>false;
world.update(.05,game.player.pos,true);
assert.equal(traffic.AI_TCA.followingBlocked(waitingFollower,waitingFollower.group.position.x,40,0),false,
  'follower releases extra distance when lead vehicle moves again');
delete window.__trafficSignals;
world.colliders.length=0;traffic.main.length=0;
const stationaryLaneCar=makeMain(510,6);
stationaryLaneCar.group.position.z=10.05;
stationaryLaneCar._trafficActualSpeed=0;
assert.equal(traffic.laneGapClear(500),false,'police must detect a stopped car behind the crossing');
stationaryLaneCar._trafficActualSpeed=6;
assert.equal(traffic.laneGapClear(500),true,'car driving away no longer blocks the crossing');
world.colliders.length=0;traffic.main.length=0;
const follower=makeMain(-70,6),leader=makeMain(-63,4.5);
let followerDistance=0,stoppedFrames=0;
for(let i=0;i<2400;i++){
  const old=follower.group.position.x;
  world.update(.05,game.player.pos,true);
  const dx=follower.group.position.x-old;
  if(dx>0 && dx<1)followerDistance+=dx;
  if(dx===0)stoppedFrames++;
  const a=follower._trafficCol,b=leader._trafficCol;
  const overlapping=a.minX<b.maxX&&a.maxX>b.minX&&a.minZ<b.maxZ&&a.maxZ>b.minZ;
  assert.equal(overlapping,false,`moving cars overlap at frame ${i}`);
}
assert.ok(followerDistance>100,'follower continues travelling over the simulation');
assert.ok(stoppedFrames>0,'follower waits when the lead car is too close');

// Real traffic and signal modules cooperate: a car stops at amber/red and
// continues on the next green. Rendering remains a stub in this Node test.
world.colliders.length=0;traffic.main.length=0;traffic.outer.length=0;
class Color { constructor(v){this.value=v;} setHex(v){this.value=v;} }
class Material { constructor({color}){this.color=new Color(color);} }
class Mesh extends Group { constructor(geometry,material){super();this.geometry=geometry;this.material=material;} }
Object.assign(window.THREE,{Mesh,MeshBasicMaterial:Material,SphereGeometry:class {}});
world.geo=()=>({});
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','city-signals-yeni.js'),'utf8'),sandbox);
const signal=window.__trafficSignals;
const crossingCar=makeMain(-38,6);
crossingCar.group.position.z=10.05;traffic.sync(crossingCar);
signal.step(16.5);
for(let i=0;i<120;i++)world.update(.05,game.player.pos,true);
assert.ok(crossingCar.group.position.x<=-36.19,'car stops before the crossing on amber/red');
for(let i=0;i<350;i++)world.update(.05,game.player.pos,true);
assert.ok(crossingCar.group.position.x> -32,'car proceeds through crossing after green');
console.log('OK: player/vehicle safety, bus passenger, following, police merge, spawn, 120s traffic and live signal integration');
