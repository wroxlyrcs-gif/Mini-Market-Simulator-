'use strict';
const assert=require('node:assert/strict');
const steering=require('../pedestrian-steering.js');
const move=(p,target,people,colliders=[],signals=null)=>{
  const result=steering.choose(p,target.x,target.z,1.3,.05,steering.frame(people,colliders),signals);
  p.x=result.x;p.z=result.z;return result;
};
const first={id:'a',state:'route',x:-3,z:0},second={id:'b',state:'route',x:3,z:0},people=[first,second];
let closest=Infinity;
for(let i=0;i<500;i++){
  const f=steering.frame(people,[]);
  for(const [p,target] of [[first,{x:3,z:0}],[second,{x:-3,z:0}]]){
    const s=steering.choose(p,target.x,target.z,1.3,.05,f,null);p.x=s.x;p.z=s.z;
  }
  closest=Math.min(closest,Math.hypot(first.x-second.x,first.z-second.z));
}
assert.ok(closest>=steering.GAP-1e-6,`opposing pedestrians keep distance: ${closest}`);
assert.ok(Math.hypot(first.x-3,first.z)<.1&&Math.hypot(second.x+3,second.z)<.1,'opposing pedestrians pass and arrive');

const leader={state:'dwell',x:1,z:5},follower={state:'route',x:0,z:5};
for(let i=0;i<180;i++){
  move(follower,{x:3,z:5},[leader,follower]);
  assert.ok(Math.hypot(leader.x-follower.x,leader.z-follower.z)>=steering.GAP-1e-6,'stationary NPC retains distance');
}
assert.ok(follower.x>2.5,'follower can go around a stationary pedestrian');

const car={trafficBody:true,minX:0,maxX:3,minZ:9,maxZ:11},walker={state:'route',x:-1,z:10};
for(let i=0;i<200;i++){
  move(walker,{x:4,z:10},[walker],[car]);
  assert.ok(!(walker.x>car.minX-.28&&walker.x<car.maxX+.28&&walker.z>car.minZ-.28&&walker.z<car.maxZ+.28),'walker stays outside traffic body');
}
const signalWalker={state:'route',x:0,z:0};
const red={canPedestrianMove:()=>false};
assert.equal(move(signalWalker,{x:0,z:3},[signalWalker],[],red).moved,false,'red signal stops pedestrian');
assert.equal(move(signalWalker,{x:0,z:3},[signalWalker],[],{canPedestrianMove:()=>true}).moved,true,'walk signal lets pedestrian move');
const atTarget={state:'route',x:2,z:2};
assert.equal(move(atTarget,{x:2,z:2},[atTarget]).arrived,true,'zero-distance destination is safe');
const hidden={state:'inside',x:.3,z:0},outdoors={state:'route',x:0,z:0};
assert.equal(move(outdoors,{x:1,z:0},[hidden,outdoors]).moved,true,'indoor NPC does not block sidewalk');
console.log('OK: opposing and stationary walkers, traffic-body clearance, signals and zero-distance targets');
