'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'mini-market-ikinci-market.html'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'ikinci-market-computer.js'), 'utf8');
const build = fs.readFileSync(path.join(root, 'market-build.js'), 'utf8');
const core = html.slice(html.indexOf("__def('logistics'"), html.indexOf("__def('main'"));

assert.ok(html.indexOf('window.__MMS_SECOND_MARKET_FULL_SYSTEM=true;') < html.indexOf("__req('main');"),
  'second-store structure is configured before the world is built');
assert.match(html, /src="ikinci-market-computer\.js"/, 'full second-market computer module is loaded');
assert.match(bridge, /mms_citymarket_depot_v1/, 'second market has a separate persistent save');
assert.match(bridge, /fixtureFilter=f=>f\.id\.startsWith\('m2s_'\)/, 'second store stock is isolated to its fixtures');
assert.match(bridge, /new DepotSystem\(/, 'the shared depot engine is reused');
assert.match(bridge, /__MMS_CREATE_MARKET_BUILD/, 'the shared construction editor is reused');
assert.match(bridge, /__MMS_CREATE_WORKERS_FEATURE/, 'the shared workers system is reused');
assert.match(bridge, /site\.expandFeature=secondExpand/, 'the shared upgrade interface is bound to second-market data');
assert.match(build, /__MMS_CREATE_MARKET_BUILD/, 'shared construction factory is exported');
assert.match(core, /_fixtures\(\)/, 'logistics operations are scoped to data-owned fixtures');
assert.match(html, /__MMS_SECOND_MARKET_LEDGER\.credit\(n\)/, 'second-store daily income is credited to its own balance');

console.log('OK: second-market UI, independent save/fixtures, shared build/workers and wallet routing');
