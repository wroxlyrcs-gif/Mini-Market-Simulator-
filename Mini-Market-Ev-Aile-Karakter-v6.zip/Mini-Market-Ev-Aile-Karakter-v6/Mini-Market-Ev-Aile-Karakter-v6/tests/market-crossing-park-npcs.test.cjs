'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const htmlFiles = fs.readdirSync(root).filter(name => /^mini-market-.*\.html$/.test(name));
assert.ok(htmlFiles.length > 0, 'game HTML builds exist');
for (const name of htmlFiles) {
  const html = fs.readFileSync(path.join(root, name), 'utf8');
  const line = html.split('\n').find(row => row.includes('const DEST ='));
  assert.ok(line, `${name}: NPC destination list exists`);
  const nodes = [...line.matchAll(/\{ n: '([A-Z0-9]+)'/g)].map(match => match[1]);
  assert.equal(nodes.length, 10, `${name}: destination weighting has ten outcomes`);
  assert.equal(nodes.filter(node => ['L', 'M', 'N'].includes(node)).length, 4,
    `${name}: four of ten destination outcomes are in the park`);
  assert.match(html, /src="mobil-grafik\.js"/, `${name}: mobile graphics profile is linked`);
  assert.match(html, /src="crowd-chant\.js"/, `${name}: match chant module is linked`);
}

const signals = fs.readFileSync(path.join(root, 'city-signals.js'), 'utf8');
assert.doesNotMatch(signals, /id:\s*['"]market['"]/, 'legacy signal set has no market-front crossing');
assert.match(signals, /id:'avenue'/, 'stadium-road crossing remains');

const chant = fs.readFileSync(path.join(root, 'crowd-chant.js'), 'utf8');
assert.match(chant, /new Audio\('stadium-chant\.mp3'\)/, 'match chant audio is connected');
assert.match(chant, /m >= 1180 && m < 1320/, 'chant is limited to match hours');
assert.ok(fs.existsSync(path.join(root, 'stadium-chant.mp3')), 'chant audio file is bundled');

console.log('OK: market crossing removed, park destination weighting, mobile graphics, match audio');
