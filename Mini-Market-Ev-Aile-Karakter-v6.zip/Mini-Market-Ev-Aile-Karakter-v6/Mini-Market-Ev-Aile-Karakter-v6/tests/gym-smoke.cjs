'use strict';
// Optional browser test: install Playwright separately, then run
// node tests/gym-smoke.cjs. The game itself does not require Playwright.
const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('playwright');

(async()=>{
  const browser=await chromium.launch({headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const page=await browser.newPage({viewport:{width:844,height:390},deviceScaleFactor:2,isMobile:true,hasTouch:true});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.context().setOffline(true);
  await page.addInitScript(()=>{window.requestAnimationFrame=()=>0;});
  await page.route('**/*',r=>r.request().url().startsWith('http')?r.abort():r.continue());
  await page.goto(pathToFileURL(path.join(__dirname,'..','mini-market-simulator.html')).href,{waitUntil:'domcontentloaded'});
  const result=await page.evaluate(async()=>{
    const g=window.__mms;await g.onNew();
    const tick=seconds=>{for(let n=0;n<Math.ceil(seconds/.05);n++)g.world.update(.05,g.player.pos,true);};
    const move=steps=>{for(let n=0;n<steps;n++){g.player.pos.z+=.03;g.player._resolve();}};
    g.player.setPosition(63.75,66.3);move(70);
    const closed=g.player.pos.z<66.7&&__gym.inspect().doorBlocked;
    g.player.setPosition(63.75,66.25);__gym.toggleDoor();tick(2);move(100);
    const entered=g.player.pos.z>67.5&&!__gym.inspect().doorBlocked;
    const stations={treadmill:[62.4,70.35],bike:[63.45,75.12],bench:[64.1,70.3],squat:[64.6,72.65],dumbbells:[65.7,74.9]};
    const started={};
    for(const [kind,[x,z]] of Object.entries(stations)){
      g.player.setPosition(x,z);started[kind]=__gym.start(kind);tick(9);
    }
    g.player.setPosition(62.4,70.35);__gym.start('treadmill');__gym.finish(false);
    const hit=id=>g.world.hitboxes.find(h=>h.userData.interactable?.id===id).userData.interactable.action();
    const before=g.data.money;hit('gym-water');hit('gym-shower');hit('gym-locker');
    const result={closed,entered,started,workouts:g.data.gym.workouts,treadmill:g.data.gym.byKind.treadmill,
      waterCost:before-g.data.money,drinks:g.data.gym.drinks,shower:__gym.inspect().shower,locker:__gym.inspect().locker};
    g.saveNow();g.toMenu();g.onContinue();result.reloaded=g.data.gym.workouts;
    return result;
  });
  assert.equal(result.closed,true);assert.equal(result.entered,true);
  assert.ok(Object.values(result.started).every(Boolean));assert.equal(result.workouts,5);
  assert.equal(result.treadmill,1);assert.equal(result.waterCost,5);assert.equal(result.drinks,1);
  assert.equal(result.shower,true);assert.equal(result.locker,true);assert.equal(result.reloaded,5);
  assert.deepEqual(errors,[]);
  console.log('OK: gym door, five workouts, cancellation, water, shower, locker, save/reload');
  process.exit(0);
})().catch(e=>{console.error(e);process.exit(1);});
