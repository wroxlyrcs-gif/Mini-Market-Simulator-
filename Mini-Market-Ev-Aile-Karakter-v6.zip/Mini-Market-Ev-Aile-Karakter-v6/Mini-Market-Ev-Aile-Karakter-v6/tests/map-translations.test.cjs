'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const dict=require('../map-translations.js');
const langs=['tr','en','az','ru'];
for(const [name,values] of Object.entries(dict.labels)){
  assert.equal(values.length,4,name);for(const v of values)assert.ok(v.trim(),name);
  assert.equal(dict.place('tr',name),name,`Turkish label preserved: ${name}`);
}
for(const [key,values] of Object.entries(dict.headings)){assert.equal(values.length,4,key);for(const v of values)assert.ok(v.trim(),key);}
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
const start=html.indexOf('// Köşe mini haritası:'),end=html.indexOf('\n</script>',start);
assert.ok(start>=0&&end>start,'map module found');
const code=html.slice(start,end);
assert.ok(html.indexOf('src="map-translations.js"')<start,'dictionary loads before map');
const staticNames=[...code.matchAll(/R\([^\n]*?'#[0-9a-fA-F]+',\s*'([^']+)'/g)].map(m=>m[1]);
for(const name of staticNames)assert.ok(dict.labels[name],`missing map translation: ${name}`);
for(const name of ['Market Otoparkı','Reklam Panosu','Batı Mahallesi','Market','Doğu Bulvarı','Doğu Çevre Yolu','Kuzey Çevre Yolu'])
  assert.ok(dict.labels[name],`missing extension label: ${name}`);
const title={textContent:''},close={textContent:''},drawn=[];
const context={fillRect(){},measureText(){return {width:1};},fillText(s){drawn.push(s);},save(){},restore(){},translate(){},rotate(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
const canvases=[];
const doc={
  head:{appendChild(){}},body:{append(){}},
  createElement(tag){
    if(tag==='canvas'){const c={width:0,height:0,getContext(){return context;}};canvases.push(c);return c;}
    if(tag==='style')return {};
    return {id:'',style:{},events:{},appendChild(){},insertAdjacentHTML(){},
      addEventListener(type,fn){this.events[type]=fn;},
      querySelector(s){return s==='.mm-map-title'?title:close;}};
  }
};
const game={state:'playing',player:{pos:{x:0,z:0}},fpsCam:{yaw:0},ui:{lang:'tr',setLanguage(l){this.lang=l;}}};
const window={__mms:game,MMS_MAP_TRANSLATIONS:dict};
let wrap;
const baseCreate=doc.createElement;
doc.createElement=function(tag){const v=baseCreate.call(this,tag);if(tag==='div'&&!wrap)wrap=v;return v;};
const contextObj={window,document:doc,innerWidth:1000,innerHeight:1000,setInterval(){},Math};
vm.runInNewContext(code,contextObj,{filename:'map-module'});
assert.equal(title.textContent,dict.heading('tr','title'));
wrap.events.click();
assert.ok(drawn.length>0,'map draws existing labels');
for(const lang of langs){
  drawn.length=0;game.ui.setLanguage(lang);
  assert.equal(title.textContent,dict.heading(lang,'title'),`${lang} map title refreshes`);
  assert.equal(close.textContent,dict.heading(lang,'close'),`${lang} map close hint refreshes`);
  assert.ok(drawn.some(v=>v.includes(dict.place(lang,'Basketbol'))),`${lang} redraws existing basketball label`);
}
console.log(`OK: ${Object.keys(dict.labels).length} existing map names and live map language switching`);
