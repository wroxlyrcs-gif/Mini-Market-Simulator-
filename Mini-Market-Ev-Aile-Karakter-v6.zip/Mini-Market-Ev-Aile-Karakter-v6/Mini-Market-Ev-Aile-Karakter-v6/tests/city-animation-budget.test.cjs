'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const steering=require('../pedestrian-steering.js');
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-ikinci-market.html'),'utf8');
const start=html.indexOf('window.MMS_PEOPLE = (() => {'),end=html.indexOf('\n</script>',start);
assert.ok(start>=0&&end>start);
let code=html.slice(start,end);
const anchor='return { build, update, inspect: () => people.map';
assert.ok(code.includes(anchor));
code=code.replace(anchor,"return { __test:{setContext(w,g){W=w;G=g;built=true;},setPeople(list){people.length=0;people.push(...list);}}, build, update, inspect: () => people.map");
const window={MMS_PEDESTRIAN_STEERING:steering};
const context={window,localStorage:{getItem(){return null;},setItem(){}},__req:()=>({inHouse:()=>false}),Math,THREE:{},console};
vm.runInNewContext(code,context);
const world={colliders:[],trafficCars:[]};
const game={world,player:{pos:{x:0,z:0}},state:'playing',ui:{},clock:{minutes:600}};
window.MMS_PEOPLE.__test.setContext(world,game);
function actor(x,z,target){
 const group={position:{x,y:0,z,set(a,b,c){this.x=a;this.y=b;this.z=c;}},rotation:{y:0},scale:{y:1},visible:true};
 return {id:'test',x,z,state:'route',q:[[target.x,target.z]],dest:{n:'A'},cd:0,talk:0,rel:0,
  h:{group,calls:0,walk(){this.calls++;}},heart:{visible:false,rotation:{y:0}},hb:{position:{set(){}}}};
}
const far=actor(100,0,{x:105,z:0});
window.MMS_PEOPLE.__test.setPeople([far]);
for(let i=0;i<20;i++)window.MMS_PEOPLE.update(.05,game);
assert.ok(far.x>100,'far NPC still moves and follows its route');
assert.equal(far.h.calls,0,'invisible NPC does not animate');
const mid=actor(30,0,{x:35,z:0});
window.MMS_PEOPLE.__test.setPeople([mid]);
for(let i=0;i<20;i++)window.MMS_PEOPLE.update(.05,game);
assert.ok(mid.x>30,'medium-distance NPC still moves');
assert.ok(mid.h.calls>0&&mid.h.calls<20,'medium-distance animation is throttled');
const near=actor(5,0,{x:10,z:0});
window.MMS_PEOPLE.__test.setPeople([near]);
for(let i=0;i<20;i++)window.MMS_PEOPLE.update(.05,game);
assert.equal(near.h.calls,20,'nearby NPC animation remains full rate');
console.log('OK: actual second-market build preserves navigation while reducing distant NPC animation');
