'use strict';
const assert=require('node:assert/strict');
const {FramePacer,AdaptiveScale,install}=require('../performance-budget');

for(const target of [30,45,60]) {
  const pacer=new FramePacer(target);
  let rendered=0;
  for(let n=0;n<1200;n++)if(pacer.shouldRender(n*1000/120))rendered++;
  assert.ok(Math.abs(rendered-target*10)<=1,`${target} FPS cap at 120 Hz: ${rendered} renders`);
}
const capped60=new FramePacer(45);let frames=0;
for(let n=0;n<600;n++)if(capped60.shouldRender(n*1000/60))frames++;
assert.ok(Math.abs(frames-450)<=1,'45 FPS is correctly paced on a 60 Hz loop');
assert.equal(capped60.shouldRender(120000),true,'long background pause does not cause a catch-up burst');

let a=new AdaptiveScale(),scale=1;
for(let n=0;n<1200;n++)scale=a.sample(1/30,30,scale);
assert.equal(scale,1,'a deliberate 30 FPS limit must not reduce quality');
a=new AdaptiveScale();scale=1;
for(let n=0;n<600;n++)scale=a.sample(1/30,60,scale);
assert.ok(scale<1 && scale>=.5,'sustained load lowers resolution');
const reduced=scale;
for(let n=0;n<1800;n++)scale=a.sample(1/60,60,scale);
assert.ok(scale>reduced && scale<=1,'resolution recovers after sustained stability');

class Element {
  constructor(){this.dataset={};this.children=[];this.attrs={};this.handlers={};this.textContent='';this.classList={toggle:(k,v)=>{this.on=v;}};}
  appendChild(e){this.children.push(e);}
  setAttribute(k,v){this.attrs[k]=v;}
  addEventListener(k,fn){this.handlers[k]=fn;}
  insertAdjacentElement(_where,e){this.inserted=e;}
}
const quality=new Element();quality.parentElement=new Element();
const doc={hidden:false,getElementById:id=>id==='set-quality'?quality:null,createElement:()=>new Element(),addEventListener(){}};
let now=0,renders=0,resizes=0,simTicks=0;
const stored=new Map();
const g={
  state:'playing',settings:{quality:'medium'},_renderScale:1,
  renderer:{render(){renders++;},getPixelRatio(){return 1;},setSize(){resizes++;},info:{render:{calls:14,triangles:700},memory:{geometries:9,textures:3}}},
  ui:{lang:'tr',setLanguage(l){this.lang=l;}},
  applyQualityRatio(){},samplePerformance(){throw Error('old sampler should be replaced');},
};
const win={__mms:g,document:doc,innerWidth:800,innerHeight:400,
  localStorage:{getItem:k=>stored.get(k)||null,setItem:(k,v)=>stored.set(k,v)},
  performance:{now:()=>now}};
const control=install(win);
assert.ok(control);
assert.equal(quality.parentElement.inserted.children[0].textContent,'FPS sınırı');
g.ui.setLanguage('en');
assert.equal(quality.parentElement.inserted.children[0].textContent,'FPS limit');
control.setFPS(30);
for(let n=0;n<600;n++){now=n*1000/60;simTicks++;g.renderer.render({},{});g.samplePerformance(1/60);}
assert.equal(simTicks,600,'simulation is not throttled');
assert.ok(Math.abs(renders-300)<=1,`rendering is capped separately (${renders})`);
assert.equal(control.inspect().targetFPS,30);
assert.equal(control.inspect().drawCalls,14);
assert.equal(control.inspect().textures,3);
assert.equal(stored.get('mms_fps_limit_v1'),'30');
assert.equal(g.settings.quality,'medium','automatic tuning does not alter saved quality');
assert.equal(resizes,0,'stable capped rendering does not repeatedly resize');
const mobileGame={
  state:'playing',settings:{quality:'medium'},_renderScale:1,
  renderer:{render(){},getPixelRatio(){return 1;},setSize(){},info:{}},
  ui:{lang:'tr',setLanguage(){}},applyQualityRatio(){},samplePerformance(){},
};
const mobileWin={...win,__mmsPerformance:undefined,__mms:mobileGame,navigator:{userAgent:'Android'},localStorage:{getItem(){return null;},setItem(){}}};
const mobileControl=install(mobileWin);
assert.equal(mobileControl.inspect().targetFPS,30,'Android defaults to 30 FPS if no preference exists');
const savedGame={...mobileGame,renderer:{...mobileGame.renderer},ui:{...mobileGame.ui}};
const savedWin={...mobileWin,__mmsPerformance:undefined,__mms:savedGame,localStorage:{getItem(){return '60';},setItem(){}}};
assert.equal(install(savedWin).inspect().targetFPS,60,'an existing FPS preference is respected');
console.log('OK: 30/45/60 pacing, separate simulation, adaptive recovery, persistence and diagnostics');
