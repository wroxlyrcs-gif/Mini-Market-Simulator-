const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const base = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(base, 'casino-system.js'), 'utf8');
const html = fs.readFileSync(path.join(base, 'mini-market-simulator.html'), 'utf8');
function loadCasino(storage = {}) {
  const store = new Map(Object.entries(storage));
  const localStorage = { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k,v) => store.set(k, String(v)) };
  const window = {};
  vm.runInNewContext(code, { window, localStorage, Math, Number, Object, Array, String, JSON, Set, Map });
  return { casino: window.MMS_CASINO, store };
}
const c = (rank, suit='♠') => ({ rank, suit });

test('casino extension is loaded before app boot and registered in the existing loop', () => {
  assert.match(html, /<script src="casino-system\.js"><\/script>/);
  assert.match(html, /extraBuilders\.push\(\(w\) => MMS_CASINO\.build\(w, this\)\)/);
  assert.match(html, /MMS_CASINO\.update\(dt, this\)/);
  assert.match(html, /MMS_CASINO\.safeSave\(/);
});

test('poker evaluator ranks royal flush, quads, wheel straight, and kickers', () => {
  const { casino } = loadCasino();
  assert.equal(casino.pokerEval([c(10,'♥'),c(11,'♥'),c(12,'♥'),c(13,'♥'),c(14,'♥')]).tier, 9);
  assert.equal(casino.pokerEval([c(9,'♠'),c(9,'♥'),c(9,'♦'),c(9,'♣'),c(2,'♠')]).tier, 7);
  assert.deepEqual(Array.from(casino.pokerEval([c(14),c(2),c(3),c(4),c(5)]).tie), [5]);
  assert.ok(casino.compareHands([c(14),c(14,'♥'),c(7),c(5),c(2)], [c(13),c(13,'♥'),c(7),c(5),c(2)]) > 0);
});

test('blackjack correctly values aces as 11 or 1', () => {
  const { casino } = loadCasino();
  assert.equal(casino.bjValue([c(14),c(9)]), 20);
  assert.equal(casino.bjValue([c(14),c(9),c(5)]), 15);
  assert.equal(casino.bjValue([c(14),c(14),c(9)]), 21);
});

test('wallet reads and clamps persisted casino credits without touching main-game cash', () => {
  const { casino } = loadCasino({ mms_casino_wallet_v1: JSON.stringify({ balance: 1250.9, wins: 3, losses: 4, played: 8 }) });
  assert.deepEqual(JSON.parse(JSON.stringify(casino.inspect())), { inside: false, seated: false, balance: 1250, wins: 3, losses: 4, played: 8, npcCount: 0 });
  casino.saveWallet();
  const saved = JSON.parse([...loadCasino({ mms_casino_wallet_v1: JSON.stringify({ balance: 1250 }) }).store.values()][0]);
  assert.equal(saved.balance, 1250);
});
