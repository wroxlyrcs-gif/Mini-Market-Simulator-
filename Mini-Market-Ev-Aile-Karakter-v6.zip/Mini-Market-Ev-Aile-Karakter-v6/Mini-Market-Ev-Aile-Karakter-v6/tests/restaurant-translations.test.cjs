'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const dict=require('../restaurant-translations.js');
const langs=['tr','en','az','ru'];
const placeholders=s=>[...new Set([...s.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map(m=>m[1]))].sort().join(',');
for(const [key,rows] of Object.entries(dict.entries)){
  assert.equal(rows.length,4);
  for(const row of rows){assert.ok(row.trim(),key);assert.equal(placeholders(row),placeholders(rows[0]),key);}
}
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
assert.ok(html.indexOf('src="restaurant-translations.js"')<html.indexOf('src="city-life.js"'));
class Group{
  constructor(){this.position={set(){}};this.rotation={};this.scale={set(){}};this.userData={};}
  add(){} 
}
class Mesh extends Group{}
const T={Group,Mesh,CylinderGeometry:class {},MeshBasicMaterial:class {}};
const controls={};
const ui={
  _html:'',classes:new Set(),addEventListener(){},
  classList:{add(c){ui.classes.add(c);},remove(c){ui.classes.delete(c);},contains(c){return ui.classes.has(c);}},
  set innerHTML(v){this._html=v;controls.close={};for(const kind of ['meal','sky'])for(const option of ['solo','date'])if(v.includes(`data-${kind}="${option}"`))controls[kind+option]={dataset:{[kind]:option}};},
  get innerHTML(){return this._html;},
  querySelector(s){if(s==='.close')return controls.close;throw Error(s);},
  querySelectorAll(s){const kind=s==='[data-meal]'?'meal':'sky';return [controls[kind+'solo'],controls[kind+'date']];}
};
const document={head:{appendChild(){}},body:{appendChild(){}},createElement(tag){return tag==='div'?ui:{};}};
const interactions={};
const world={
  scene:{add(){}},colliders:[],b(){return new Group();},cyl(){},put(){},geo(){return {};},mat(){return {};},canvasTex(){return {};},
  addInteractable(o){interactions[o.id]=o;}
};
const people={girlfriend:()=>null,family:()=>({}),dateReward(){},endDining(){},beginDining(){return true;}};
const game={
  world,marketBuild:{upperCols:[]},data:{money:500,upgrades:[],marketBuild:{items:[]},fixtures:{}},state:'playing',
  ui:{lang:'tr',setLanguage(lang){this.lang=lang;},toast(text){this.message=text;}},
  player:{pos:{x:0,z:0},setPosition(x,z){this.pos={x,z};}},fpsCam:{eyeHeight:1.62,update(){}},
  depot:{customers:{_step(){}},update(){},reset(){}},audio:{play(){}},saveNow(){},setInputLocked(){},toMenu(){}
};
const window={__mms:game,THREE:T,MMS_RESTAURANT_TRANSLATIONS:dict};
const ctx={window,document,THREE:T,MMS_PEOPLE:people,MMS_NIGHT:{reg:v=>v,light(){},glow(){}},__req:()=>({findPath(){}}),Math,Set,Map};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','city-life.js'),'utf8'),ctx,{filename:'city-life.js'});
assert.ok(interactions['city-restaurant-table'],'ground-floor restaurant action registered');
interactions['city-restaurant-table'].action();
for(const lang of langs){
  game.ui.setLanguage(lang);
  assert.ok(ui.innerHTML.includes(dict.t(lang,'title')),`${lang} restaurant menu title`);
  assert.ok(ui.innerHTML.includes(dict.t(lang,'solo')),`${lang} solo meal`);
  assert.ok(ui.innerHTML.includes(dict.t(lang,'balance',{balance:500})),`${lang} balance`);
  assert.equal(game.data.money,500,'language changes do not affect money');
}
game.ui.setLanguage('ru');
controls.mealsolo.onclick();
assert.equal(game.data.money,455,'ground-floor solo meal price preserved');
assert.equal(game.ui.message,dict.t('ru','enjoy'),'meal notification translated');
assert.equal(ui.classList.contains('open'),false,'menu closes after purchase');
interactions['city-restaurant-up'].action();
interactions['city-restaurant-sky-table'].action();
for(const lang of langs){
  game.ui.setLanguage(lang);
  assert.ok(ui.innerHTML.includes(dict.t(lang,'skyTitle')),`${lang} scenic menu`);
  assert.ok(ui.innerHTML.includes(dict.t(lang,'skySolo')),`${lang} scenic meal`);
}
controls.skysolo.onclick();
assert.equal(game.data.money,395,'scenic solo meal price preserved');
console.log(`OK: ${Object.keys(dict.entries).length} restaurant phrases, open menus refresh, meal prices unchanged`);
