'use strict';
// Real city NPC update with lightweight rendering and world substitutes.
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const steering=require('../pedestrian-steering.js');
const html=fs.readFileSync(path.join(__dirname,'..','mini-market-simulator.html'),'utf8');
const moduleStart=html.indexOf('window.MMS_PEOPLE = (() => {'),end=html.indexOf('\n</script>',moduleStart);
assert.ok(moduleStart>=0&&end>moduleStart,'existing NPC module found');
assert.ok(html.indexOf('src="pedestrian-steering.js"')<moduleStart,'steering loads before NPCs');
let code=html.slice(moduleStart,end);
const anchor='return { build, update, inspect: () => people.map';
assert.ok(code.includes(anchor));
code=code.replace(anchor,"return { __test:{setContext(w,g){W=w;G=g;built=true;},setPeople(list){people.length=0;people.push(...list);}}, build, update, inspect: () => people.map");
const window={MMS_PEDESTRIAN_STEERING:steering};
const ctx={window,localStorage:{getItem(){return null;},setItem(){}},__req:()=>({inHouse:()=>false}),Math,THREE:{},console};
vm.runInNewContext(code,ctx);
const world={colliders:[],trafficCars:[]};
const game={world,player:{pos:{x:100,z:100}},state:'playing',ui:{},clock:{minutes:600}};
window.MMS_PEOPLE.__test.setContext(world,game);
function actor(id,x,z,target){
  const group={position:{x,y:0,z,set(a,b,c){this.x=a;this.y=b;this.z=c;}},rotation:{y:0},scale:{y:1},visible:true};
  return {id,x,z,state:'route',q:[[target.x,target.z]],dest:{n:'A'},cd:0,talk:0,rel:0,
    h:{group,walk(dt,speed){this.lastSpeed=speed;}},heart:{visible:false,rotation:{y:0}},hb:{position:{set(){}}}};
}
const a=actor('a',-3,0,{x:3,z:0}),b=actor('b',3,0,{x:-3,z:0});
window.MMS_PEOPLE.__test.setPeople([a,b]);
for(let i=0;i<200;i++){
  window.MMS_PEOPLE.update(.05,game);
  assert.ok(Math.hypot(a.x-b.x,a.z-b.z)>=steering.GAP-1e-6,`NPCs overlap in actual update at frame ${i}`);
}
assert.ok(a.x>2.8&&b.x< -2.8,'both real NPC update paths make progress');

// The previous 0.15m snap skipped traffic-signal checks.
const waiting=actor('red',2.9,0,{x:3,z:0});
window.MMS_PEOPLE.__test.setPeople([waiting]);
window.__trafficSignals={canPedestrianMove:()=>false};
window.MMS_PEOPLE.update(.05,game);
assert.equal(waiting.x,2.9,'near-waypoint pedestrian does not bypass a red signal');
assert.equal(waiting.q.length,1,'waypoint remains queued when stopped');
window.__trafficSignals={canPedestrianMove:()=>true};
for(let i=0;i<3;i++)window.MMS_PEOPLE.update(.05,game);
assert.ok(Math.abs(waiting.x-3)<1e-7,'pedestrian reaches waypoint after green');
assert.equal(waiting.q.length,0,'waypoint shifts only after arrival');
assert.ok(Number.isFinite(waiting.x)&&Number.isFinite(waiting.z),'positions stay finite');

// The actual signal controller and NPC update run together at the west crossing.
class Obj {
  constructor(){this.position={set(){}};this.rotation={};this.userData={};this.children=[];}
  add(...items){this.children.push(...items);}
}
class Color{constructor(v){this.value=v;}setHex(v){this.value=v;}}
class Material{constructor({color}){this.color=new Color(color);}}
class Mesh extends Obj{constructor(geometry,material){super();this.geometry=geometry;this.material=material;}}
window.THREE={Group:Obj,Mesh,MeshBasicMaterial:Material,SphereGeometry:class {}};
window.__cityTraffic={};window.__mms=game;
world.scene=new Obj();world.b=()=>new Obj();world.geo=()=>({});world.mergeStatic=()=>{};world.update=()=>{};
delete window.__trafficSignals;
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','city-signals.js'),'utf8'),ctx);
const signal=window.__trafficSignals, north=actor('north',-32.3,7.5,{x:-32.3,z:15.6}),south=actor('south',-32.3,15.6,{x:-32.3,z:7.5});
window.MMS_PEOPLE.__test.setPeople([north,south]);
for(let i=0;i<200;i++){window.MMS_PEOPLE.update(.05,game);world.update(.05,game.player.pos,true);}
assert.ok(north.z<8.2&&south.z>14.6,'both pedestrians wait before crossing during vehicle green');
const blockingCar={trafficBody:true,minX:-33.3,maxX:-31.3,minZ:9,maxZ:11};
world.colliders.push(blockingCar);
for(let i=0;i<260;i++){window.MMS_PEOPLE.update(.05,game);world.update(.05,game.player.pos,true);}
assert.equal(signal.phase(),'walk');
assert.ok(north.z<8.2&&south.z>14.6,'pedestrians wait while a vehicle occupies the crossing');
world.colliders.length=0;
let minDistance=Infinity;
for(let i=0;i<700;i++){
  window.MMS_PEOPLE.update(.05,game);world.update(.05,game.player.pos,true);
  minDistance=Math.min(minDistance,Math.hypot(north.x-south.x,north.z-south.z));
}
assert.ok(minDistance>=steering.GAP-1e-6,'pedestrians maintain spacing on crossing');
assert.ok(north.z>14.6&&south.z<8.2,'both pedestrians eventually cross after vehicle clears');
console.log('OK: actual NPC update, crowd spacing, red/walk signals and occupied crossing');
