'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function create(mobile=true){
 let ratio=0,updates=0,disposals=0;const bg={isColor:true,clone(){return {copy(){}}}};
 class FogExp2{constructor(color,density){this.color=color;this.density=density}}
 const renderer={shadowMap:{needsUpdate:false,type:0},setPixelRatio(n){ratio=n},getPixelRatio(){return ratio},setSize(){updates++}};
 const world={sun:{shadow:{mapSize:{x:1024,set(x){this.x=x}},map:{dispose(){disposals++}}}},setQuality(){},update(){return 17}};
 const game={world,renderer,scene:{background:bg,traverse(){}},settings:{quality:'medium'},state:'playing',_renderScale:1,applyQualityRatio(){ratio=1.4},samplePerformance(){this.desktopCalled=true}};
 const window={__mms:game,THREE:{ACESFilmicToneMapping:1,PCFShadowMap:1,FogExp2},devicePixelRatio:2};
 const ctx={window,navigator:{userAgent:mobile?'Android':'Desktop',deviceMemory:4,maxTouchPoints:mobile?5:0},document:{hidden:false},location:{search:''},URLSearchParams,innerWidth:1000,innerHeight:500,matchMedia:()=>({matches:mobile}),Math,Number};
 vm.runInNewContext(fs.readFileSync('mobil-grafik.js','utf8'),ctx);
 return {game,window,world,renderer,stats:()=>({ratio,updates,disposals})};
}
let v=create();assert.ok(v.window.__mobilGrafik.mobile);assert.equal(v.world.sun.shadow.mapSize.x,512);assert.equal(v.renderer.shadowMap.type,1);assert.ok(v.game._renderScale<=.85);assert.ok(Math.abs(v.stats().ratio-1.6*.85)<1e-9,'orta kalite 1.6x tavan x baslangic olcegi');assert.equal(v.game.scene.fog.density,.0016);
for(let i=0;i<60;i++)v.game.samplePerformance(.05);assert.ok(v.game._renderScale<1,'slow frames lower resolution');assert.equal(v.game.settings.quality,'medium');assert.ok(v.stats().updates>0);
const reduced=v.game._renderScale;for(let i=0;i<1200;i++)v.game.samplePerformance(1/60);assert.ok(v.game._renderScale>reduced,'stable high FPS restores resolution');assert.ok(v.game._renderScale<=1);
assert.equal(v.world.update(.6),17);v.game.settings.quality='low';v.game.applyQualityRatio();assert.ok(v.stats().ratio<=1);
let desktop=create(false);desktop.game.samplePerformance(.05);assert.ok(desktop.game.desktopCalled);assert.equal(desktop.stats().ratio,1.4);
console.log('OK: mobil tespiti, gölgeler, çözünürlük uyarlaması, kalite tercihi, gece uyumu ve masaüstü davranışı');
