/* FINAL: modest café service on the existing outdoor café footprint. */
(function(){
  'use strict';
  const g=window.__mms,T=window.THREE,P=window.__mmsPeople;
  if(!g||!T||!P||window.MMS_CAFE_FINAL)return;
  const w=g.world;
  const tx={
    tr:{label:'☕ Kafeden içecek al',title:'Kafe',note:'İçeceğini burada tüketirsin.',coffee:'Kahve',tea:'Çay',lemon:'Limonata',close:'Kapat',bought:'İçeceğin hazır. Afiyet olsun!',no:'Yeterli paran yok.',money:'Bakiye'},
    en:{label:'☕ Buy a drink at the café',title:'Café',note:'Your drink is served here.',coffee:'Coffee',tea:'Tea',lemon:'Lemonade',close:'Close',bought:'Your drink is ready. Enjoy!',no:'Not enough money.',money:'Balance'},
    az:{label:'☕ Kafedən içki al',title:'Kafe',note:'İçkini burada içə bilərsən.',coffee:'Qəhvə',tea:'Çay',lemon:'Limonad',close:'Bağla',bought:'İçkin hazırdır. Nuş olsun!',no:'Pulun kifayət etmir.',money:'Balans'},
    ru:{label:'☕ Купить напиток в кафе',title:'Кафе',note:'Напиток подаётся здесь.',coffee:'Кофе',tea:'Чай',lemon:'Лимонад',close:'Закрыть',bought:'Ваш напиток готов. Приятного аппетита!',no:'Недостаточно денег.',money:'Баланс'}
  };
  const t=()=>tx[g.ui.lang]||tx.tr, menu={coffee:15,tea:10,lemon:18}, actors=[];
  function person(x,z,shirt,skin,seat){
    const h=P.buildHuman({shirt,pants:0x313945,skin,hair:0x352821,scale:.92,lod:true,face:{hairStyle:'short'}});
    h.group.position.set(x,seat?.45:0,z);h.group.rotation.y=seat?Math.PI:0;w.scene.add(h.group);
    if(h.lowGroup){h.lowGroup.position.copy(h.group.position);h.lowGroup.rotation.y=h.group.rotation.y;w.scene.add(h.lowGroup);h.lowGroup.visible=false;}
    if(seat){h.legL.rotation.x=h.legR.rotation.x=-1.15;h.armL.rotation.x=h.armR.rotation.x=-.35;}
    actors.push({h,x,z,seat,phase:actors.length*2.1});
  }
  person(65.0,46.45,0xf4e9d4,0xd9a17a,false);
  person(62.8,43.72,0x678a79,0xe0ac86,true);
  person(66.5,43.72,0x955e63,0xc8916c,true);
  w.addInteractable({id:'final-cafe-counter',label:Object.fromEntries(Object.keys(tx).map(k=>[k,tx[k].label])),box:[2.2,2.5,1.1,65,0,46.2],action:open});
  let overlay=null;
  function buy(which){
    if(!g.data||!Object.prototype.hasOwnProperty.call(menu,which))return false;
    const price=menu[which];if(g.data.money<price){g.ui.toast(t().no);return false;}
    g.data.money-=price;if(!g.data.cafe||typeof g.data.cafe!=='object')g.data.cafe={drinks:0};
    g.data.cafe.drinks=Math.min(1000000,(Number(g.data.cafe.drinks)||0)+1);
    g.saveNow();g.audio.play('cash');g.ui.toast(t().bought,2400);return true;
  }
  function open(){if(!g.data||g.state!=='playing')return;if(document.exitPointerLock)document.exitPointerLock();
    if(!overlay){const css=document.createElement('style');css.textContent='#final-cafe-ui{position:fixed;inset:0;z-index:140;display:none;align-items:center;justify-content:center;padding:12px;background:#21160dcc;color:#fff5e7;font:16px system-ui}#final-cafe-ui.open{display:flex}#final-cafe-ui section{width:min(430px,96vw);max-height:90vh;overflow:auto;background:#4d3427;border:2px solid #e1bb82;border-radius:18px;padding:20px;box-shadow:0 18px 50px #0008}#final-cafe-ui h2{margin:0;color:#ffe2ae}#final-cafe-ui button{display:block;width:100%;min-height:44px;margin:8px 0;padding:10px;border:0;border-radius:10px;background:#f3dfbc;color:#3b291f;font:700 15px system-ui;cursor:pointer}';document.head.appendChild(css);
      overlay=document.createElement('div');overlay.id='final-cafe-ui';overlay.innerHTML='<section role="dialog" aria-modal="true"></section>';document.body.appendChild(overlay);
      for(const ev of ['pointerdown','touchstart','mousedown'])overlay.addEventListener(ev,e=>e.stopPropagation());
      overlay.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;e.stopPropagation();if(b.dataset.key==='close')close();else if(buy(b.dataset.key))render();});
      window.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay.classList.contains('open')){e.stopImmediatePropagation();e.preventDefault();close();}},true);
    }
    g.setInputLocked(true);overlay.classList.add('open');render();
  }
  function render(){const v=t();overlay.querySelector('section').innerHTML=`<h2>☕ ${v.title}</h2><p>${v.note}</p><p>${v.money}: ${Math.floor(g.data.money)} $</p>`+Object.entries(menu).map(([key,price])=>`<button data-key="${key}">${v[key]} · ${price} $</button>`).join('')+`<button data-key="close">${v.close}</button>`;}
  function close(){if(!overlay)return;overlay.classList.remove('open');g.setInputLocked(false);g._promptKey=null;}
  let clock=0;const oldUpdate=w.update.bind(w);
  w.update=function(dt,pos,playing){const result=oldUpdate(dt,pos,playing);if(playing&&g.state==='playing'){
    clock+=Math.min(.05,dt);for(const a of actors){const d=Math.hypot(g.player.pos.x-a.x,g.player.pos.z-a.z);const visible=d<48;
      if(a.h.lowGroup){a.h.group.visible=visible&&d<20;a.h.lowGroup.visible=visible&&d>=20;}else a.h.group.visible=visible;
      if(d<22){if(a.seat){a.h.armL.rotation.x=-.38+Math.sin(clock*1.4+a.phase)*.12;}else a.h.walk(dt,.025);}}
    }return result;};
  const oldMenu=g.toMenu.bind(g);g.toMenu=function(){if(overlay?.classList.contains('open'))close();return oldMenu();};
  window.MMS_CAFE_FINAL={buy,open,inspect:()=>({people:actors.length,drinks:g.data?.cafe?.drinks||0})};
})();
