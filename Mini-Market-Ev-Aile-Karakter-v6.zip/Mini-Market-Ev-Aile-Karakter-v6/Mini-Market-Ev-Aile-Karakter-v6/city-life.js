/* v2.9: upstairs customer visits, neighborhood footpath and restaurant. */
(function () {
  'use strict';
  const g = window.__mms;
  if (!g || !g.marketBuild || !window.THREE) return;
  const T = window.THREE, w = g.world;
  const L = (key,vars) => window.MMS_RESTAURANT_TRANSLATIONS.t(g.ui.lang,key,vars);
  const { findPath } = __req('pathing');
  const shop = g.depot.customers;
  const oldStep = shop._step.bind(shop);
  const hallBounds = () => {
    const d = __req('expand').backDepth(g.data.upgrades);
    return { minX:-6.5, maxX:6.5, minZ:-5.0-d, maxZ:-5.6 };
  };
  // Small A* grid for the upper floor: existing furniture and the stairwell are obstacles.
  function upperPath(from, goals) {
    const b = hallBounds(), cell = .35, cols = g.marketBuild.upperCols;
    const nx = Math.floor((b.maxX-b.minX)/cell)+1, nz = Math.floor((b.maxZ-b.minZ)/cell)+1;
    const xx = i => b.minX+i*cell, zz = j => b.minZ+j*cell;
    const free = (i,j) => i>=0 && j>=0 && i<nx && j<nz && !cols.some(c =>
      xx(i)>c.minX-.25 && xx(i)<c.maxX+.25 && zz(j)>c.minZ-.25 && zz(j)<c.maxZ+.25);
    const nearest = (x,z) => {
      const i0=Math.round((x-b.minX)/cell), j0=Math.round((z-b.minZ)/cell);
      let best=null, dist=Infinity;
      for(let j=Math.max(0,j0-6);j<=Math.min(nz-1,j0+6);j++) for(let i=Math.max(0,i0-6);i<=Math.min(nx-1,i0+6);i++) {
        if(!free(i,j))continue; const d=(xx(i)-x)**2+(zz(j)-z)**2;
        if(d<dist){dist=d;best={i,j};}
      }
      return best;
    };
    const start=nearest(from.x,from.z);
    if(!start)return null;
    for (const goal of goals) {
      const end=nearest(goal.x,goal.z);
      if(!end)continue;
      const key=(i,j)=>j*nx+i, startKey=key(start.i,start.j), endKey=key(end.i,end.j);
      const open=[{...start,f:0}], prev=new Map(), score=new Map([[startKey,0]]), closed=new Set();
      while(open.length) {
        let best=0;for(let n=1;n<open.length;n++)if(open[n].f<open[best].f)best=n;
        const cur=open.splice(best,1)[0], ck=key(cur.i,cur.j);
        if(closed.has(ck))continue;closed.add(ck);
        if(ck===endKey) {
          const out=[];let k=ck;
          while(k!==startKey){out.unshift({x:xx(k%nx),z:zz(Math.floor(k/nx)),y:3.2});k=prev.get(k);}
          return out;
        }
        for(const [di,dj] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]) {
          const i=cur.i+di,j=cur.j+dj;if(!free(i,j) || (di&&dj&&(!free(cur.i+di,cur.j)||!free(cur.i,cur.j+dj))))continue;
          const k=key(i,j), next=score.get(ck)+(di&&dj?1.414:1);
          if(next >= (score.get(k)??Infinity))continue;
          score.set(k,next);prev.set(k,ck);open.push({i,j,f:next+Math.hypot(i-end.i,j-end.j)});
        }
      }
    }
    return [];
  }
  function makeTrip(c) {
    const floor=g.data.marketBuild;
    const toFoot=findPath(w.colliders,{x:c.x,z:c.z},{x:5.35,z:-5.55},{r:.22});
    if(!toFoot || !toFoot.length) return null;
    const last=toFoot[toFoot.length-1];
    if(Math.hypot(last.x-5.35,last.z+5.55)>.65)return null;
    const stairs=[];
    for(let i=0;i<=12;i++) stairs.push({x:5.35,z:-5.6-i*3.5/12,y:3.2*i/12});
    const landing={x:3.35,z:-7.2,y:3.2};
    const stocks=floor.items.filter(a=>a.floor===1 && a.x!==null && (a.type==='shelf'||a.type==='fridge'));
    const preferred=stocks.filter(a=>c.wants.some(want => (g.data.fixtures[a.id]?.[want.pid]||0)>0));
    const fixture=preferred[0]||stocks[0];
    const goals=fixture ? [{x:fixture.x-1,z:fixture.z},{x:fixture.x+1,z:fixture.z},{x:fixture.x,z:fixture.z-1},{x:fixture.x,z:fixture.z+1}] : [{x:-.8,z:-7.4}];
    const upper=upperPath(landing,goals);
    if(upper===null)return null;
    const ground=toFoot.map(p=>({x:p.x,z:p.z,y:0}));
    const outward=[...ground,...stairs,landing,...upper];
    const reverse=[...outward].reverse().slice(1);
    reverse.push({x:5.6,z:-2.9,y:0});
    return {points:outward, back:reverse, index:0, phase:'out', dwell:0};
  }
  function queueCustomer(c) {
    c.upperTrip=null;
    c.upperVisited=true;
    c.h.group.position.y=0;
    c.state='queue'; c.path=[]; c.at='E'; c.target=null;
    if(!shop.queue.includes(c))shop.queue.push(c);
    shop._goTo(c,['P0','P1','P2'][Math.min(shop.queue.length-1,2)]);
    shop._addBag(c);
  }
  function walkTrip(c,dt) {
    const trip=c.upperTrip;
    if(trip.phase==='browse') {
      c.h.walk(dt,0);trip.dwell-=dt;
      if(trip.dwell<=0){trip.phase='back';trip.points=trip.back;trip.index=0;}
      return;
    }
    const target=trip.points[trip.index];
    if(!target) {
      if(trip.phase==='out'){trip.phase='browse';trip.dwell=2.5;return;}
      queueCustomer(c);return;
    }
    const dx=target.x-c.x,dz=target.z-c.z,dy=target.y-(c._upperY||0);
    const dist=Math.hypot(dx,dz,dy);
    if(dist<.055) {
      c.x=target.x;c.z=target.z;c._upperY=target.y;trip.index++;
    } else {
      const k=Math.min(1,(c.speed*.82*dt)/dist);
      c.x+=dx*k;c.z+=dz*k;c._upperY=(c._upperY||0)+dy*k;
      if(Math.hypot(dx,dz)>.02)c.heading=Math.atan2(dx,dz);
    }
    c.h.group.position.set(c.x,c._upperY||0,c.z);
    c.h.group.rotation.y=c.heading;c.h.walk(dt,1);
  }
  shop._step = function(c,dt) {
    if(c.upperTrip){walkTrip(c,dt);return;}
    if(c.state==='visit_upper' && !c.path.length) {
      c.upperTrip=makeTrip(c);c._upperY=0;
      if(!c.upperTrip)queueCustomer(c);
      return;
    }
    const previous=c.state;
    oldStep(c,dt);
    if(previous==='browse' && c.state==='queue' && !c.upperVisited && g.data?.marketBuild?.upper) {
      const upperStock=g.data.marketBuild.items.some(a=>a.floor===1 && a.x!==null && c.wants.some(k=>(g.data.fixtures[a.id]?.[k.pid]||0)>0));
      if(upperStock || shop.rnd()<.65) {
        shop.queue=shop.queue.filter(x=>x!==c);
        c.state='visit_upper';c.path=[];c.target=null;shop._goTo(c,'E');
      } else c.upperVisited=true;
    }
  };

  // The sidewalk remains; the duplicate crossing in front of the market was removed.
  const parent=new T.Group(); w.scene.add(parent);
  const box=(sx,sy,sz,x,y,z,color,collide=false) =>
    w.b(sx,sy,sz,x,y,z,color,{parent,cast:false,collide});
  box(60,.08,1.5,0,.02,15.35,0xe2d6c4);
  box(2.0,.07,4.5,-24,.04,16.4,0xe2d6c4);

  // Open-front neighborhood restaurant at x -24, z 19.
  box(8,.12,6,-24,0,19,0xe3c49d);
  box(.18,3.2,6,-28,0,19,0xc67b56,true);
  box(.18,3.2,6,-20,0,19,0xc67b56,true);
  box(8,3.2,.18,-24,0,22,0xc67b56,true);
  box(2.9,2.5,.18,-26.55,0,16,0xefdfc7,true);
  box(2.9,2.5,.18,-21.45,0,16,0xefdfc7,true);
  box(8,.24,6.3,-24,3.2,19,0x6d4436);
  box(8,.6,.25,-24,2.5,15.88,0x80412e);
  const tex=w.canvasTex(512,100,(ctx,ww,hh)=>{
    ctx.fillStyle='#80412e';ctx.fillRect(0,0,ww,hh);ctx.fillStyle='#fff0c9';
    ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold 51px Arial';ctx.fillText('ŞEHİR LOKANTASI',ww/2,hh/2);
  });
  const sign=new T.Mesh(w.geo('plane'),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));
  sign.scale.set(6.5,.7,1);sign.position.set(-24,2.83,15.73);parent.add(sign);
  // Table and two chairs. Table has its own collider, not the seating area.
  box(1.5,.12,1.0,-24,.72,19.1,0x995e3c,true);
  for(const x of [-24.55,-23.45])for(const z of [18.8,19.4])box(.09,.72,.09,x,0,z,0x75432b);
  for(const z of [17.95,20.25]) {
    box(.65,.1,.65,-24,.45,z,0x71472f);box(.65,.65,.08,-24,.5,z+(z<19.1?-.28:.28),0x71472f);
  }
  for(const x of [-24.4,-23.6]) {
    const plate=new T.Mesh(new T.CylinderGeometry(.17,.17,.025,12),w.mat(0xf5efe1));
    plate.position.set(x,.87,19.1);parent.add(plate);
  }
  w.addInteractable({id:'city-restaurant-table',label:{tr:'🍽️ Lokantada yemek ye',en:'🍽️ Eat at the restaurant',az:'🍽️ Yemək ye',ru:'🍽️ Поесть'},box:[2.8,1.8,1.0,-24,0,17.2],action:openMenu});

  // A scenic second-floor dining room over the existing restaurant.
  const upperFloor=3.2, upperGlass=MMS_NIGHT.reg(w.mat(0x547482,{emissive:0xffc979,emissiveIntensity:0,opacity:.72,transparent:true}));
  box(8,.14,6,-24,upperFloor,19,0xe7dcc8);
  box(.2,3.1,6,-28,3.34,19,0x8a563f); box(.2,3.1,6,-20,3.34,19,0x8a563f);
  box(8,3.1,.18,-24,3.34,22,0x8a563f); box(8,.12,6.2,-24,6.44,19,0x4a3d36);
  // Panoramic glazing and a balcony rail leave the city view open.
  box(8,.18,.18,-24,3.34,16,0x8a563f);
  for(const x of [-27,-24,-21]) { const pane=new T.Mesh(w.geo('box'),upperGlass);pane.scale.set(2.55,2.35,.07);pane.position.set(x,4.68,16.05);parent.add(pane); }
  box(8,.08,.16,-24,4.12,15.86,0x714b3a); box(8,.08,.16,-24,5.88,15.86,0x714b3a);
  for(const x of [-27.8,-26,-24,-22,-20.2]) box(.08,1.15,.08,x,3.34,15.72,0x714b3a);
  // Exterior stair silhouette: the interaction animates the floor transition, while these steps make the access legible.
  for(let i=0;i<12;i++) box(1.35,.16,.5,-29.05,.04+i*.255,16.45+i*.43,0x80543d);
  box(.08,3.25,.08,-29.75,.04,18.9,0x4f4640); box(.08,3.25,.08,-28.35,.04,18.9,0x4f4640);
  box(8,.1,.18,-24,4.48,15.8,0x714b3a);
  const skySignTex=w.canvasTex(512,96,(ctx,ww,hh)=>{ctx.fillStyle='#693a2b';ctx.fillRect(0,0,ww,hh);ctx.strokeStyle='#f2cf65';ctx.lineWidth=6;ctx.strokeRect(4,4,ww-8,hh-8);ctx.fillStyle='#fff0c9';ctx.font='900 44px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('MANZARALI ÜST KAT',ww/2,hh/2);});
  const skySign=new T.Mesh(w.geo('plane'),new T.MeshBasicMaterial({map:skySignTex,side:T.DoubleSide}));skySign.scale.set(5.6,1.0,1);skySign.position.set(-24,5.38,15.78);parent.add(skySign);
  // Warm ceiling lamps and exterior street lighting are real point lights, not fake ground patches.
  for(const [x,z] of [[-26,18],[-22,18],[-26,20],[-22,20]]) {
    box(.35,.07,.35,x,6.15,z,0xffe3a0); if(x===-26) MMS_NIGHT.light(w,x,5.3,z,0xffd28a,2.4,12);
  }
  for(const [x,z] of [[-30,15.2],[-18,15.2],[-30,23],[-18,23]]) {
    w.cyl(.07,3.1,x,.04,z,0x414a52,{cast:false,low:true});
    w.put('sphere',.28,.28,.28,x,3.24,z,MMS_NIGHT.reg(w.mat(0xffd98a,{emissive:0xffcf78})),{cast:false,low:true});
    if(z===15.2) MMS_NIGHT.light(w,x,3.4,z,0xffd28a,3,14);
  }
  // Stair interactions switch the camera between the ground floor and a bounded upper dining floor.
  function enterUpper() {
    if(g.player.marketUpper && !g.player.cityRestaurantUpper) { g.ui.toast(L('exitMarket')); return; }
    g.player.cityRestaurantUpper=true;
    g.player.marketUpper={bounds:{minX:-27.8,maxX:-20.2,minZ:16.2,maxZ:21.8},colliders:[]};
    g.fpsCam.eyeHeight=4.82; g.player.setPosition(-24,19); g.fpsCam.update(0,g.player.pos,0);
    g.ui.toast(L('wentUp'),3000);
  }
  function exitUpper() {
    if(!g.player.cityRestaurantUpper)return;
    g.player.cityRestaurantUpper=false; g.player.marketUpper=null; g.fpsCam.eyeHeight=1.62;
    g.player.setPosition(-24,15.0); g.fpsCam.update(0,g.player.pos,0);
  }
  w.addInteractable({id:'city-restaurant-up',label:{tr:'⬆️ Manzaralı üst kata çık',en:'⬆️ Go to scenic dining floor',az:'⬆️ Mənzərəli mərtəbəyə qalx',ru:'⬆️ На видовой этаж'},box:[2.2,2.2,1.4,-24,0,15.8],action:enterUpper});
  w.addInteractable({id:'city-restaurant-down',label:{tr:'⬇️ Alt kata in',en:'⬇️ Go downstairs',az:'⬇️ Aşağı en',ru:'⬇️ Вниз'},box:[1.4,2.0,1.4,-27,upperFloor,20.6],action:exitUpper});
  w.addInteractable({id:'city-restaurant-sky-table',label:{tr:'🥂 Manzaralı masada yemek ye',en:'🥂 Dine at the scenic table',az:'🥂 Mənzərəli masada yemək ye',ru:'🥂 Ужин с видом'},box:[2.8,1.8,1.4,-24,upperFloor,18.4],action:openSkyMenu});
  box(1.8,.12,1.0,-24,3.92,19.1,0x995e3c);
  for(const x of [-24.68,-23.32])for(const z of [18.75,19.45])box(.09,.72,.09,x,3.34,z,0x75432b);
  for(const z of [17.95,20.25]){box(.65,.1,.65,-24,3.79,z,0x71472f);box(.65,.65,.08,-24,3.84,z+(z<19.1?-.28:.28),0x71472f);}
  const css=document.createElement('style');
  css.textContent='#restaurant-ui{display:none;position:fixed;inset:0;z-index:120;background:#09160dc9;align-items:center;justify-content:center;padding:14px;font:15px system-ui;color:#26372b}#restaurant-ui.open{display:flex}#restaurant-ui .panel{width:min(440px,100%);max-height:90vh;overflow:auto;background:#f8f1e3;border-radius:16px;padding:20px;box-shadow:0 16px 50px #0007}#restaurant-ui h2{margin:0 0 5px}#restaurant-ui p{line-height:1.4}#restaurant-ui button{width:100%;padding:13px;border:0;border-radius:9px;margin:4px 0;background:#a94e30;color:white;font:700 15px system-ui;cursor:pointer}#restaurant-ui button:disabled{opacity:.5}#restaurant-ui button.close{background:#d9dfd5;color:#26372b}';
  document.head.appendChild(css);
  const ui=document.createElement('div');ui.id='restaurant-ui';document.body.appendChild(ui);
  for(const ev of ['pointerdown','touchstart','mousedown','click'])ui.addEventListener(ev,e=>e.stopPropagation());
  let dining=0, menuKind=null;
  function openSkyMenu() {
    if(!g.data || g.state!=='playing' || !g.player.cityRestaurantUpper)return;
    const partner=MMS_PEOPLE.girlfriend(),family=MMS_PEOPLE.family();
    const balance=Math.floor(g.data.money),date=!!partner&&family;
    menuKind='sky';
    ui.innerHTML=`<div class="panel"><h2>${L('skyTitle')}</h2><p>${L('skyBalance',{balance})}</p>
      <button data-sky="solo" ${balance<60||dining>0?'disabled':''}>${L('skySolo')}</button>
      <button data-sky="date" ${!date||balance<120||dining>0?'disabled':''}>${L('skyDate')}</button>
      <p>${L(date?'skyPartner':'noPartner')}</p><button class="close">${L('close')}</button></div>`;
    ui.classList.add('open');g.setInputLocked(true);ui.querySelector('.close').onclick=closeMenu;
    ui.querySelectorAll('[data-sky]').forEach(b=>b.onclick=()=>{
      const isDate=b.dataset.sky==='date',price=isDate?120:60,p=MMS_PEOPLE.girlfriend();
      if(g.data.money<price || (isDate&&(!p||dining>0||!MMS_PEOPLE.beginDining(-23.28,19.1,upperFloor))))return;
      g.data.money-=price;if(isDate){MMS_PEOPLE.dateReward();dining=10;}
      g.saveNow();g.audio.play('cash');closeMenu();g.ui.toast(L(isDate?'skyStarted':'enjoySky'),3500);
    });
  }
  function openMenu() {
    if(!g.data || g.state!=='playing')return;
    const partner=MMS_PEOPLE.girlfriend();
    const nearby=partner && partner.state==='follow' && Math.hypot(partner.x-g.player.pos.x,partner.z-g.player.pos.z)<8;
    const balance=Math.floor(g.data.money);
    menuKind='ground';
    ui.innerHTML=`<div class="panel"><h2>${L('title')}</h2><p>${L('balance',{balance})}</p>
      <button data-meal="solo" ${balance<45?'disabled':''}>${L('solo')}</button>
      <button data-meal="date" ${!nearby || balance<90 || dining>0?'disabled':''}>${L('date')}</button>
      <p>${L(nearby?'nearby':'invite')}</p><button class="close">${L('close')}</button></div>`;
    ui.classList.add('open');g.setInputLocked(true);
    ui.querySelector('.close').onclick=closeMenu;
    ui.querySelectorAll('[data-meal]').forEach(b=>b.onclick=()=>{
      const date=b.dataset.meal==='date', price=date?90:45;
      const p=MMS_PEOPLE.girlfriend();
      if(g.data.money<price || (date && (!p || p.state!=='follow' || Math.hypot(p.x-g.player.pos.x,p.z-g.player.pos.z)>=8 || dining>0)))return;
      if(date && !MMS_PEOPLE.beginDining(-24,20.25))return;
      g.data.money-=price;
      if(date){MMS_PEOPLE.dateReward();dining=8;}
      g.saveNow();g.audio.play('cash');closeMenu();
      g.ui.toast(L(date?'together':'enjoy'),3500);
    });
  }
  function closeMenu(){menuKind=null;ui.classList.remove('open');g.setInputLocked(false);}
  const oldLanguage=g.ui.setLanguage.bind(g.ui);
  g.ui.setLanguage=function(lang){
    const result=oldLanguage(lang);
    if(ui.classList.contains('open')){if(menuKind==='sky')openSkyMenu();else if(menuKind==='ground')openMenu();}
    return result;
  };
  const oldUpdate=g.depot.update.bind(g.depot);
  g.depot.update=function(dt,...args){
    const r=oldUpdate(dt,...args);
    if(dining>0){dining-=dt;if(dining<=0)MMS_PEOPLE.endDining();}
    return r;
  };
  const oldReset=g.depot.reset.bind(g.depot);
  g.depot.reset=function(...args){if(dining>0){MMS_PEOPLE.endDining();dining=0;}if(g.player.cityRestaurantUpper)exitUpper();if(ui.classList.contains('open'))closeMenu();return oldReset(...args);};
  const oldToMenu=g.toMenu.bind(g);g.toMenu=function(...args){if(g.player.cityRestaurantUpper)exitUpper();if(dining>0){MMS_PEOPLE.endDining();dining=0;}return oldToMenu(...args);};
})();
