/* Stadyum arkası: dekoratif modern binalar ve çevre yoluna bağlı kavşak. */
(function () {
  'use strict';
  const g = window.__mms;
  if (!g || !window.THREE) return;
  const T = window.THREE, w = g.world;
  const regions = __req('player').REGIONS;
  const group = new T.Group();
  w.scene.add(group);
  const no = { parent: group, cast: false, receive: false };
  const b = (sx, sy, sz, x, y, z, color) => {
    const mesh = w.b(sx, sy, sz, x, y, z, color, no);
    mesh.userData.static = true;
    return mesh;
  };
  const asphalt = 0x444a50, white = 0xf2f1e9, pavement = 0xd0ccc4;

  // Ana çevre yolu z=107..117 aralığında zaten var. Yeni yüzeyler onun
  // kenarında biter, kavşakta üst üste binen asfalt düzlemi oluşturmaz.
  b(123, .06, 6, 92.5, -.16, 128, 0x7fcf6b);
  b(10, .055, 41, 36.5, .03, 86.5, asphalt);    // z=66..107
  b(10, .055, 3, 36.5, .03, 118.5, asphalt);   // z=117..120
  b(10, .055, 3, 149, .03, 118.5, asphalt);    // doğu çevre yoluna bağlantı
  b(122.5, .055, 10, 92.75, .03, 125, asphalt); // z=120..130
  regions.push(
    {minX:31.5,maxX:41.5,minZ:65.5,maxZ:130},
    {minX:31.5,maxX:154,minZ:120,maxZ:130},
    {minX:144,maxX:154,minZ:116.5,maxZ:130},
    {minX:-32,maxX:31.5,minZ:87.5,maxZ:107}
  );

  // Dur çizgileri, şerit ayırıcılar ve dört kollu yaya geçidi.
  for (let z=72; z<101; z+=6) b(.13,.02,2.2,36.5,.09,z,white);
  for (let x=46; x<144; x+=8) b(2.3,.02,.13,x,.09,125,white);
  for (let x=32.3; x<=40.8; x+=1.15) {
    b(.54,.025,2.0,x,.092,104.8,white);
    b(.54,.025,1.8,x,.092,119.0,white);
  }
  for (let z=107.6; z<=116.5; z+=1.18) {
    b(1.9,.025,.54,29.8,.092,z,white);
    b(1.9,.025,.54,43.2,.092,z,white);
  }
  b(10,.025,.16,36.5,.092,102.8,white);
  b(.16,.025,10,27.9,.092,112,white);
  b(.16,.025,10,45.1,.092,112,white);

  // Kaldırımlar yalnızca trafik şeritlerinin dışında.
  b(1.3,.08,13.5,30.85,.01,97.75,pavement);
  b(1.3,.08,13.5,42.15,.01,97.75,pavement);
  b(56,.08,1.5,-.5,.01,104.75,pavement);
  for (const [x,z] of [[29.2,104.7],[43.8,104.7],[29.2,119.2],[43.8,119.2]]) {
    b(.15,3.7,.15,x,.05,z,0x26323a);
    b(.52,1.15,.42,x,2.65,z,0x26323a);
    // Şimdilik görsel trafik ışığıdır, araçları durdurma kuralı değildir.
    b(.2,.2,.03,x,3.42,z-.23,0xdb4c3f);
    b(.2,.2,.03,x,3.08,z-.23,0xd9ae45);
    b(.2,.2,.03,x,2.74,z-.23,0x65ba79);
  }
  for (const z of [76,91,101]) for (const x of [30.8,42.2]) {
    b(.12,4,.12,x,.05,z,0x3a4650);
    b(.8,.10,.14,x+(x<36.5?.32:-.32),3.93,z,0x3a4650);
    b(.22,.12,.18,x+(x<36.5?.66:-.66),3.82,z,0xffe3a0);
  }

  // Stadyumun arkasındaki birbirinden farklı, girilemeyen şehir binaları.
  const buildings = [
    {x:-22,z:97,w:10,d:7,h:8.0,wall:0xd8dedb, trim:0x375565,glass:0x76a6bf},
    {x:-7.5,z:97,w:10,d:7,h:11.2,wall:0xb4c3c9,trim:0x344653,glass:0x6f9db4},
    {x:8,z:97,w:11,d:7,h:9.3,wall:0xe2d6c3,trim:0x856a58,glass:0x86b5c4},
    {x:23,z:97,w:9,d:7,h:7.3,wall:0x9caeb9,trim:0x273d4b,glass:0xa9ced8}
  ];
  for (const [index, q] of buildings.entries()) {
    const front=q.z+q.d/2;
    b(q.w,q.h,q.d,q.x,0,q.z,q.wall);
    w.colliders.push({minX:q.x-q.w/2,maxX:q.x+q.w/2,minZ:q.z-q.d/2,maxZ:q.z+q.d/2});
    b(q.w+.35,.28,q.d+.35,q.x,q.h,q.z,q.trim);
    b(q.w,.34,.14,q.x,.15,front+.08,q.trim);
    const floors=Math.floor((q.h-1.2)/2.05);
    for (let f=0;f<floors;f++) {
      const y=1.0+f*2.05;
      for (let j=0;j<4;j++) {
        const x=q.x-q.w/2+(j+.5)*q.w/4;
        b(q.w/5.1,1.25,.09,x,y,front+.07,q.glass);
        b(.07,1.25,.05,x,y,front+.13,q.trim);
      }
      if(index===1 || index===3) b(q.w,.13,.2,q.x,y+1.42,front+.09,q.trim);
    }
    b(1.45,2.1,.12,q.x,.05,front+.17,q.trim);
    b(1.2,.1,.7,q.x,2.25,front+.42,q.trim);
    if(index===0) b(2.1,1.8,1.5,q.x-2.5,q.h+.27,q.z+.3,q.trim);
    if(index===2) for(const dx of [-4,-3.75,-3.5]) b(.10,q.h-.5,.08,q.x+dx,.2,front+.16,q.trim);
    if(index===3) b(q.w*.7,.22,1.3,q.x,q.h-.8,front+.45,q.trim);
  }
  // Oyun motorunun mevcut statik birleştirmesiyle çizim sayısını azalt.
  w.mergeStatic(group);
})();
