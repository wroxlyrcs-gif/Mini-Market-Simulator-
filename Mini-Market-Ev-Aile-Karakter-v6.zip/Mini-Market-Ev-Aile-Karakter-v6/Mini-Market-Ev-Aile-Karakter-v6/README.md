# FINAL ADAYI

Güncel giriş `mini-market-final.html` (veya `index.html`). Casino, ikinci market, kafe ve ev genişletmesi bu girişte birleşir. Ayrıntılar ve açık doğrulama eksikleri için `FINAL-OKU-BENI.txt` dosyasına bakın.

# MINI MARKET SIMULATOR v3.9

## Şehir yolları ve park etkinlikleri
- Güncel dosya `mini-market-ikinci-market.html`. Mahalle yolunun doğusuna, mevcut çevre yoluna bağlanan bir yol eklendi. Yol ve kaldırım çizgilerinde bilinen üst üste binme/yükseklik sorunlarının bir kısmı düzeltildi; yeni yolun ağaç çarpışması ve kayıt sınırı da güncellendi.
- Atlıkarınca kaldırıldı. Yerinde küçük bir piknik alanı ve üç turlu taş-kağıt-makas masası var. Pikniği başlatınca kısa süre alanda kal; yürüyerek ayrılırsan iptal olur. Masaya bakıp etkileşime basarak oyunu açabilirsin.
- Dış mahalledeki mevcut futbol sahasına hareket eden bir top eklendi. Topa bakıp etkileşime bas; iki kale direği arasından geçirince gol olur ve top ortaya döner.
- Etkinlikler anlık eğlencedir; puanlar veya piknik kayda işlenmez, para ödülü verilmez. Şehir saati normal akmaya devam eder.
- `node tests/city-leisure.test.cjs` ve `node tests/city-road-connectivity.test.cjs`: etkinlik mantığı, yol ağının temel ayak izleri, çizgi yükseklikleri ve dış mahallede konum kaydı. Bunlar mantık/koordinat testleridir.
- **Sınırlar:** Bu ortamda WebGL görüntüsü, tüm yolların araçla uçtan uca sürüşü ve fiziksel telefondaki performans test edilmedi. Siyah görünen tüm görsel hataların giderildiği doğrulanmadı. Yeni paketi açmadan önce eski tarayıcı kaydını yedekle.

## Akıcılık güncellemesi
- Yeni FPS tercihi olmayan Android ve diğer mobil cihazlar 30 FPS sınırıyla başlar; daha önce seçilen 30 / 45 / 60 tercihi korunur. İstenirse Ayarlar'dan değiştirilebilir.
- İkinci markette arka plandaki değişiklikler kısa aralıklarla toplu kaydedilir. Sipariş, satın alma ve uygulamadan çıkma gibi açık kayıt çağrıları beklemeden yapılır; başarısız toplu kayıt tekrar denenir.
- İkinci market çarpışma dönüşümleri gerektiğinde üretilir ve nesneler yeniden kullanılır. Oyun dünyası ve çarpışma kuralları aynı kalır.
- Testler: `node tests/save-batch.test.cjs`, `node tests/second-collider-budget.test.cjs`, `node tests/performance-budget.test.cjs` ve mevcut regresyon testleri. Bunlar mantık testleridir.
- **Sınır:** WebGL, gerçek Android cihaz ve uzun süreli oynanış bu ortamda ölçülmedi. Donmanın tüm cihazlarda kesinlikle olmayacağı garanti edilemez. ZIP'i kullanmadan önce mevcut tarayıcı kaydını yedekleyin.

## Grafik ve performans güncellemesi
- Güncel sürüm: `mini-market-ikinci-market.html`. Ayarlar ekranında mevcut Düşük/Orta/Yüksek seçeneklerine ek olarak **30 / 45 / 60 FPS sınırı** bulunur. FPS tercihi ayrı saklanır. Simülasyon döngüsü sınırlandırılmaz; yalnızca çizim sıklığı sınırlandırılır. Ekranın yenileme hızı ve cihaz yükü nedeniyle istenen sayı her cihazda tam yakalanmayabilir.
- Yola, kaldırımlara ve bazı bina yüzeylerine paylaşılan küçük dokular; bazı camlara düşük maliyetli statik çevre yansıması; akşam/gece için güneş ışığı renkleri eklendi. Bu yansıma gerçek zamanlı aynalama değildir; tüm binalar ve modeller yeniden yapılmadı.
- Çözünürlük, FPS hedefine göre uzun süreli yükte kademeli düşer ve durum iyileşince geri çıkar. Görsel kalite seçimi değiştirilmez. Düşük kalite veya ağır yükte cam yansıması geçici kapatılır; iyileşince yeniden açılır.
- Uzak şehir sakinlerinin sadece model animasyonu seyreltilir, yürüme/çarpışma/sinyal hesapları devam eder. Trafiğin sabit rota uzunlukları önbelleğe alındı. Mevcut çizim alanı dışı eleme, gölge aralığı ve NPC LOD korunur.
- Hata ayıklamada `window.__mmsPerformance.inspect()` hedef/ölçülen FPS, çizim ve Three.js geometri/doku sayılarını gösterir. Tarayıcı destekliyorsa JS yığını da görünür; bunlar gerçek GPU belleği ölçümü değildir.
- Node testleri: `node tests/performance-budget.test.cjs`, `node tests/graphics-polish.test.cjs`, `node tests/city-animation-budget.test.cjs`, mevcut regresyon testleri ve optimize edilmiş trafik modülü ile trafik güvenliği testi. 10.000 ışık güncellemesinde yeniden doku oluşturulmadığı kontrol edildi.
- **Sınırlar:** Testler mantık/simülasyon testleridir. Bu ortamda WebGL sahnesi, fiziksel Android cihaz, gerçek FPS, GPU belleği ve uzun süreli oynanış doğrulanmadı. Her telefonda akıcılık veya donmasız çalışma garanti edilmez. Yeni ZIP'i kullanmadan önce tarayıcı kayıtlarını yedekleyin; dosya konumu veya tarayıcı değişince kayıtlar otomatik taşınmayabilir.

## Son güncelleme: market geçidi, park NPC'leri ve mobil grafik
- Marketin önündeki eski geçit/sinyal kaldırıldı; şehir ve stadyum güzergâhındaki diğer geçişler korunuyor.
- 18 şehir sakininin rota hedeflerinin 10'da 4'ü park içinde; sekiz bankın tamamında oturan NPC var.
- Maç tezahüratı `stadium-chant.mp3` maç saatinde (19:40-22:00), oyuncu stadyuma yakınken ve ses efektleri açıkken çalar. Uzaklık, duraklatma ve tarayıcı ses izni davranışı korunur.
- Mobil grafik profili ana `mini-market-simulator.html` ve `mini-market-yeni-surum.html` sürümlerine eklendi. Çözünürlük yük durumuna göre ayarlanır; gerçek telefondaki FPS cihaza bağlıdır.

## İkinci market bilgisayarı
- `mini-market-ikinci-market.html` now reuses the first market's `DepotSystem`, `SiteUI`, `MarketBuild` and worker features instead of the old one-screen panel.
- The second shop has its own saved balance, stock, register, orders, upgrades, staff and furniture layout under `mms_citymarket_depot_v1`; the first shop's save and wallet stay separate.
- Product ordering, delivery/boxes, stockroom, shelf placement, rear expansion and upper-floor construction use the same systems as the first store. The city's existing second-store purchase price still comes from the player's wallet.
- Automated checks cover the shared UI hooks and first-market regression suite; the 3D scene and FPS still need a real browser/phone playtest.

## İlk market: görünür genişletme ve bölgeye özel raf görevlileri
- Satın alınmamış arka salon ve üst kat için yarı saydam duvar, zemin ve pencerelerle görünür, kilitli bir önizleme eklendi. Bu önizleme açılma veya çarpışma kurallarını değiştirmez. Satın alınan üst katın arka pencere çerçeveleri doğru cepheye taşındı.
- Bilgisayarda **Marketi Büyüt** ile arka salon genişletilir. İlk seviye 600 $, ikinci seviye 1.200 $; ikinci seviyeden sonra **Yapı ve Eşya** ekranında üst kat 3.500 $ karşılığında açılır. Mevcut fiyatlar ve kayıt alanları korunur.
- **İşçiler** ekranından raf görevlisinin alanı seçilebilir: ana reyon, arka salon veya üst kat. Arka salon görevlisi ilk arka genişletmeden sonra, üst kat görevlisi üst kat inşa edilince alınabilir. Toplam raf görevlisi sınırı dört, ücret kişi başına 25 $/gündür. Alanlara raf yerleştirmek ve depoda ürün bulundurmak gerekir.
- Eski otomatik bölgeli çalışanların kaydı korunur; daha önceki arka salon + üst kat görevli bölgesi de geçerliliğini sürdürür.
- `node tests/market-expansion.test.cjs`: arka salon satın alma, kayıt ve kapı çarpışması mantığı. `node tests/build-translations.test.cjs`: kilitli önizleme geometrisi, üst kat satın alma/merdiven ve üst kata çalışan rotası. `node tests/market-zones.test.cjs`: alan seçimi, kilitler, ücretler, eski kayıtlar ve raf görev planlaması.
- **Sınır:** Testler kod üzerinde dünya ve arayüz taklitleriyle yapıldı. 3D görünüm, gerçek telefon performansı ve uçtan uca oyun oynanışı bu ortamda test edilmedi. Tarayıcı kayıtları dosya konumuna bağlı olabileceğinden paketi açmadan önce eski kayıtları yedekleyin.

## Aşama 2: yaya mantığı için sınırlı güncelleme
- Mevcut şehir sakini yürüyüşüne yerel mesafe kontrolü eklendi. Sakinin önündeki diğer şehir sakinleri ve `trafficBody` işaretli araçlar kontrol edilir; güvenli yan adım veya bekleme uygulanır. İç mekân / üst kat durumu olan kişiler sokak kalabalığına katılmaz.
- Çok yakın ara hedeflere eski doğrudan konum ataması kaldırıldı; normal hareket ve yaya sinyali onayıyla ulaşılır. Ara hedefe varılmadan rota ilerletilmez. Sıfır mesafede sayısal hata önlenir.
- `node tests/pedestrian-steering.test.cjs`: karşılıklı gelen / duran yayalar, araç gövdesi, kırmızı ışık ve sıfır mesafe mantığını sınar.
- `node tests/pedestrian-integration.test.cjs`: gerçek şehir sakini güncellemesini ve gerçek sinyal modülünü hafif dünya taklitleriyle çalıştırır. Karşılıklı yayalar, araç dolu geçit ve ışık değişimi dahil senaryolar sınanır.
- **Sınırlar:** Bu sistem yalnızca mevcut şehir sakini listesine uygulanır; market müşterileri, otobüs yolcuları ve maç günü kalabalığı kapsanmaz. Bütün bina/nesne çarpışmaları, her yol ve takip rotası, gerçek telefon FPS'i, 3D görünüm ve tarayıcı konsolu doğrulanmadı. Polis ceza sistemi eklenmedi. Test edilmemiş özellikler tamamlanmış değildir.

## Dört dil: kısmi çeviri güncellemesi
- NPC konuşmaları, ilişki eylemleri, marketin yapı ve eşya menüsü, lokanta menüsü, haritadaki mevcut yer adları ve araç etkileşimleri için TR/EN/AZ/RU metinleri iyileştirildi. Açık ilgili paneller ve harita dil değişiminde yenilenir.
- Otobüs gibi sistemlerin çevrilebilir nesne şeklindeki bildirimleri artık nesne olarak değil, seçilen dilde gösterilir.
- `node tests/translations.test.cjs`, `node tests/build-translations.test.cjs`, `node tests/restaurant-translations.test.cjs`, `node tests/map-translations.test.cjs`: sözlükleri ve örnek etkileşimleri hafif taklitlerle sınar. Kayıt biçimi değiştirilmedi.
- **Sınır:** Dünya içindeki bazı tabelalar hâlâ tek dillidir; tüm oyun ekranlarında ve 3D tarayıcıda kapsamlı çeviri testi yapılmadı. Bu paket tüm çevirilerin veya 4.0 sürümünün tamamlandığı anlamına gelmez.

## Trafik güvenliği: sınırlı ara güncelleme
- Devam güncellemesi: yapay zekâ araçları oyuncuyla temas ederken veya oyuncunun güvenlik mesafesindeyken oyuncuya doğru ilerlemez; uzaklaşarak sıkışmadan çıkabilir. Otobüs kendi yolcusu varken bu kontrolden muaf tutulur.
- Ana yol ve çevre yolu araçları, hedef hızlarının yanı sıra gerçekten hareket edip etmediklerini bildirir. Takip mesafesi ve polis geçiş kontrolü, kırmızı ışıkta veya engelde duran araçları buna göre değerlendirir.
- Mevcut projeye iki hedefli düzeltme yapıldı. Oyuncu aracı daha önce bir engelle iç içeyse, engelin daha derinine ilerleyemez; geri çıkma ve engele paralel kayma korunur.
- Karakol devriyesinin yol geçişi için kullandığı boşluk kontrolü, ana yoldaki yaklaşan veya yakında duran halk otobüsünü de dikkate alır. Bu değişiklik polis ceza sistemi eklemez.
- `node tests/traffic-safety.test.cjs`: gerçek trafik ve sinyal modüllerini hafif dünya taklitleriyle çalıştırır; oyuncu ve araç çarpışmasından kurtulma, otobüs yolcusu istisnası, duran araçları takip ve polis geçiş kontrolü, araç doğma kontrolü, uzun harekette engel, iki araçla 120 saniyelik takip ve ışıkta durup yeşilde hareket etmeyi sınar.
- `node tests/traffic-signals.test.cjs`: mevcut sinyal evreleri ve yaya/araç geçiş güvenliği mantık testidir. Her iki Node testi de bu ara güncellemede geçti.
- **Sınırlar:** Bunlar 3D tarayıcıda, tüm gerçek şehirde veya fiziksel telefonda yapılmış testler değildir. Trafiğin bütün kilitlenmeleri, tüm polis rotaları ve diğer 4.0 talepleri doğrulanmadı. APK derlenmedi. Kayıt kodu değiştirilmedi; ancak farklı dosya konumları veya tarayıcılar farklı localStorage alanları kullanabilir. Yeni paketi açmadan önce eski kayıtları yedekleyin.

## 4.0 hazırlığı: Aşama 2, spor salonu
- Önceden içi dolu dekor olan GYM açılabilir kapısı, çarpışmalı duvarları ve düşük poligonlu iç mekânıyla erişilebilir hale getirildi. Haritadaki GYM işareti, gece ışığı ve yağıştan koruma eklendi.
- Koşu bandı, bisiklet, bench press, squat ve dambıl etkileşimleri süreli antrenman başlatır; iptal edilebilir ve tamamlanan antrenmanlar kayıtlı oyuna işlenir. Kayıtlar resepsiyondan görülebilir.
- İkinci koşu bandında spor yapan bir NPC ve resepsiyon görevlisi bulunur. Su otomatı 5 $ karşılığında su satışı kaydeder; dolap kapısı ve duş açılıp kapanabilir.
- Eski para/gün/personel kaydı, kapı çarpışması, beş egzersiz, iptal, su, duş, dolap, NPC hareketi, dört dilde yeni arayüz ve internetsiz dokunmatik telefon benzetimi kontrol edildi. Aşama 1 trafik testleri tekrar çalıştırıldı. İsteğe bağlı tarayıcı testi için Playwright kurulu bir sistemde `node tests/gym-smoke.cjs` çalıştırılabilir.
- **Sınırlar:** Egzersizler kısa oyun içi animasyonlar ve kayıtlı sayaçlar kullanır; gerçekçi tam vücut oyuncu fiziği değildir. Ayna gerçek zamanlı yansıma değildir, duş ve dolap ayrı bir kıyafet/envanter sistemi içermez. Kafe, bağımsız ikinci market, APK derlemesi ve istenen diğer 4.0 özellikleri henüz tamamlanmadı. Gerçek telefon testi yapılmadı.
- Tarayıcı kayıtları dosyanın açıldığı konuma bağlı olabilir. Yeni klasörü açmadan önce mevcut kaydını yedekle; önceki kayıt biçimi korunmuştur.

## 4.0 hazırlığı: Aşama 1, trafik ve yaya geçitleri
- Mevcut oyunun üzerine kuruldu. Ana caddede iki, merkez bulvarında bir ve bölge yolunda bir geçit için eşgüdümlü araç/yaya sinyalleri eklendi.
- Araçlar ve otobüs kırmızıda durur, geçitte olan araçlar alanı boşaltır. Mevcut yaya rotalarındaki kişiler araç alanı boş ve yaya ışığı yeşil olduğunda geçer; geçiş tamamlanana kadar araç ışığı yeşile dönmez.
- Eski yakınlık kuralının yayaları ve trafiği birbirini bekletmesi giderildi. Market otoparkı tek şeritli giriş/çıkış için sıraya alındı, çıkışta ana cadde boşluğu beklenir ve park halindeki bir araç giriş güzergâhından taşındı.
- Testler: yeşil/sarı/kırmızı/yaya ve geçiş temizliği mantığı; 120 saniyelik simülasyonda 480 aralıklı trafik çarpışma taraması; otobüs ve yayalarla 210 saniyelik simülasyon; önceki kayıt üzerinden para, gün ve işçi yükleme; internetsiz telefon benzetiminde oyun döngüsü. `node tests/traffic-signals.test.cjs` mantık testini tekrar çalıştırır.
- **Sınırlar:** Yeni sinyaller yalnız tanımlı geçitleri kapsar. Bölge yolundaki geçitte henüz şehir yayası rotası yoktur. Mevcut kavşaktaki eski dekoratif ışıklar, oyuncunun kullandığı araç için ceza sistemi, tüm yayaların karşılıklı çarpışması ve diğer 4.0 talepleri bu aşamada tamamlanmadı. Testler benzetimdir; gerçek telefon ve bütün trafik durumları doğrulanmadı. Android araçları bulunmadığından APK derlenmedi.
- Bu aşama, eski dosyaları ve kayıt biçimini korur; tarayıcı kayıtları dosyanın açıldığı konuma bağlı olabilir. Yeni klasörü açmadan önce mevcut kaydı yedekle.

## Telefon için grafik iyileştirmesi
- Orta ve yüksek kalitede, destekleyen cihazlarda kenar yumuşatma açılır; düşük bellekli cihazlarda akıcılık için kapalı tutulur.
- Telefon ekranında çözünürlük sınırı ve dokuların eğik açılardaki keskinliği iyileştirildi. Büyük ekranlarda piksel bütçesi, ağır sahnelerde otomatik çözünürlük ayarı ve önceki performans iyileştirmeleri korunur.
- “Düşük” kaliteyle başlattıktan sonra kenar yumuşatmayı açmak için kaliteyi Orta/Yüksek seçip oyunu yeniden aç. Ayar saklanır.
- Tüm önceki özellikler aynı oyun projesinde bulunur. ZIP içindeki HTML, JavaScript ve ses dosyalarını birlikte tut.
- Three.js (r185) artık paketin içindedir, bu yüzden temel oyun internet olmadan açılabilir. İsteğe bağlı Google yazı tipleri internetsizse sistem yazı tipine geçer.
- Aşağıdaki eski sürüm notlarında geçen Three.js internet gereksinimi bu güncel paket için geçerli değildir.
- Telefon benzetimi masaüstü Chromium ile yapılmıştır; gerçek telefonlarda kalite ve akıcılık cihaza göre değişebilir.

## Grafik ve performans güncellemesi
- Şehirde ekran dışında kalan statik yapılar daha küçük parçalara ayrılarak çizimden çıkarılır; yol işaretleri de birleştirilir.
- Gece en yakın lambalar gerçek ışık verir, uzak pencereler ve lambalar parlamaya devam eder. Gece dokuları ve hava efektleri gereksiz yere sürekli güncellenmez.
- Uzun süre düşük kare hızında çözünürlük kademeli azaltılır; performans iyileşince yeniden yükselir. Ayarlarda seçilen kalite değiştirilmez. Duraklatmada ve sekme arka plandayken çizim yükü azaltılır.
- Test: grafik ve oyun açılışı, üç sahne için çizim sayısı, kalite uyarlaması, gece/gündüz, pano ve işçi işlemleri masaüstü başsız Chromium'da kontrol edildi. Testte yerel Three.js kopyası kullanıldı; oyun kendi CDN sürümünü internetten yüklemeye devam eder. Fiziksel telefon ve her cihaz için akıcılık garanti edilemez.

## Güncelleme: otobüs, reklam panoları ve market
- 25 numaralı hattın durakları seyrekleştirildi. Otobüs duraktayken kapısına bakıp etkileşime bas, açılan haritadan başka bir durak seç; otobüs hedefte otomatik indirir. İstersen yolculuk sırasında daha erken inebilirsin.
- Otobüsün duraktan önce takılmasına yol açan fren hatası ve bazı çarpışma durumları düzeltildi. Dar stadyum dönüşü yerine ana cadde ve çevre yolu kullanılır; kavşak geçişleri için ek öncelik kontrolü vardır.
- Panolar yeni oyunda boş başlar ve daha açık yol kenarlarına yerleştirilir. Bilgisayardaki “Reklam panoları” sekmesinden her panoya ayrı metin yazabilir veya metni silerek panoyu boşaltabilirsin. Önceki pano kayıtları korunur.
- Henüz alınmamış arka genişleme ve üst kat, dışarıdan yeşil kilitli yapı taslağı olarak görünür. Arka salonu “Marketi Büyüt” menüsünden satın al; en az iki arka genişlemeden sonra “Yapı ve Eşya” bölümünden üst katı inşa et.
- Dört adede kadar raf görevlisi alınabilir; ana reyon, arka salon ve üst kat görevleri sırayla atanır. Her görevli 25 $/gün kazanır. Çalışanlar artık başka bir çalışanın açıp depoya bıraktığı ürünlerden de raf doldurabilir.
- Dosyaları aynı klasörde tutup `mini-market-simulator.html` dosyasını aç. Oyun Three.js kitaplığını internetten yükler. Tarayıcı testlerinde yerel Three.js test kopyası kullanıldı; tüm trafik durumları ve fiziksel telefon performansı doğrulanmadı.

## v3.9 (aile hayatı, gece ışıkları, manzaralı restoran ve ikinci rafçı)
- Sevgiliyle park yürüyüşü ve şehir turu eklendi. İlişki 95/100 olduğunda 500 $ ile evlilik teklifi yapılabilir; evlilik durumu mevcut `mms_rel_v1` kaydına eklenir.
- Eş, oyuncunun evinde görünür; ev içi sohbet, ailece vakit geçirme ve yemek hazırlama etkinlikleri eklendi. Akşam saatlerinde mutfakta pişirme animasyonu çalışır; ocak üstüne tencere eklendi.
- Evli çift, 700 $ karşılığında en fazla iki çocuk sahibi olabilir. Çocuk isimleri ve aile durumu `mms_rel_v1` içinde saklanır; aile modelleri evin içinde görünür. Eski ilişki kayıtları okunmaya devam eder.
- Şehir Lokantası'na manzaralı camlı üst kat, balkon korkuluğu ve dışarıdan görünen merdiven eklendi. Zemin kattaki merdiven etkileşimiyle üst kata çıkıp in; üst kattaki masadan tek başına 60 $'a, sevgili/eşinle 120 $'a yemek yiyebilirsin.
- Gece oyuncunun evi, mahalle evleri, restoran ve marketin üst katındaki pencereler sıcak ışıkla parlar; yeni sokak ve cephe lambaları gerçek noktasal ışık üretir. Fazladan ışıklar sınırlı tutuldu; yerde beyaz ışık lekesi oluşturulmadı.
- Marketin arka salon genişletmesi ve ikinci kat inşa edildiğinde üst katın arka cephesi, pencereleri ve tabelası dışarıdan görünür.
- Bilgisayardan ikinci raf görevlisi alınabilir (25 $/gün). İlk görevli ana reyonları, ikinci görevli arka genişleme ve üst kattaki ek rafları doldurur; üst kat rafına çıkmak için merdiven rotası kullanır. İkinci işçinin günlük maaşı da market bakiyesinden düşer.
- `mms_save_v1` ve `mms_rel_v1` anahtarları korunur; mevcut NPC ilişkileri ve çalışan kayıtları geriye dönük okunur. JavaScript sözdizimi ve ikinci rafçı işe alım/stok alanı planı simüle edildi. Three.js CDN gerektirdiği için bu paket gerçek 3D tarayıcıda ve fiziksel telefonda görsel/FPS testinden geçmedi.

## v3.8 (genişletilmiş otobüs hattı, kapı ve oturma sistemi)
- Mavi-siyah, özgün 360° şehir otobüsü eklendi: ön/arka/camlı yan gövde, dijital 25 numaralı hat tabelası, aynalar, far/stop lambaları, animasyonlu jantlar, detaylı koltuklar, sarı tutamaklar, gösterge paneli, direksiyon ve iç aydınlatma.
- Ön kapıdan biniş, arka kapıdan iniş ve orta kapıdan ek akış vardır. 25 numaralı şehir hattı bu pakette 5 duraklıdır; gerçek trafik çarpışma/araç takip sistemine bağlıdır ve yol doluyken güvenle yavaşlayıp bekler. NPC şoför otobüsü sürer; NPC yolcular ön kapıdan biner, oturur; durakta ayağa kalkıp arka kapıdan yürüyerek iner. Oyuncu da açık ön kapıdan binebilir, ikinci etkileşim düğmesiyle oturup kalkabilir ve sonraki durakta arka kapıdan inebilir.
- Sabit otobüs detayları malzeme başına birleştirildi; kabin NPC sayısı ve yol geometrisi mobil için sınırlı tutuldu. Kapı animasyonu, ön biniş/arka iniş, NPC otur-kalk akışı, oyuncu otur-kalk, 5 durak, trafik beklemesi ve kayıt davranışı yerel simülasyonda test edildi. Gerçek 3D tarayıcı ve fiziksel telefon FPS testi yapılmadı.

## v3.6 (yol kenarı reklam panoları)
- Ana cadde, doğu bulvarı, şehir çıkışı ve mahalle yoluna dört büyük çift yüzlü market reklam panosu eklendi; büyük şehir haritasında da işaretlenir.
- Panoya yaklaşarak etkileşim düğmesiyle metni düzenle; 60 karaktere kadar özel reklam yaz veya hazır metin seç. Her pano ayrı kaydedilir ve oyun yeniden açılınca korunur.
- Yeni panolar için JavaScript sözdizimi, dört pano yerleşimi, varsayılan metin, kayıt/yeniden yükleme, özel reklam ve mobil panel davranışı test edildi.

## v3.5 (12 yeni tam 3D kadın şehir sakini)
- Şehre 12 ek yetişkin kadın NPC eklendi; mevcut yürüme, etkileşim ve ilişki sistemi korunarak ayrı isimler ve kayıt kimlikleri verildi.
- Her model 360° tam gövde 3D'dir: farklı saç modeli/rengi, yüz oranı ve özellikleri, kıyafet katmanı, pantolon/etek, çanta türü, takı ve ayakkabı. Arka saç, çanta ve kıyafet ayrıntıları ön/arka/sağ/sol görünümde gerçek geometri olarak modellenir; referanslar birebir kopyalanmaz, mevcut low-poly oyun dili izlenir.
- Hareketli eklem ve ifade parçaları korunurken sabit karakter geometrileri malzemeye göre birleştirilir; 24 m’den uzakta animasyonlu hafif model, 58 m’den uzakta görünmez LOD kullanılır; ek NPC maliyeti mobil için sınırlandırılır.
- Kayıt, ilişki sistemi, yürüyüş animasyonu ve mobil kontroller korundu. Yerel testler ve sözdizimi denetimleri yapıldı; gerçek cihaz FPS testi yapılmadı.

## v3.4 (market otoparkı ve etkileşimli ev kapısı)
- Marketin soluna dört araçlık işaretli otopark ve ana caddeye bağlanan giriş yolu eklendi. Trafik boşluk buldukça araçlar otoparka girip park ediyor, bekleyip güvenli biçimde tekrar yola çıkıyor.
- Evin ön kapısı artık menteşeli ve animasyonlu; etkileşim düğmesiyle açılıp kapanır, kapalıyken geçişi fiziksel olarak engeller. Ses efekti ve Türkçe/İngilizce/Azerbaycanca/Rusça yönlendirmeleri eklendi.
- Kayıt, market kapısı, mobil kontroller ve mevcut trafik akışı korundu. Kod sözdizimi, otopark geometrisi, araç spawn/aralıkları ve kapı durumu için yerel testler yapıldı; gerçek tarayıcı/mobil görsel testi yapılmadı.

## v3.3 (harita sınırı, şehir çıkışı ve trafik güvenliği)
- Görünen harita kenarındaki gökyüzü sızıntısını önlemek için kesintisiz zemin, oynanabilir alanın ve 160 m kamera görüş sınırının ötesine genişletildi; mevcut dinamik gökyüzü rengi ve mobil kamera aralığı korundu.
- Güney çevre yolundan devam eden şehir çıkış yolu, servis garajı, mahalle parkı, küçük futbol sahası, beş ev, yön tabelaları ve düşük çizim maliyetli ağaçlar eklendi. Büyük harita yeni bölgeyi gösterir.
- Polis devriyeleri iki gerçek trafik şeridinde ilerler; şerit geçişlerinden önce yaklaşan araçların boşluk ve varış süresi kontrol edilir, yeterli boşluk yoksa araç bekler. Trafik için AI Traffic Collision Avoidance (AI-TCA), aynı şeritte takip mesafesi, güvenli spawn noktası ve güvenli yeniden giriş kontrolü eklendi. ZUNEX PETROL istasyonu ve mevcut sistemler korundu.
- Kayıtlar, etkileşimler, mevcut şehir ve mobil kontroller değiştirilmedi. JavaScript sözdizimi ve trafik güvenliği senaryoları yerel simülasyonla kontrol edildi; Three.js CDN erişimi gerektiren gerçek 3D tarayıcı ve fiziksel telefon testi bu pakette yapılamadı.
- ZIP içindeki HTML, JavaScript dosyaları ve `stadium-chant.mp3` aynı klasörde kalmalı. Three.js için internet gerekir.


## Yenilenen stadyum tribünleri
- Tribünlere beton basamaklar, ayrı siyah-beyaz koltuklar, merdiven çizgileri, çatı destekleri ve CITY FC pankartları eklendi. Tasarım gönderilen stadyum fotoğrafından esinlenen low-poly bir yorumdur.
- Maç günü 19:40-22:00 arasında taraftarlar kollarını kaldırıp indirerek tezahürat yapar. Gönderilen videodaki orijinal taraftar sesi ve alkışlar çalar; kayıt Kartal tezahüratı içerir. Hareketler yaklaşık ritme uyar.
- Ses stadyumdan uzaklaştıkça azalır; duraklatmada, menüde ve maç dışında durur. Ses efektleri ayarına bağlıdır. Tarayıcı sesi etkinleştirmek için ilk dokunuşu gerektirebilir. Biletli oyuncunun görüş alanı açık bırakılır.
- Bilet alma, kapıdan giriş, maç izleme ve tribünden çıkış korunur. Bilet ve kayıt anahtarları değiştirilmedi.
- HTML, JavaScript dosyaları ve `stadium-chant.mp3` aynı klasörde bulunmalı. Three.js internet gerektirir.
- Oyun açılışı, maç saatinde sesin çalması, duraklatma, maç sonu, ses efektlerini kapatma ve uzaklaşma tarayıcıda test edildi. 3D çizim testlerde kapatıldı; fiziksel telefonda test edilmedi.

## Modern evler ve stadyum arkası
- Mahalledeki dört evin her biri farklı modern cepheyle yenilendi. Oyuncunun market yanındaki evi de modernleştirildi; iç mekânı ve etkileşimleri korunur.
- Stadyumun arkasına dört farklı dekoratif bina ve yürünebilir bir bölge eklendi. Yeni binalara girilmez.
- Stadyumun doğusundaki otopark yolundan çevre yoluna bağlanan yeni yol, dört kollu kavşak, yaya geçitleri, kaldırımlar, trafik ışıkları ve devam yoluyla genişletildi. Yeni güzergahta bir araç dolaşır. Trafik ışıkları dekoratiftir, araçları yönetmez.
- Market önündeki basketbol sahası, büyük stadyum ve mevcut kayıt anahtarları korunur.
- ZIP'teki `mini-market-simulator.html`, `market-build.js`, `city-life.js`, `city-traffic.js` ve `city-expansion.js` dosyaları aynı klasörde olmalı. Oyunu HTML dosyasını açarak başlat. Three.js için internet gerekir.
- Oyun açılışı ve yeni trafik rotası, grafik çizimi kapatılarak tarayıcıda sınandı; yeni 3D sahne ayrıca önizlendi. Fiziksel telefonda ve tam grafik performansında test edilmedi.

## Market önü: mini basketbol sahası
- Marketin karşısındaki küçük futbol sahası kaldırıldı; yerine çizgili, iki potalı mini basketbol sahası eklendi. Büyük CITY STADIUM ve maç sistemi korunur.
- Saha asfalt yollara değmez; yolların geometrisi ve trafik sistemi değiştirilmedi. Şehir haritasına basketbol sahası işlendi.
- Basketbol topu etkileşimle saha içinde yuvarlanır. Pota atışı veya skor sistemi eklenmedi.
- Güncel sürüm için HTML, altı JavaScript dosyası ve tezahürat ses dosyasını aynı klasörde tut. Three.js için internet gerekir.
- Basketbol sahasının konumu ve top hareketi kontrol edildi.

## v3.2 (şehir çevre yolu, trafik ve çarpışma)
- Polis merkezinin dışından ve şehrin etrafından geçen iki şeritli çevre yolu, altı dolaşan araç ve harita çizimi eklendi. Ana cadde trafiği doğuda polis merkezine kadar uzanır.
- Trafik araçları, park edilmiş galeri araçları, kargo kamyonu ve bazı yerde duran eşyalar için çarpışma kutuları eklendi. Araçlar önlerindeki engeli bekler, yakınlarda uzun süre beklerlerse korna çalar. Ses ayarları korunur.
- Maç günü araçları ve polis devriyeleri trafik engellerini gözetir; maç günü yolcuları araç gerçekten park edince iner. Oyuncunun aracı kendi çarpışma kutusuna takılmaz.
- Çarpışma basitleştirilmiş dikdörtgen ve dairelerle yapılır, tüm dekoratif veya animasyonlu nesneler için ayrıntılı fizik garantisi yoktur. Şehrin dış yolunda kayıt konumları korunur.
- ZIP'teki `mini-market-simulator.html`, `market-build.js`, `city-life.js` ve `city-traffic.js` birlikte aynı klasörde olmalı. Three.js internet gerektirir. Masaüstü tarayıcı ve mobil ekran emülasyonunda test edildi, fiziksel telefonda test edilmedi.

## v3.1 (geçitte trafik yavaşlaması)
- Ana cadde trafiği stadyum yolu kavşağına yaklaşırken yavaşlar, kavşağı geçince tekrar hızlanır. Şehir merkezi geçidinde yayalara yol verme davranışı korunur.
- Stadyuma giden maç günü araçları yeni geçide yaklaşırken kademeli yavaşlar; geçtikten sonra hızlanır. Park, yolcu varışı ve oyun saatiyle yeniden yükleme buna göre hesaplanır. Bu geçitte araçlar otomatik yavaşlar, yayaya özel tam durma davranışı eklenmemiştir.
- Masaüstü tarayıcı ve mobil ekran emülasyonunda kontrol edildi; fiziksel telefonda test edilmedi.

## v3.0 (performans ve stadyum yolu)
- FPS düştüğünde grafik ayarını otomatik azaltan sistem kaldırıldı. Seçtiğin grafik seviyesi yalnızca ayarlardan değiştirilir.
- Gölge haritası her kare yerine saniyede yaklaşık 10 kez güncellenir. Çözünürlük ve gölge kalitesi seçilen seviyede kalır; hareketli gölgeler daha seyrek yenilenebilir. Bu optimizasyon kasmayı azaltabilir, her cihazda tamamen bitireceği garanti değildir.
- Stadyum önündeki yaya geçidi, markete yakın stadyum yolunun başlangıcına taşındı. Marketin hemen önündeki sonradan eklenmiş diğer geçit kaldırıldı; şehir merkezindeki ayrı geçit korunuyor.
- Stadyum yolunda gezinen maç öncesi taraftar grubu kaldırıldı. Diğer şehir yayaları taşıt şeritleri yerine yol kenarlarındaki güzergâhlara yönlendirildi. Otoparka araçla gelen taraftarlar korunur.
- Mevcut kayıt ve şehir sistemleri korunur. ZIP'teki HTML ve iki JavaScript dosyası aynı klasörde kalmalı; Three.js için internet gerekir. Tarayıcı testleri yapıldı, fiziksel telefonda test edilmedi.

## v2.9 (ikinci kat müşterileri, şehir yaşamı ve lokanta)
- İkinci kat açıldığında müşteriler alışveriş sırasında merdiveni kullanıp üst kata uğrar ve ardından ana kasaya döner. Üst katta stoklu bir ürün istiyorlarsa ilgili rafın yakınına gitmeye çalışırlar. Üst katta engellerin etrafında rota ararlar; yolu tamamen kapatma. İşçiler hâlâ üst kata çıkmaz, yeni raflar elle doldurulur.
- Şehirdeki kadın karakterlere çeşitli yetişkin yüzleri, saç stilleri, kıyafetler ve renkler eklendi; genel müşteri görünümüne de seçenekler eklendi. Konuşulabilir romantik karakterler yetişkindir.
- Sevgili menüsüne sarılma, iltifat ve yemeğe davet seçenekleri eklendi. Sarılma ve iltifat diyalog/ilişki etkileşimidir, ayrı yakın temas animasyonu yoktur.
- Şehir Lokantası ana yolun karşısında, marketin sol çaprazında bulunur ve şehir haritasında işaretlidir. Masaya veya girişe bakıp etkileşime bas. Tek kişilik yemek 45 $, baş başa yemek 90 $; bakiye yetersizse satın alınamaz.
- Baş başa yemek için önce sevgilini konuşma menüsünden davet et, birlikte lokantaya git ve menüden yemeği seç. Sevgilin masada kısa süre oturur; ilişki +10 artar. Ardından yeniden seni takip eder. Oyuncu yemek sırasında serbesttir, ayrı yeme animasyonu yoktur.
- Araç yolunun karşı kenarında devamlı yaya kaldırımı bulunur. Geçitlerin güncel konumu için v3.0 notlarına bak.
- Para, ilişki, eşyalar ve üst kat mevcut kayıt anahtarlarını kullanır. Eski kayıtları saklamak için güncellemeden önce yedek al; tarayıcı veya dosya konumu değişirse kayıtlar otomatik taşınmayabilir.
- ZIP içindeki `mini-market-simulator.html`, `market-build.js` ve `city-life.js` aynı klasörde kalmalı. Three.js için internet gerekir. Testler masaüstü tarayıcı ve mobil ekran/dokunmatik emülasyonunda yapıldı; fiziksel telefonda test edilmedi.

## v2.8 (merdiven animasyonu)
- Merdivene bakıp etkileşime basınca oyuncu basamakları tek tek çıkar veya iner. Kamera yüksekliği ve konumu kademeli değişir, adım sesleri çalar.
- Hareket otomatik gerçekleşir; yaklaşık 6 saniyelik geçiş bitene kadar yön kontrolleri kilitlenir. Merdiven serbest yürünebilen fiziksel bir rampa değildir.
- Mevcut kayıt, genişletme ve eşya sistemi korunur. Tarayıcıda hem çıkış hem iniş test edildi; fiziksel mobil cihazlarda test edilmedi.

## v2.7 (market inşaatı ve eşya yerleştirme)
- Depodaki bilgisayarda **Marketi Büyüt** sekmesinden mevcut arka salonu sırasıyla 600 $, 1.200 $ ve 2.200 $ karşılığında genişlet. Zemin, duvarlar ve yürüme alanı fiziksel olarak büyür.
- **Yapı ve Eşya** sekmesinden ikinci katı 3.500 $ karşılığında inşa et. Önce arka salonun en az iki kez genişletilmesi gerekir. Merdivene bakıp etkileşim düğmesine basarak kat değiştir.
- Eşya fiyatları: raf 180 $, buzdolabı 320 $, kasa 250 $, masa 120 $, bitki 65 $. Bakiye yetmezse satın alma yapılamaz.
- **Yerleştirme modunu aç**: envanterden eşya seç ve plana dokun; konmuş eşyayı sürükle. Döndür düğmesi 90° çevirir. Eşyayı seçip kat düğmesini değiştirerek diğer kata taşıyabilirsin. Kaydet yerleşimi uygular; İptal yalnızca o oturumdaki yerleşim değişikliklerini geri alır, satın alma iadesi yapmaz.
- Raf ve buzdolabı etkileşimiyle mevcut depodan ürün yerleştirilebilir; ürünler mevcut stok ve satış sistemine bağlanır. Yeni raflar elle doldurulur. Yeni kasa mevcut kasa ekranını açar; ayrı müşteri kuyruğu veya ayrı kasa bakiyesi oluşturmaz. Masa ve bitki dekoratiftir.
- Yeni eşyalar, konumları, stokları ve ikinci kat mevcut `mms_save_v1` kaydına eklenir. Önceki kayıtlar okunur. İkinci katta kaydedilirse açılışta zemin kata dönülür. Kayıtlar tarayıcıya ve dosyanın açıldığı konuma bağlı olabilir; değiştirmeden önce mevcut kaydı yedekle ve aynı konumu kullan.
- ZIP'i açıp `mini-market-simulator.html` dosyasını tarayıcıda aç. `market-build.js` aynı klasörde kalmalıdır. Önceki sürüm gibi Three.js için internet bağlantısı gerekir. Mobil yerleştirme dokunma ve sürüklemeyi destekler; fiziksel cihazlarda test edilmemiştir.

## v2.6 (grafik ve yüzey düzeltmeleri)
- Gece yerde aşırı parlak beyaz lekeler oluşturan sahte ışık düzlemleri kaldırıldı; lambalar ve noktasal ışıklar korunup daha dengeli hale getirildi.
- Stadyum kenarları, park yolu kesişimleri ve bazı bina köşelerindeki üst üste binen yüzeyler ayrıldı. Kamera derinlik hassasiyeti iyileştirildi.
- Haritanın doğusu ve stadyum çevresinde eksik kalan zemin genişletildi. Hava durumunda gökyüzü renginin her karede üst üste solması düzeltildi; kar tanelerinin kare beyaz görünümü yumuşatıldı.
- Doku ve materyal yüklemesi, şehir bölgelerinde gündüz/gece ve maç sahnesinde kontrol edildi. Oyunun bilinçli olarak düz renkli ve beyaz malzemeleri korunmuştur.
- Statik geometri birleştirme, uyumsuz materyal ve geometri türlerini atlayacak şekilde güvenli hale getirildi. Düşük grafik ayarının gölgesiz, düşük çözünürlüklü modu korunmuştur.
- Oyunu açmak için önceden olduğu gibi Three.js internet bağlantısı gerektirir; fiziksel mobil cihazlarda ayrıca test edilmemiştir.

## v2.5 (hava durumu ve karakol)
- Azerbaycan bayrağı direğe bağlı, rüzgârda dalgalanan bir kumaş olarak yenilendi.
- Hava oyun gününe ve saatine göre değişir: döngünün ilk gününde 10:00-13:00 yağmur, ikinci gününde 14:00-17:00 kar, üçüncü gününde açık hava görülür. Sonra döngü tekrarlanır.
- Yağış iç mekânlarda görünmez; düşük grafik ayarında parçacık sayısı azaltılır. Kar birikimi veya kaygan zemin simülasyonu yoktur.
- Karakolun resepsiyonuna ve çalışma alanlarına dört üniformalı görevli eklendi.
- İki polis aracı sırayla karakol ile cadde arasında gidip gelir; oyuncu yakınındaysa beklerler. Araçlar ve çalışanlar görsel simülasyondur, sürme ve görev sistemi eklenmemiştir.
- Oyun dosyası tek HTML olarak kalır; mevcut kayıt anahtarları korunur.

## v2.4 (bayrak güncellemesi)
- Polis karakolundaki Amerikan bayrağı Azerbaycan bayrağıyla değiştirildi.

## v2.3 (polis karakolu)
- Şehrin doğusuna, benzin istasyonunun ilerisinde iki katlı ve içine girilebilen CITY POLICE karakolu eklendi; cadde ve şehir haritası uzatıldı.
- Resepsiyon ve bekleme alanı, çalışma masaları, toplantı odası, nezarethane ve araç garajı vardır. Polis araçları, güvenlik çitleri, otopark ve Amerikan bayrağı eklendi.
- Kat değiştirmek için karakol girişindeki asansöre bakıp etkileşim düğmesine basın. Zemin ve üst kat engelleri ayrı çalışır.
- Garajdaki ve otoparktaki polis araçları dekor amaçlıdır. Polislik, nezarete alma veya bu araçları sürme sistemi eklenmemiştir.
- Mobil performansı için basit paylaşımlı geometri ve malzemeler kullanılır. Önceki kayıt anahtarları korunur; üst katta kaydedilirse yeniden yüklerken karakol girişine dönülür.

## v2.2 (doğal bitki örtüsü)
- Eski basit ağaçlar, dal ve kabuk detayları ile yaprak dokuları içeren yeni 3D bitkilerle değiştirildi.
- Meşe, huş, çam, kiraz, palmiye ve çalı çeşitleri şehrin uygun bölgelerine yerleştirildi. Futbol sahası, yol ve park yürüyüş yolları açık bırakıldı.
- Yapraklar hafif rüzgârla hareket eder. Bitkiler paylaşılan geometri, instancing, küçük dokular ve gölgesiz çizimle mobil yükü azaltacak şekilde hazırlandı.
- Mevcut kayıt anahtarları, maç günü ve benzin istasyonu korundu.

## v2.1 (harita ve benzin istasyonu)
- Stadyum yolu, kavşak ve doğu cadde zeminlerindeki aynı düzlem çakışmaları düzeltildi; şehir merkezindeki kesişen yaya yolları ayrıştırıldı.
- Büyük haritanın sınırları doğu bölgesini gösterecek şekilde genişletildi. Bölgeler, yollar ve etiketlerin sıralaması düzenlendi; üst üste binen etiketler gizleniyor.
- Doğudaki eski dekor istasyon, tabelası, pompaları ve gece aydınlatması olan ZUNEX PETROL istasyonuna dönüştürüldü; haritada gösteriliyor.
- Benzin istasyonu görsel dekordur: oyunda yakıt tüketimi ve yakıt satın alma sistemi yoktur.
- v2.0 maç günü sistemi ve mevcut kayıt anahtarları korundu.

## v2.0 (maç günü ve stadyum yolu)
- Her oyun günü, 20:00 maçından önce 10 kişilik taraftar grubu stadyuma yürür; kapılar açılana kadar girişte bekler.
- Üç taraftar araçlarıyla gelir, stadyumun yanındaki işaretli otoparka park eder ve girişe yürür. Park yerleri oyuncu için çarpışmalıdır.
- Ana caddeden stadyuma ve otoparka kesintisiz araç yolu açıldı. Yolun üstündeki atlıkarınca, banklar ve engel oluşturan çevre öğeleri taşındı.
- Market önündeki yaya geçidi stadyum girişine taşındı; yeni yol ve otopark şehir haritasına eklendi.
- Olaylar oyun saatine bağlıdır ve yeni günde tekrar eder. Mevcut kayıt anahtarları değiştirilmedi.

Çalıştırma: ZIP'i açın ve `mini-market-simulator.html` dosyasını tarayıcıda açın. Önceki sürümde olduğu gibi Three.js internetten yüklendiği için internet bağlantısı gerekir.

## v1.9 (araç güncellemesi — kayıtlar uyumlu)
- Tüm arabalar yeni 3D modellerle: kesitlerden örülmüş gövde, çamurluk kavisleri, omuz çizgisi, daralan cam kabin, köşeye sarılan farlar, sis farı, sinyal, stop, ızgara, plaka, ayna, kapı çizgisi/kolu, egzoz, fren kaliperi
- Türler: Hatchback, Sedan, SUV (tavan rayı), Kamyonet (branda), Süper Spor (difüzör, yan hava girişi), Hiper Spor (kanat, yüzgeç), TAKSİ (tepe lambası, damalı şerit), POLİS (yanıp sönen tepe lambası, POLİS şeridi, ön tampon koruma)
- Tekerlekler: yuvarlatılmış lastik + 5 kollu / çok kollu / çelik jant; dönüş artık gerçek kat edilen yoldan hesaplanır, ön tekerlekler direksiyonla döner
- Süspansiyon: gazda arka çöker, frende burun dalar, virajda gövde yatar; frenlerken ve dururken stop lambaları yanar
- Sürüş: türe göre ivme/azami hız/fren, motor freni, hız arttıkça hassaslaşan direksiyon, yanal tutuş sınırı, çarpışma alt adımlı (duvardan geçme yok); yumuşak takip kamerası (hızla FOV açılır)
- Trafiğe taksi, polis ve lacivert sedan eklendi; otoparktaki arabalar da yeni modellerle
- ZUNEX CARS: Sarı Taksi (1.500 $) ve Polis Aracı (5.000 $) satışta; galeri 9 araca göre yeniden dizildi
- Optimizasyon: parçalar malzeme başına birleştirildi (araç başına ~18 çizim, eskiden ~60), geometriler tür başına paylaşılır, park halindeki araçlarda tekerlekler gövdeye gömülü, 42 m ötesinde lastik/jant basit sürüme geçer (LOD), gölgeyi yalnız ana gövde düşürür
- Kayıt: mms_cars_v1 aynı; eski kayıtlardaki arabalar korunur


## v1.8 (premium ana menü — oyun sistemi ve kayıtlar değiştirilmedi)
- Yeni ana menü: PLAY, CONTINUE, GARAGE, SETTINGS, EXIT (Unbounded + Manrope yazı tipleri, altın PLAY butonu, kademeli giriş animasyonu)
- Arka planda canlı 3D şehir: menüdeyken trafik akar, yayalar yürür
- Sinematik kamera turu: 7 plan (Ana Cadde, Süper Market, City Stadium, Şehir Merkezi, ZUNEX CARS, Şehir Parkı, Şehir Üstü), perde geçişleri, letterbox, vinyet, film greni, "CANLI · CAM" etiketi
- GARAGE ekranı: ZUNEX CARS araçlarını sinematik kamerayla gez (sahip olunanlar / satılıklar, fiyat). Sadece görüntüler; satın alma oyunda galeride
- CONTINUE butonunda kayıt özeti (Gün · Para); kayıtlar sadece okunur
- Mobil uyum: kısa yatay ekranlar, çentik (safe-area) ve dikey ekranda da menü; oyun yine yatay açılır
- Klavye: ↑/↓ menü, ←/→ garajda araç, Esc geri. Garajda kaydırarak araç değişir
- Ayarlar / Duraklat / Onay pencereleri aynı premium görünüme geçti
- Kayıt anahtarları aynı: mms_save_v1, mms_settings_v1, mms_cars_v1 ...


Tek dosya: `mini-market-simulator.html` — tarayıcıda açarak oynanır (Three.js'i internetten yükler, bu yüzden internet gerekir).

## v1.2
- CITY MALL artık 2 katlı: asansörle 1. kat ↔ 2. kat; 2. katta yemek alanı (food court) ve 6 yeni mağaza
- 14 mağazadan alışveriş: tezgâha bakınca katalog açılır, ürünler satın alınır; her ürün Süper Market günlük gelirini artırır

## v1.1
- Marketin önündeki arabalar daha gerçekçi (cam kabin, eğimli camlar, jantlı tekerlek, farlar, ayna, plaka, spor araba kanadı)
- Süper Market içi yenilendi: karolu zemin, tavan lambaları, iki yüzlü ürünlü raflar, meyve tezgâhları, cam kapılı soğutucu duvarı, numaralı kırmızı kasalar, alışveriş arabaları
- CITY MALL parkın arkasına taşındı ve içi gezilebilir: mermer zemin, havuz, banklar, 8 mağaza
- 5 yeni kule/gökdelen (beyaz, kademeli bej, mavi cam)

## v1.0 (yeni ticaret bölgesi — mevcut hiçbir şey değiştirilmedi)
- ZUNEX CARS'ın güneyinde yeni bölge: otopark (renkli arabalar), ağaçlar, lambalar
- SÜPER MARKET (satılık, 12.000 $): kapıdaki SATILIK tabelasına bakıp satın al → kapı açılır, içeri girilir (raflar, soğutucular, kasa)
- Satın alınca her yeni günde kasada 450 $ gelir birikir; kasaya bakıp "Geliri al" ile paranı alırsın
- CITY MALL, GYM ve KAFE binaları (dekor), mini haritada yeni bölge
- Kayıt ayrı anahtarda tutulur (mms_citymarket_v1); eski kayıtlar etkilenmez

## v0.9 (insan tasarımları)
- NPC'ler referans görsele göre: kapüşonlu hoodie, crop top + kot, etek + çorap, eşofman şeritli, forma, ceketli, çanta, kulaklık; yaşlı ve çocuk modelleri

## v0.8 (araba güncellemesi)
- Arabayı sürerken ekranda GAZ ve FREN düğmeleri (klavyede W ve Boşluk), km/h göstergesi
- Araba satın alınca ZUNEX CARS galerisinin önünde, yola bakarak doğarsın

## v0.7 (stadyum güncellemesi — stadyum güncellemesi)
- Stadyuma artık serbestçe girilemez: giriş kapısında bariyer var, sahaya/tribüne yürünmez
- Kapının solunda BİLET GİŞESİ (satıcılı kulübe): bilet 15 $, her gün için bir bilet; rastgele numaralı koltuk (tribün, blok, sıra, koltuk)
- Kapıdaki görevliye bileti göster: kapılar 19:40'ta açılır, maç bitince (22:00) otomatik dışarı çıkarılırsın
- Koltuğuna oturup maçı izlersin (sağdaki "Tribünden çık" düğmesi, üstte koltuk bilgisi)
- Tribünlerde blok tabelaları: BATI/DOĞU TRİBÜNÜ · BLOK A-B-C-D, kuzey/güney tribün yazıları
- Maçta hakem + 2 yan hakem, sarı/kırmızı kart, başlama/final düdüğü; oyuncular birbirinin içine girmez, sahadan taşmaz
- Eski kayıtta stadyum içinde kalan oyuncu otomatik kapının önüne alınır

## v0.6'dan kalanlar
- Yeni low-poly arabalar (Crazy Cars tarzı) ve düzeltilmiş tekerlekler
- Yenilenmiş stadyum (krem duvarlar, tribünler, çatılar, projektörler, gerçek skor tabelası)
- ZUNEX CARS araba galerisi (sağ köşe): araba satın al ve sür
- Şehir Merkezi: gökdelenler, yaya geçidi, tabela, yaya yolu
- Köşede mini harita; dokununca detaylı şehir haritası
- Şehir Parkı: oturan insanlar, yürüyen yayalar (evlere girer, parka gider)
- İnsanlarla konuşma, arkadaşlık, sevgili sistemi, gezinti
- Gece ışıkları (lambalar, pencereler, ışık lekeleri, projektörler)
- Her gün 20:00-22:00 stadyum maçı: skor stadyumun kendi tabelasında yazar
