/* Mobil grafik profili: mevcut oyuna eklenir; orijinal dosyaları değiştirmez. */
(function () {
  'use strict';
  const g=window.__mms, T=window.THREE;
  if(!g||!T||window.__mobilGrafik)return;
  const mobile=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) ||
    (navigator.maxTouchPoints>0 && matchMedia('(pointer: coarse)').matches) ||
    new URLSearchParams(location.search).has('mobil-onizleme');
  const reduceMemory=Number.isFinite(navigator.deviceMemory)&&navigator.deviceMemory<=2;
  const originalRatio=g.applyQualityRatio.bind(g), originalQuality=g.world.setQuality.bind(g.world);
  const originalSample=g.samplePerformance.bind(g);
  let elapsed=0,frames=0,good=0,fps=60;
  // Filmic colors and light atmospheric depth use the existing scene, not extra meshes or textures.
  g.renderer.toneMapping=T.ACESFilmicToneMapping;
  g.renderer.toneMappingExposure=1.12;
  const fog=new T.FogExp2(g.scene.background.clone(),0.0016);
  g.scene.fog=fog;
  // Keskinlik: eskiden telefon 1.05x ile çiziliyordu (3x ekranda ~3 kat büyütülüp bulanıyordu).
  // Yeni tavanlar daha yüksek; FPS düşerse _renderScale otomatik azaltır, toparlanınca geri çıkarır.
  g.applyQualityRatio=function(){
    if(!mobile)return originalRatio();
    const q=this.settings.quality, dpr=window.devicePixelRatio||1;
    const base=q==='low'?1:q==='high'?2:1.6;
    const budget=q==='low'?900000:q==='high'?2400000:1600000;
    const area=Math.max(1,innerWidth*innerHeight);
    const cap=Math.min(dpr,base,Math.sqrt(budget/area));
    this.renderer.setPixelRatio(Math.max(.5,cap*this._renderScale));
  };
  g.world.setQuality=function(q,renderer){
    originalQuality(q,renderer);
    if(!mobile||q==='low')return;
    const size=q==='high'&&!reduceMemory?1024:512;
    if(this.sun.shadow.mapSize.x!==size){
      this.sun.shadow.mapSize.set(size,size);
      if(this.sun.shadow.map){this.sun.shadow.map.dispose();this.sun.shadow.map=null;}
      renderer.shadowMap.needsUpdate=true;
    }
  };
  // Short measurements respond to sustained load, but never change a player's quality selection.
  g.samplePerformance=function(dt){
    if(!mobile)return originalSample(dt);
    if(this.state!=='playing'||document.hidden||dt<=0||dt>2)return;
    elapsed+=dt;frames++;
    if(elapsed<2.5)return;
    fps=frames/elapsed; this._fps=fps;elapsed=0;frames=0;
    let next=this._renderScale;
    if(fps<26){next=Math.max(.58,next-.12);good=0;}
    else if(fps<33){next=Math.max(.58,next-.06);good=0;}
    else if(fps>52){if(++good>=4){next=Math.min(1,next+.04);good=0;}}
    else good=0;
    if(Math.abs(next-this._renderScale)>.005){
      this._renderScale=next;this.applyQualityRatio();
      this.renderer.setSize(innerWidth,innerHeight,false);
    }
  };
  // Keep fog matched to the day/night sky, with no per-frame allocations.
  const update=g.world.update.bind(g.world);let fogTimer=0;
  g.world.update=function(dt,...args){
    const result=update(dt,...args); fogTimer+=Math.max(0,dt);
    if(fogTimer>.5){fogTimer=0;if(g.scene.background?.isColor)fog.color.copy(g.scene.background);}
    return result;
  };
  if(mobile){
    // PCFSoft mobil GPU'da pahalı; PCF aynı görünümde belirgin şekilde daha hızlı.
    g.renderer.shadowMap.type=T.PCFShadowMap;
    g.scene.traverse(o=>{if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m&&typeof m==='object')m.needsUpdate=true;});});
    // Zayıf telefonda ilk saniyelerde takılmamak için biraz düşük başlar, cihaz yeterliyse kendiliğinden yükselir.
    g._renderScale=Math.min(g._renderScale,reduceMemory?.7:.85);
  }
  g.world.setQuality(g.settings.quality,g.renderer);
  g.applyQualityRatio(); g.renderer.setSize(innerWidth,innerHeight,false);
  window.__mobilGrafik={mobile,inspect:()=>({mobile,quality:g.settings.quality,fps,scale:g._renderScale,pixelRatio:g.renderer.getPixelRatio(),shadow:g.world.sun.shadow.mapSize.x,fog:fog.density})};
})();
