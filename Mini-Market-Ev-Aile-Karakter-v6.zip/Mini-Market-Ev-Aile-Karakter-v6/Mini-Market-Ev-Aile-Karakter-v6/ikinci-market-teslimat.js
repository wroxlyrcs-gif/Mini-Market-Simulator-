/* Süper Market deposu, teslimat aracı ve otopark müşterileri. */
(function(){
  'use strict';
  const g=window.__mms,T=window.THREE,w=g?.world, traffic=window.__cityTraffic;
  if(!g||!T||!w||!traffic||!window.MMS_VEH||window.__ikinciTeslimat)return;
  const KEY='mms_citymarket_delivery_v1';
  let pending=null;try{pending=JSON.parse(localStorage.getItem(KEY)||'null');}catch(_){}
  if(!pending||!['water','bread','milk','snack'].includes(pending.id)||pending.qty!==10||typeof pending.token!=='string')pending=null;
  let vehicle=null,courier=null,job=null,blockTime=0,readyDelay=0;
  const pool={};
  function save(){try{localStorage.setItem(KEY,JSON.stringify(pending));}catch(_){}}
  function notice(text){if(g.ui&&g.state==='playing')g.ui.toast(text);}
  function owned(){try{return JSON.parse(localStorage.getItem('mms_citymarket_v1')||'{}').owned===true;}catch(_){return false;}}
  // Small open depot in the east corner of the parking lot, clear of the road and parking aisle.
  const depot=new T.Group();depot.name='SÜPER MARKET DEPOSU';w.scene.add(depot);
  function b(sx,sy,sz,x,y,z,c){const m=w.b(sx,sy,sz,x,y,z,c,{parent:depot,cast:false,receive:false});m.userData.static=true;return m;}
  b(4.4,.10,3.4,69.4,0,57.3,0xaebbb2);
  b(4.5,.18,3.6,69.4,3.0,57.3,0x48634f);
  b(4.4,2.8,.15,69.4,.1,58.95,0xd8d8c5);
  for(const x of [67.3,71.5])b(.14,3,.14,x,.1,55.65,0x48634f);
  for(const [x,z] of [[68.3,57.7],[69.1,57.7],[70,57.7],[70.8,57.7]]){
    b(.65,.55,.6,x,.1,z,0xb48955);b(.65,.025,.03,x,.38,z-.31,0xf4d68b);
  }
  const label=w.canvasTex(256,96,(c,W,H)=>{c.fillStyle='#275b44';c.fillRect(0,0,W,H);c.fillStyle='#fff';c.textAlign='center';c.textBaseline='middle';c.font='bold 52px sans-serif';c.fillText('DEPO',W/2,H/2);});
  const sign=new T.Mesh(w.geo('plane'),new T.MeshBasicMaterial({map:label,side:T.DoubleSide}));sign.scale.set(2.2,.7,1);sign.position.set(69.4,2.65,55.55);depot.add(sign);
  w.mergeStatic(depot);
  for(const x of [67.3,71.5])w.colliders.push({minX:x-.09,maxX:x+.09,minZ:55.56,maxZ:55.74,secondDepot:true});
  function makeCar(kind){
    const group=new T.Group();group.name=kind==='delivery'?'SÜPER MARKET TESLİMAT':'MARKET MÜŞTERİ ARACI';w.root.add(group);
    const model=MMS_VEH.build(w,group,kind==='delivery'?'pickup':'hatch',kind==='delivery'?0x37855e:0xe9ae3c,0x263339,0xd5dadf);
    if(kind==='delivery'){
      const box=w.b(1.35,1.1,1.45,-1.25,1.15,0,0xece8db,{parent:group,cast:false});
      box.userData.secondDelivery=true;
      const tex=w.canvasTex(256,96,(c,W,H)=>{c.fillStyle='#277b50';c.fillRect(0,0,W,H);c.fillStyle='#fff';c.font='bold 38px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('TESLİMAT',W/2,H/2);});
      const s=new T.Mesh(w.geo('plane'),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));s.scale.set(1.2,.38,1);s.position.set(-1.25,1.7,.735);group.add(s);
    }
    group.visible=false;
    return {group,wheels:model.wheels,_nominal:3.0,_hornWait:0,_trafficCol:null,kind};
  }
  function setCar(kind){
    if(vehicle){vehicle.group.visible=false;if(vehicle._trafficCol){let i=w.colliders.indexOf(vehicle._trafficCol);if(i>=0)w.colliders.splice(i,1);}}
    vehicle=pool[kind]||(pool[kind]=makeCar(kind));vehicle.group.position.set(42,0,55.5);vehicle.group.rotation.y=0;vehicle.group.visible=true;
    vehicle._trafficCol=Object.assign(traffic.bounds(42,55.5,0,2.05,.86),{vehicleOwner:vehicle,trafficBody:true});w.colliders.push(vehicle._trafficCol);
  }
  function moveCar(target,dt){
    const p=vehicle.group.position,dx=target[0]-p.x,dz=target[1]-p.z,dist=Math.hypot(dx,dz);
    if(dist<.04){p.x=target[0];p.z=target[1];return true;}
    const step=Math.min(dist,2.5*dt),x=p.x+dx/dist*step,z=p.z+dz/dist*step, yaw=Math.atan2(-dz,dx);
    if(!traffic.canMoveVehicle(vehicle,x,z,yaw,dt,2.05,.86)){blockTime+=dt;return false;}
    blockTime=0;p.x=x;p.z=z;vehicle.group.rotation.y=yaw;traffic.sync(vehicle);
    for(const wheel of vehicle.wheels)wheel.rotation.z-=step/.35;
    return dist<=step+.001;
  }
  function disposeCar(){
    if(vehicle){let i=w.colliders.indexOf(vehicle._trafficCol);if(i>=0)w.colliders.splice(i,1);vehicle.group.visible=false;vehicle=null;}
    if(courier){courier.group.visible=false;courier.setCarry(false);}
    job=null;blockTime=0;if(window.__ikinciMarket?.refresh)window.__ikinciMarket.refresh();
  }
  function beginDelivery(){setCar('delivery');job={kind:'delivery',phase:'arrive'};}
  function startCustomer(){if(job||pending||!owned()||g.state!=='playing')return false;
    setCar('customer');job={kind:'customer',phase:'arrive'};return true;}
  function order(id,qty){
    if(job||pending||!owned()||qty!==10||!['water','bread','milk','snack'].includes(id))return false;
    pending={id,qty,token:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9)};save();readyDelay=0;
    notice('Sipariş alındı. Teslimat aracı yola çıkıyor.');return true;
  }
  function customerDone(){if(job?.kind==='customer'&&job.phase==='shopping')job.phase='exitParking';}
  function makeCourier(){if(courier)return;courier=window.__mmsPeople.buildHuman({shirt:0x2d7959,pants:0x283941,vest:0x41996a,skin:0xe0ac69,cap:0x244d3a,lod:true});w.root.add(courier.group);courier.group.visible=false;}
  function moveCourier(x,z,dt){const p=courier.group.position,dx=x-p.x,dz=z-p.z,d=Math.hypot(dx,dz),v=Math.min(d,1.8*dt);if(d>0){p.x+=dx/d*v;p.z+=dz/d*v;courier.group.rotation.y=Math.atan2(dx,dz);}courier.walk(dt,d>.05?1:0);return d<=v+.02;}
  function step(dt){
    if(g.state!=='playing'||!g.data||!owned())return;
    if(!job&&pending){readyDelay+=dt;if(readyDelay>.5){readyDelay=0;beginDelivery();}}
    if(!job)return;
    if(job.kind==='delivery'){
      if(job.phase==='arrive'&&moveCar([61,55.5],dt)){job.phase='unload';makeCourier();courier.group.position.set(63.1,0,55.3);courier.group.visible=true;courier.setCarry(true);}
      else if(job.phase==='unload'&&moveCourier(67.6,55.1,dt)){
        if(window.__ikinciMarket?.receive && window.__ikinciMarket.receive(pending.id,pending.qty,pending.token)){
          pending=null;save();courier.setCarry(false);job.phase='back';notice('Sipariş ikinci market deposuna teslim edildi.');
        }
      }else if(job.phase==='back'&&moveCourier(63.1,55.3,dt)){courier.group.visible=false;job.phase='depart';}
      else if(job.phase==='depart'&&moveCar([42,55.5],dt)){disposeCar();}
    }else{
      if(job.phase==='arrive'&&moveCar([61,55.5],dt))job.phase='park';
      else if(job.phase==='park'&&moveCar([61,60],dt)){
        if(window.__ikinciMarket?.arriveByCar?.()){job.phase='shopping';}else job.phase='exitParking';
      }else if(job.phase==='exitParking'&&moveCar([61,55.5],dt))job.phase='depart';
      else if(job.phase==='depart'&&moveCar([42,55.5],dt))disposeCar();
    }
  }
  const old=w.update.bind(w);w.update=function(dt,...args){const result=old(dt,...args);step(Math.min(.1,Math.max(0,dt)));return result;};
  window.__ikinciTeslimat={order,startCustomer,customerDone,canOrder:()=>!job&&!pending,
    inspect:()=>({pending:pending?{...pending}:null,job:job?{...job}:null,blockedSeconds:+blockTime.toFixed(1),vehicle:vehicle?{x:vehicle.group.position.x,z:vehicle.group.position.z}:null})};
})();
