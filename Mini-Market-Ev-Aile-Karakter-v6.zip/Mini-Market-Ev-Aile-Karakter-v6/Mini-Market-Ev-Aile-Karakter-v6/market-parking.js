/* v3.4: market-side parking with scheduled arrivals, safe gap checks and mobile-light geometry. */
(function () {
  'use strict';
  const g = window.__mms, T = window.THREE;
  const traffic = window.__cityTraffic;
  if (!g || !T || !traffic || !window.MMS_VEH || window.__marketParkingBuilt) return;
  window.__marketParkingBuilt = true;
  const w = g.world, regions = __req('player').REGIONS;
  const lot = new T.Group();
  w.scene.add(lot);
  const pave = (sx, sy, sz, x, y, z, color) => {
    const m = w.b(sx, sy, sz, x, y, z, color, { parent: lot, cast: false, receive: false });
    m.userData.static = true;
    return m;
  };
  const asphalt = 0x454a50, line = 0xf3f1e9, curb = 0xd3d0c6;
  // Four stalls, a broad maneuver aisle, and a driveway connecting to the curb-side eastbound lane.
  // Katman yükseklikleri (Z-FIGHTING DÜZELTMESİ): yol .04, kaldırım .07 (dünya tarafından).
  // Eskiden otopark asfaltının üstü de .07 idi; kaldırımla aynı düzlemde olduğu için beyaz/koyu yüzeyler
  // her karede yer değiştirip titreşiyordu. Burada her katman bir öncekinden en az 3 cm yüksek tutulur.
  const LOT_TOP = .11, LINE_TOP = .138;
  pave(19.2, LOT_TOP + .005, 10.8, -22.6, -.005, 1.0, asphalt);   // x -32.2..-13, z -4.4..6.4
  // Yolluk, otopark asfaltıyla aynı yükseklikte ve ona bitişik (z 6.4..8.6); üst üste binmez, kaldırımın 4 cm üstündedir.
  pave(6.4, LOT_TOP - .015, 2.2, -13.2, .015, 7.5, 0x4a4f57);
  pave(.65, .14, 10.2, -32.5, -.005, 1.0, curb);
  pave(.18, .14, 10.2, -12.95, -.005, 1.0, curb);
  // White parking dividers and front stop markings (asfaltın 2.8 cm üstünde).
  for (const x of [-31, -27, -23, -19, -15.2]) pave(.09, .018, 5.7, x, LINE_TOP - .018, .25, line);
  pave(15.8, .018, .09, -23.1, LINE_TOP - .018, -2.65, line);
  // Low wheel stops sit at the nose of each marked bay.
  const stallXs = [-29, -25, -21, -17];
  for (const x of stallXs) pave(.42, .16, .14, x, LOT_TOP, -2.35, 0x9ca19f);

  const signTex = w.canvasTex(384, 128, (ctx, cw, ch) => {
    ctx.fillStyle = '#1f4e8c'; ctx.fillRect(0, 0, cw, ch);
    ctx.strokeStyle = '#f2cf65'; ctx.lineWidth = 8; ctx.strokeRect(5, 5, cw - 10, ch - 10);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = '900 56px Arial'; ctx.fillText('P', 67, 64);
    ctx.font = '800 31px Arial'; ctx.fillText('MARKET', 235, 49); ctx.fillText('PARKING', 235, 86);
  });
  const post = new T.Mesh(w.geo('box'), w.mat(0x39434a));
  post.scale.set(.12, 2.65, .12); post.position.set(-9.45, 1.32, 5.8); lot.add(post);
  const sign = new T.Mesh(w.geo('plane'), new T.MeshBasicMaterial({ map: signTex, side: T.DoubleSide }));
  sign.scale.set(2.6, .88, 1); sign.position.set(-9.45, 2.28, 5.85); lot.add(sign);
  w.mergeStatic(lot);
  regions.push(
    { minX: -32.4, maxX: -7.7, minZ: -4.8, maxZ: 7.25 },
    { minX: -16.6, maxX: -9.8, minZ: 6.2, maxZ: 10.7 }
  );
  window.__marketParkingMap = [
    { x0: -32.2, x1: -13.0, z0: -4.4, z1: 6.4, c: '#858b88', l: 'Market Otoparkı', e: '🅿️' },
    { x0: -16.4, x1: -10.0, z0: 6.3, z1: 10.5, c: '#4b4f55' }
  ];

  const visitors = [];
  // The driveway is one lane. Reserve it for one incoming or outgoing car;
  // the previous unrestricted route let two cars face each other forever.
  let drivewayHolder = null;
  const models = [
    { kind: 'sedan', color: 0x2b68a4, spawn: 8, slot: -17, park: 22, retry: 48 },
    { kind: 'hatch', color: 0xc44436, spawn: 26, slot: -21, park: 25, retry: 54 },
    { kind: 'taxi', color: 0xe8bb36, spawn: 46, slot: -25, park: 20, retry: 62 }
  ];
  for (const [i, q] of models.entries()) {
    const group = new T.Group(); group.visible = false; w.root.add(group);
    const built = MMS_VEH.build(w, group, q.kind, q.color, 0x202428, 0xd7dce0);
    const car = { group, wheels: built.wheels || [], _nominal: 4.8, nominal: 4.8, _hornWait: 0,
      collider: { minX: 0, maxX: 0, minZ: 0, maxZ: 0, vehicleOwner: null, trafficBody: true } };
    car.collider.vehicleOwner = car;
    car._trafficCol = car.collider;
    car.state = 'waiting'; car.elapsed = 0; car.nextSpawn = q.spawn; car.slotX = q.slot;
    car.parkSeconds = q.park; car.retrySeconds = q.retry; car.id = i;
    car.entryRoute = [[-80, 10.05], [-12.2, 10.05], [-12.2, 7.0], [-14.2, 5.15], [q.slot, 5.15], [q.slot, .55]];
    car.exitRoute = [[q.slot, .55], [q.slot, 5.15], [-14.2, 5.15], [-12.2, 7.0], [-12.2, 10.05], [-11.0, 10.05], [12.0, 10.05]];
    visitors.push(car); traffic.parking.push(car);
  }

  function setCollider(car, x, z, yaw) {
    Object.assign(car.collider, traffic.bounds(x, z, yaw), { vehicleOwner: car, trafficBody: true, parkingVisitor: true });
  }
  function spawn(car) {
    if (drivewayHolder && drivewayHolder !== car) return false;
    if (visitors.some(v => v !== car && v.state === 'parked' && v.elapsed >= v.parkSeconds)) return false;
    if (!traffic.canSpawnAt(-80, 10.05, 0, car)) return false;
    drivewayHolder = car;
    car.group.position.set(-80, .11, 10.05); car.group.rotation.y = 0;
    setCollider(car, -80, 10.05, 0);
    if (!w.colliders.includes(car.collider)) w.colliders.push(car.collider);
    car.group.visible = true; car.state = 'arriving'; car.route = car.entryRoute; car.waypoint = 1;
    return true;
  }
  function clearTrafficCar(car) {
    if (drivewayHolder === car) drivewayHolder = null;
    if (window.__parkingExitReservation === car) window.__parkingExitReservation = null;
    const idx = w.colliders.indexOf(car.collider);
    if (idx >= 0) w.colliders.splice(idx, 1);
    car.group.visible = false; car.state = 'waiting'; car.elapsed = 0; car.route = null;
    car.nextSpawn = car.retrySeconds;
  }
  function stepCar(car, dt) {
    if (car.state === 'waiting') {
      car.elapsed += dt;
      if (car.elapsed >= car.nextSpawn) { if (!spawn(car)) car.elapsed = car.nextSpawn - 1.0; }
      return;
    }
    if (car.state === 'parked') {
      car.elapsed += dt;
      if (car.elapsed >= car.parkSeconds && (!drivewayHolder || drivewayHolder === car)) {
        drivewayHolder = car; car.elapsed = 0; car.state = 'leaving'; car.route = car.exitRoute; car.waypoint = 1;
      }
      return;
    }
    const target = car.route[car.waypoint];
    if (!target) {
      if (car.state === 'arriving') { car.state = 'parked'; car.elapsed = 0; if (drivewayHolder === car) drivewayHolder = null; }
      else clearTrafficCar(car);
      return;
    }
    if (car.state === 'leaving' && car.waypoint >= 3 && car.group.position.x < -7) {
      // Stop new eastbound traffic before the exit, then wait for vehicles
      // already in the merge area to leave before rotating into the lane.
      if (!window.__parkingExitReservation) window.__parkingExitReservation = car;
      if (window.__parkingExitReservation !== car) return;
      const occupied = traffic.main.concat(traffic.outer, traffic.police, [window.__cityBus?.bus]).some(v => {
        if (!v || v === car || !v.group || v.group.visible === false) return false;
        const p=v.group.position, col=v._trafficCol || v.collider || traffic.bounds(p.x,p.z,v.group.rotation.y);
        return col.maxX > -25 && col.minX < -5 && col.maxZ > 8.8 && col.minZ < 11.3;
      });
      if (car.waypoint === 3 && occupied) return;
    }
    const p = car.group.position, dx = target[0] - p.x, dz = target[1] - p.z, dist = Math.hypot(dx, dz);
    if (dist < .10) { car.waypoint++; return; }
    const yaw = -Math.atan2(dz, dx), step = Math.min(dist, 4.8 * dt);
    const nx = p.x + dx / dist * step, nz = p.z + dz / dist * step;
    if (!traffic.canMove(car, nx, nz, yaw, dt)) return;
    p.set(nx, .11, nz); car.group.rotation.y = yaw; traffic.sync(car);
    if (window.__parkingExitReservation === car && p.x >= -7) window.__parkingExitReservation = null;
    for (const wheel of car.wheels) wheel.rotation.z -= step / .35;
  }
  const previousUpdate = w.update.bind(w);
  w.update = function (dt, playerPos, playing) {
    const result = previousUpdate(dt, playerPos, playing);
    if (!playing) return result;
    for (const car of visitors) stepCar(car, dt);
    return result;
  };
  window.__marketParking = { lot, visitors, inspect: () => visitors.map(c => ({ id: c.id, state: c.state, position: [c.group.position.x, c.group.position.z], visible: c.group.visible })) };
})();
