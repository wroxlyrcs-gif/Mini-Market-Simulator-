/* Maç günü stadyum çevresinde, kullanıcının videosundan tezahürat. */
(function () {
  'use strict';
  const g = window.__mms;
  if (!g || !g.world || !g.audio) return;
  const audio = new Audio('stadium-chant.mp3');
  audio.loop = true;
  audio.preload = 'metadata';
  let pending = false, failed = false, wanted = false;

  function volume() {
    if (!g.player || !g.player.pos) return 0;
    const x = g.player.pos.x, z = g.player.pos.z;
    // Dikdörtgen stadyum alanına uzaklık: içeride tam, şehirde giderek daha sessiz.
    const dx = Math.max(0, Math.abs(x) - 30);
    const dz = z < 51 ? 51 - z : z > 85 ? z - 85 : 0;
    const distance = Math.hypot(dx, dz);
    const attenuation = Math.max(0, Math.min(1, 1 - distance / 85));
    return Math.max(0, Math.min(1, (Number(g.audio.sfxVol) || 0) * .55 * attenuation));
  }

  function updateSound() {
    const m = g.clock && g.clock.minutes;
    wanted = g.state === 'playing' && !document.hidden &&
      Number.isFinite(m) && m >= 1180 && m < 1320 && volume() > .003;
    audio.volume = volume();
    if (!wanted) {
      if (!audio.paused) audio.pause();
      return;
    }
    if (!audio.paused || pending || failed) return;
    pending = true;
    const attempt = audio.play();
    if (attempt && typeof attempt.then === 'function') {
      attempt.then(() => {
        pending = false;
        if (!wanted) audio.pause();
      }).catch(() => {
        pending = false;
        // Some browsers need a fresh user gesture after denying autoplay.
        failed = true;
      });
    } else pending = false;
  }
  function silence() {
    wanted = false;
    audio.pause();
  }
  // No work when the game is paused: the game's world.update is not called then.
  for (const name of ['pause', 'toMenu', 'onExit']) {
    const original = g[name].bind(g);
    g[name] = function (...args) {
      silence();
      return original(...args);
    };
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) silence();
  });
  window.addEventListener('pagehide', silence);
  for (const name of ['pointerdown', 'keydown']) window.addEventListener(name, () => {
    if (failed) {
      failed = false;
      updateSound();
    }
  });
  const oldUpdate = g.world.update.bind(g.world);
  g.world.update = function (...args) {
    const result = oldUpdate(...args);
    updateSound();
    return result;
  };
  window.__stadiumCrowdSound = { audio, update: updateSound };
})();
