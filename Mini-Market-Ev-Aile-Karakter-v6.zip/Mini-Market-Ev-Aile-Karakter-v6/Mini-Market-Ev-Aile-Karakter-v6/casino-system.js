// MINI MARKET SIMULATOR: self-contained casino extension. Practice credits are local-only.
window.MMS_CASINO = (() => {
  const KEY = 'mms_casino_wallet_v1';
  // Konum: market ile kuzey çevre yolu arasındaki boş doğu çayırı (eskiden kalabalık şehir merkezi kenarındaydı).
  const CX = 72.0, CZ = -3.0, W = 8.6, D = 8.2, H = 4.35;
  const FRONT = CZ - D / 2, BACK = CZ + D / 2, LEFT = CX - W / 2, RIGHT = CX + W / 2;
  const LANGS = ['tr', 'en', 'az', 'ru'];
  const TXT = {
    tr: { enter:'🎰 Casinoya gir', exit:'🚪 Casinodan çık', reception:'🎟️ Resepsiyon: sanal kredi al', slot:'🎰 Slot oyna', blackjack:'🂡 Blackjack oyna', poker:'♠ Poker oyna', title:'ŞEHİR CASİNOSU', balance:'Casino kredisi', practice:'Yalnızca oyun içi deneme kredileri. Gerçek para yok.', receptionTitle:'Kredi resepsiyonu', pack:'Sanal kredi paketi', free:'Sanal satın al', back:'Kapat', stand:'Masadan kalk', wager:'Bahis', spin:'Çevir', deal:'Dağıt', hit:'Kart çek', stay:'Dur', draw:'Kartları değiştir ve aç', hold:'Tut', clear:'İşaretleri temizle', result:'Sonuç', buy:'Kredi al', notEnough:'Yetersiz kredi. Resepsiyondan sanal kredi al.', noBet:'Önce geçerli bir bahis seç.', win:'Kazandın', lose:'Kaybettin', push:'Berabere', dealer:'Kasa', player:'Sen', slots:'Slot makineleri', table:'Oyun masası', credits:'Kredi', rules:'Sanal oyun kredileri yerel kayda yazılır; gerçek para yatırma/çekme yok.', payout:'Ödeme', menu:'Oyun seç', return:'Lobide devam et', dealerHand:'Dağıtıcı', yourHand:'Elin', cards:'Kartlar', noBalance:'Bakiyen yetersiz.' },
    en: { enter:'🎰 Enter casino', exit:'🚪 Exit casino', reception:'🎟️ Reception: get practice credits', slot:'🎰 Play slots', blackjack:'🂡 Play blackjack', poker:'♠ Play poker', title:'CITY CASINO', balance:'Casino credits', practice:'In-game practice credits only. No real money.', receptionTitle:'Credit reception', pack:'Practice-credit pack', free:'Buy practice pack', back:'Close', stand:'Leave table', wager:'Wager', spin:'Spin', deal:'Deal', hit:'Hit', stay:'Stand', draw:'Draw and reveal', hold:'Hold', clear:'Clear holds', result:'Result', buy:'Get credits', notEnough:'Not enough credits. Get practice credits at reception.', noBet:'Choose a valid wager first.', win:'You win', lose:'You lose', push:'Push', dealer:'Dealer', player:'You', slots:'Slot machines', table:'Game table', credits:'Credits', rules:'Practice credits are saved locally; no real-money deposits or withdrawals.', payout:'Payout', menu:'Choose a game', return:'Continue in lobby', dealerHand:'Dealer', yourHand:'Your hand', cards:'Cards', noBalance:'Not enough balance.' },
    az: { enter:'🎰 Kazinoya daxil ol', exit:'🚪 Kazinodan çıx', reception:'🎟️ Resepsiyon: virtual kredit al', slot:'🎰 Slot oyna', blackjack:'🂡 Blackjack oyna', poker:'♠ Poker oyna', title:'ŞƏHƏR KAZİNOSU', balance:'Kazino krediti', practice:'Yalnız oyun daxili sınaq krediti. Real pul yoxdur.', receptionTitle:'Kredit resepsiyonu', pack:'Virtual kredit paketi', free:'Virtual satın al', back:'Bağla', stand:'Masadan qalx', wager:'Mərc', spin:'Fırlat', deal:'Payla', hit:'Kart çək', stay:'Dayan', draw:'Kartları dəyiş və aç', hold:'Saxla', clear:'Seçimi təmizlə', result:'Nəticə', buy:'Kredit al', notEnough:'Kredit çatmır. Resepsiyondan virtual kredit al.', noBet:'Əvvəl düzgün mərc seç.', win:'Qazandın', lose:'Uduzdun', push:'Heç-heçə', dealer:'Diler', player:'Sən', slots:'Slot aparatları', table:'Oyun masası', credits:'Kredit', rules:'Virtual kreditlər yerli yaddaşa yazılır; real pul yoxdur.', payout:'Ödəniş', menu:'Oyun seç', return:'Lobidə davam et', dealerHand:'Diler', yourHand:'Əlin', cards:'Kartlar', noBalance:'Balans kifayət etmir.' },
    ru: { enter:'🎰 Войти в казино', exit:'🚪 Выйти из казино', reception:'🎟️ Ресепшен: получить игровые кредиты', slot:'🎰 Играть в слоты', blackjack:'🂡 Играть в блэкджек', poker:'♠ Играть в покер', title:'ГОРОДСКОЕ КАЗИНО', balance:'Кредиты казино', practice:'Только игровые тренировочные кредиты. Без реальных денег.', receptionTitle:'Стойка кредитов', pack:'Пакет игровых кредитов', free:'Купить игровые', back:'Закрыть', stand:'Встать из-за стола', wager:'Ставка', spin:'Крутить', deal:'Раздать', hit:'Еще карту', stay:'Хватит', draw:'Заменить карты и открыть', hold:'Оставить', clear:'Снять выбор', result:'Результат', buy:'Получить кредиты', notEnough:'Не хватает кредитов. Получите их на ресепшене.', noBet:'Сначала выберите допустимую ставку.', win:'Вы выиграли', lose:'Вы проиграли', push:'Ничья', dealer:'Дилер', player:'Вы', slots:'Игровые автоматы', table:'Игровой стол', credits:'Кредиты', rules:'Игровые кредиты сохраняются локально; без реальных депозитов и выводов.', payout:'Выплата', menu:'Выберите игру', return:'Остаться в холле', dealerHand:'Дилер', yourHand:'Ваша рука', cards:'Карты', noBalance:'Недостаточно средств.' },
  };
  const EXTRA={
    tr:{slotHelp:'Sanal krediyle çevir. Üç aynı sembol 12 kata kadar kazandırır.',pair:'Çift: 1,25 kat iade',value:'Değer',start:'Başlamak için dağıt.',holdHelp:'En fazla üç kart seçip tutabilirsin.',holdPrompt:'En fazla üç kartı tut, sonra kartları değiştir.',returned:'iade edildi',bust:'21 aşıldı',dealerBlackjack:'kasa blackjack',versus:'karşı',city:'ŞEHİR • CANLI OYUNLAR',receptionSign:'RESEPSİYON',hands:['Yüksek kart','Bir çift','İki çift','Üçlü','Kent','Renk','Full','Kare','Renkli kent','Royal flush']},
    en:{slotHelp:'Spin with practice credits. Three matching symbols pay up to 12×.',pair:'Pair returns 1.25×',value:'Value',start:'Deal to start.',holdHelp:'Tap up to three cards to keep.',holdPrompt:'Hold up to three cards, then draw.',returned:'returned',bust:'bust',dealerBlackjack:'dealer blackjack',versus:'vs',city:'CITY • LIVE GAMES',receptionSign:'RECEPTION',hands:['High card','One pair','Two pair','Three of a kind','Straight','Flush','Full house','Four of a kind','Straight flush','Royal flush']},
    az:{slotHelp:'Virtual kreditlə fırlat. Üç eyni simvol 12 dəfəyə qədər qazandırır.',pair:'Cüt: 1,25 qat qaytarılır',value:'Dəyər',start:'Başlamaq üçün payla.',holdHelp:'Üçədək kart seçib saxla.',holdPrompt:'Üçədək kartı saxla, sonra dəyiş.',returned:'qaytarıldı',bust:'21 aşıldı',dealerBlackjack:'diler blackjack',versus:'qarşı',city:'ŞƏHƏR • CANLI OYUNLAR',receptionSign:'RESEPSİYON',hands:['Yüksək kart','Bir cüt','İki cüt','Üçlük','Küçə','Fleş','Full house','Kare','Straight flush','Royal flush']},
    ru:{slotHelp:'Крутите за игровые кредиты. Три одинаковых символа дают до 12×.',pair:'Пара возвращает 1,25×',value:'Сумма',start:'Раздайте карты для начала.',holdHelp:'Выберите до трёх карт, которые хотите оставить.',holdPrompt:'Оставьте до трёх карт, затем замените остальные.',returned:'возвращено',bust:'перебор',dealerBlackjack:'блэкджек дилера',versus:'против',city:'ГОРОД • ИГРЫ',receptionSign:'РЕСЕПШЕН',hands:['Старшая карта','Пара','Две пары','Тройка','Стрит','Флеш','Фулл-хаус','Каре','Стрит-флеш','Роял-флеш']}
  };
  const money = n => Math.max(0, Math.floor(Number(n) || 0)).toLocaleString('en-US');
  const lang = () => (window.__mms?.ui?.lang && TXT[window.__mms.ui.lang]) ? window.__mms.ui.lang : 'tr';
  const t = k => TXT[lang()][k] || EXTRA[lang()][k] || TXT.en[k] || EXTRA.en[k] || k;
  const message = (tr, en, az, ru) => ({ tr, en, az, ru });
  const freshWallet = () => ({ balance: 0, wins: 0, losses: 0, played: 0, cashDay: 0, cashed: 0, version: 1 });
  const loadWallet = () => {
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!raw || typeof raw !== 'object') return freshWallet();
      return { balance: Math.max(0, Math.min(100000000, Math.floor(Number(raw.balance) || 0))), wins: Math.max(0, Math.floor(Number(raw.wins) || 0)), losses: Math.max(0, Math.floor(Number(raw.losses) || 0)), played: Math.max(0, Math.floor(Number(raw.played) || 0)), cashDay: Math.max(0, Math.floor(Number(raw.cashDay) || 0)), cashed: Math.max(0, Math.min(500, Math.floor(Number(raw.cashed) || 0))), version: 1 };
    } catch (_) { return freshWallet(); }
  };
  const wallet = loadWallet();
  let WLD = null, GAME = null, INSIDE = false, ROOT = null, BADGE = null, STYLE = null;
  let UI = null, UIKind = null, UIReturn = null, seated = false, returnPose = null, gameState = null;
  const hit = {};
  let doorLeaf = null, entryBarrier = null;
  const npcs = [];
  let npcClock = 0;
  const dynamicSigns=[];

  function saveWallet() { try { localStorage.setItem(KEY, JSON.stringify(wallet)); } catch (_) {} }
  // v6: kredi -> para (1 kredi = 1 $), günlük (oyun günü) en fazla 500 $
  const CASH_LIMIT = 500;
  const CT = {
    tr: { title:'Krediyi paraya çevir', info:'1 kredi = 1 $. Günlük en fazla 500 $ çekilir. Bugün kalan hak: ', all:'Maksimum', btn:'Çevir', none:'Bugünkü 500 $ çekim limitin doldu.', nocred:'Yeterli kredin yok.', done:'Krediden paraya çevrildi: +' },
    en: { title:'Convert credits to cash', info:'1 credit = $1. Up to $500 per day. Left today: ', all:'Maximum', btn:'Convert', none:'Today\'s $500 cash-out limit is reached.', nocred:'Not enough credits.', done:'Credits converted to cash: +' },
    az: { title:'Krediti pula çevir', info:'1 kredit = 1 $. Gündə ən çox 500 $. Bu gün qalan: ', all:'Maksimum', btn:'Çevir', none:'Bugünkü 500 $ limiti dolub.', nocred:'Kifayət qədər kredit yoxdur.', done:'Kredit pula çevrildi: +' },
    ru: { title:'Обмен кредитов на деньги', info:'1 кредит = 1 $. До 500 $ в день. Осталось сегодня: ', all:'Максимум', btn:'Обменять', none:'Дневной лимит 500 $ исчерпан.', nocred:'Недостаточно кредитов.', done:'Кредиты обменяны: +' },
  };
  const ct = k => (CT[lang()] || CT.tr)[k];
  const gameDay = () => Math.max(1, Math.floor(Number(GAME?.data?.day) || 1));
  const cashLeft = () => { if (wallet.cashDay !== gameDay()) { wallet.cashDay = gameDay(); wallet.cashed = 0; } return Math.max(0, CASH_LIMIT - wallet.cashed); };
  function cashOut(req) {
    const left = cashLeft();
    if (left <= 0) { flash(ct('none')); return; }
    if (wallet.balance <= 0) { flash(ct('nocred')); return; }
    const n = Math.min(req === 'max' ? Infinity : Math.max(0, Math.floor(Number(req) || 0)), left, wallet.balance);
    if (!(n > 0) || !GAME?.data) { flash(ct('nocred')); return; }
    wallet.balance -= n; wallet.cashed += n; wallet.cashDay = gameDay();
    GAME.data.money += n; saveWallet(); updateBadge();
    if (GAME.saveNow) GAME.saveNow();
    flash(ct('done') + n + ' $');
    if (UIKind === 'reception') renderUI();
  }
  function flash(text) { if (WLD?.hooks?.say) WLD.hooks.say(text); }
  function addHit(id, label, box, action, active = true) {
    WLD.addInteractable({ id, label, box, action });
    const hb = WLD.hitboxes[WLD.hitboxes.length - 1];
    hit[id] = { hb, y: hb.position.y };
    if (!active) hb.position.y = -50;
    return hb;
  }
  function showHit(id, visible) { const x = hit[id]; if (x) x.hb.position.y = visible ? x.y : -50; }
  function tex(w, h, fn) { return WLD.canvasTex(w, h, fn); }
  function sign(text, x, y, z, width, height, bg, fg, fontSize, rotation = Math.PI) {
    let ctx=null, image=null;
    const draw=(c,cw,ch)=>{
      c.fillStyle = bg; c.fillRect(0, 0, cw, ch);
      c.strokeStyle = fg; c.lineWidth = 7; c.strokeRect(6, 6, cw - 12, ch - 12);
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = fg;
      c.font = '900 ' + fontSize + 'px Arial, sans-serif';
      const label=text==='RECEPTION'?t('receptionSign'):text==='CITY  •  LIVE GAMES'?t('city'):text;
      c.fillText(label, cw / 2, ch / 2);
    };
    image=tex(512,128,(c,cw,ch)=>{ctx=c;draw(c,cw,ch);});
    if(text==='RECEPTION'||text==='CITY  •  LIVE GAMES')dynamicSigns.push(()=>{draw(ctx,512,128);image.needsUpdate=true;});
    return WLD.sign(image, width, height, x, y, z, rotation);
  }
  function stripe(x, y, z, sx, sy, sz, color) {
    WLD.b(sx, sy, sz, x, y, z, WLD.mat(color, { emissive: color }), { cast: false, receive: false, dynamic: true });
  }
  function chair(x, z, color = 0x272b34, rotation = 0) {
    const seat = WLD.b(0.62, 0.15, 0.58, x, 0.48, z, color, { cast: false });
    const back = WLD.b(0.62, 0.76, 0.12, x, 0.58, z + 0.24, color, { cast: false });
    seat.rotation.y = rotation; back.rotation.y = rotation;
    WLD.cyl(0.07, 0.46, x, 0.02, z, 0x5b626b, { low: true, cast: false });
  }
  function human(role, x, z, colors, route = null) {
    const P = window.__mmsPeople;
    if (!P?.buildHuman) return;
    const h = P.buildHuman({ shirt: colors.shirt, pants: colors.pants || 0x252a33, shoes: colors.shoes || 0x17191f, skin: colors.skin || 0xd8a77b, hair: colors.hair || 0x33251d, cap: colors.cap || null, vest: colors.vest || null, apron: colors.apron || null, scale: colors.scale || 0.94, slim: !!colors.slim, lod: true, face: { hairStyle: colors.hairStyle || 'short', mood: colors.mood || 'neutral', glasses: colors.glasses || null } });
    h.group.position.set(x, 0.17, z); WLD.root.add(h.group);
    if (h.lowGroup) { h.lowGroup.position.set(x, 0.17, z); WLD.root.add(h.lowGroup); }
    npcs.push({ role, h, x, z, baseY: 0.17, homeX: x, homeZ: z, route: route || [], target: 0, phase: npcs.length * 1.73, moving: false, changeAt: 4 + npcs.length * 1.4 });
  }
  function build(w, game) {
    WLD = w; GAME = game;
    const originalLanguage=game.ui.setLanguage.bind(game.ui);
    game.ui.setLanguage=function(language){const result=originalLanguage(language);dynamicSigns.forEach(fn=>fn());if(UI?.classList.contains('show'))renderUI();return result;};
    const NO = { cast: false, receive: false };
    const solid = { collide: true, cast: false };
    const glass = w.mat(0x8fd9ef, { opacity: 0.28 });
    const dark = 0x18232d, gold = 0xd6b15b, trim = 0x3b4552, wall = 0x222c37;

    // Ön avlu ve üç park yeri. Park yerleri araç ölçüsüne göre (sedan 5.15x2.25 m, hatchback 4.26x2.17 m)
    // 3.0 x 5.8 m yapıldı; arabalar çizgilerin ortasında, burnu binaya dönük park eder ve birbirine girmez.
    // Orta yer kapı önü yürüyüş yolu olarak boş bırakılır. Yükseklikler: avlu .07 < park yeri .12 < çizgi .15 (z-fighting yok).
    const BAY_W = 3.0, BAY_L = 5.8, BAY_STEP = 3.3, bayZ = FRONT - 4.65, BAY_TOP = 0.12;
    w.b(10.6, 0.06, 7.0, CX, 0.01, bayZ, 0x61666a, NO);
    // Ana yoldan (z 8.2) girişin önündeki otoparka inen yaya yolu. Üstü .035: ön avlunun (.07) altında kalır, aynı düzlemde değildir.
    {
      const z0 = FRONT - 6.0, z1 = 8.0;
      w.b(2.4, 0.035, z1 - z0, CX - 6.3, 0, (z0 + z1) / 2, 0xd9d4c8, NO);
    }
    const carSpots = [[0, 'hatch', 0x243d55], [2, 'sedan', 0x8b354b]];
    for (let i = 0; i < 3; i++) {
      const px = CX + (i - 1) * BAY_STEP;
      w.b(BAY_W, BAY_TOP - 0.05, BAY_L, px, 0.05, bayZ, 0x73787a, NO);
      w.b(0.08, 0.03, BAY_L - 0.2, px - BAY_W / 2 + 0.04, BAY_TOP, bayZ, 0xe9e5da, NO);
      w.b(0.08, 0.03, BAY_L - 0.2, px + BAY_W / 2 - 0.04, BAY_TOP, bayZ, 0xe9e5da, NO);
    }
    for (const [i, kind, color] of carSpots) {
      if (!window.MMS_VEH?.build) continue;
      const car = new THREE.Group();
      // Araç modelinin önü +x'tir; yaw -PI/2 burnu +z'ye (casino binasına) çevirir.
      car.position.set(CX + (i - 1) * BAY_STEP, BAY_TOP, bayZ); car.rotation.y = -Math.PI / 2;
      w.root.add(car); MMS_VEH.build(w, car, kind, color, 0x202428, 0xd7dce0, { static: true });
    }
    for (const x of [LEFT - 0.65, RIGHT + 0.65]) {
      w.b(0.18, 2.5, 0.18, x, 0.08, FRONT - 1.4, trim, NO);
      w.put('sphere', 0.32, 0.22, 0.32, x, 2.58, FRONT - 1.4, w.mat(0xffc85a, { emissive: 0xffa321 }), NO);
    }
    // Building foundation, raised entrance, glass façade and a complete walkable envelope.
    w.b(W + 0.5, 0.17, D + 0.35, CX, -0.02, CZ, 0x20242b, NO); // üstü .15: iç zeminle (.21) aynı düzlemde titremesin
    w.b(W - 0.42, 0.12, D - 0.42, CX, 0.09, CZ, 0x242b34, NO);
    // Fine floor tiles, drawn once as a compact canvas texture.
    const tile = tex(512, 512, (c, cw, ch) => {
      c.fillStyle = '#2b313a'; c.fillRect(0, 0, cw, ch);
      for (let x = 0; x < 8; x++) for (let y = 0; y < 8; y++) {
        c.fillStyle = (x + y) % 2 ? '#353c46' : '#2b313a';
        c.fillRect(x * cw / 8, y * ch / 8, cw / 8 - 1, ch / 8 - 1);
      }
      c.strokeStyle = 'rgba(222,188,101,.13)'; c.lineWidth = 2;
      for (let x = 0; x <= 8; x++) { c.beginPath(); c.moveTo(x * cw / 8, 0); c.lineTo(x * cw / 8, ch); c.stroke(); }
      for (let y = 0; y <= 8; y++) { c.beginPath(); c.moveTo(0, y * ch / 8); c.lineTo(cw, y * ch / 8); c.stroke(); }
    });
    w.put('plane', W - 0.35, D - 0.35, 1, CX, 0.17, CZ, new THREE.MeshLambertMaterial({ map: tile }), { rx: -Math.PI / 2, cast: false });
    // Side walls: transparent glass with a low solid sill. Invisible full-height colliders keep the room contained.
    for (const x of [LEFT, RIGHT]) {
      w.b(0.18, 0.72, D, x, 0.1, CZ, wall, NO);
      w.colliders.push({ minX: x - 0.12, maxX: x + 0.12, minZ: FRONT, maxZ: BACK });
      for (const z of [FRONT + 1.55, FRONT + 4.1, BACK - 1.55]) {
        w.b(0.06, 2.95, 2.32, x, 1.0, z, glass, NO);
        w.b(0.10, 3.1, 0.12, x, 0.95, z - 1.22, trim, NO);
        w.b(0.10, 3.1, 0.12, x, 0.95, z + 1.22, trim, NO);
      }
      w.b(0.18, 0.16, D, x, 3.95, CZ, trim, NO);
    }
    // Back wall, with a glowing horizontal glass band.
    w.b(W, 0.72, 0.18, CX, 0.1, BACK, wall, NO);
    w.colliders.push({ minX: LEFT, maxX: RIGHT, minZ: BACK - 0.12, maxZ: BACK + 0.12 });
    w.b(W - 0.5, 2.65, 0.07, CX, 1.0, BACK, glass, NO);
    w.b(W, 0.16, 0.18, CX, 3.95, BACK, trim, NO);
    // Front wall leaves a wide working entry. Glass panels flank the door; no blocking door collider.
    const doorWidth = 2.35;
    for (const side of [-1, 1]) {
      const span = (W - doorWidth) / 2;
      const wx = CX + side * (doorWidth / 2 + span / 2);
      w.b(span, 0.72, 0.18, wx, 0.1, FRONT, wall, NO);
      w.colliders.push({ minX: wx - span / 2, maxX: wx + span / 2, minZ: FRONT - 0.12, maxZ: FRONT + 0.12 });
      w.b(span - 0.16, 2.5, 0.07, wx, 1.0, FRONT, glass, NO);
      w.b(span, 0.16, 0.18, wx, 3.95, FRONT, trim, NO);
    }
    for (const x of [CX - doorWidth / 2, CX + doorWidth / 2]) w.b(0.12, 3.15, 0.18, x, 0.85, FRONT, gold, NO);
    w.b(W, 0.46, 0.22, CX, 3.88, FRONT, trim, NO);
    // Roof/ceiling: opaque from above, visible as a proper interior ceiling from below.
    w.b(W + 0.25, 0.22, D + 0.25, CX, H, CZ, 0x1c222b, NO);
    for (const x of [CX - 2.5, CX, CX + 2.5]) {
      w.b(1.35, 0.06, 0.28, x, H - 0.08, CZ - 2.0, WLD.mat(0xffe9b0, { emissive: 0xffd477 }), NO);
      w.b(1.35, 0.06, 0.28, x, H - 0.08, CZ + 1.0, WLD.mat(0xffe9b0, { emissive: 0xffd477 }), NO);
    }
    for (const [x, z, c] of [[LEFT, FRONT, 0xff4b60], [RIGHT, FRONT, 0x35d8eb], [LEFT, BACK, 0xffca61], [RIGHT, BACK, 0x9b73ff]]) {
      stripe(x, 3.62, z, 0.2, 0.18, 0.2, c);
    }
    stripe(CX, 4.22, FRONT - 0.02, 2.35, 0.08, 0.08, 0xf4c85a);
    sign('CASINO', CX, 3.05, FRONT - 0.15, 5.2, 1.1, '#18232d', '#ffd56a', 74, Math.PI);
    sign('CITY  •  LIVE GAMES', CX, 2.25, FRONT - 0.16, 4.0, 0.42, '#18232d', '#e7f0f5', 28, Math.PI);
    sign('CASINO', CX, 2.05, BACK - 0.06, 3.4, 0.68, '#18232d', '#ffd56a', 54, 0);
    // Door leafs are parked open to either side, leaving clear physical access.
    w.b(0.10, 2.25, 0.06, CX - 0.82, 0.2, FRONT + 0.11, glass, NO);
    w.b(0.10, 2.25, 0.06, CX + 0.82, 0.2, FRONT + 0.11, glass, NO);
    doorLeaf = w.b(doorWidth, 2.35, 0.06, CX, 0.18, FRONT, glass, NO);
    w.b(0.08, 0.72, 0.08, CX - 0.34, 0.75, FRONT - 0.06, gold, NO);
    w.b(0.08, 0.72, 0.08, CX + 0.34, 0.75, FRONT - 0.06, gold, NO);
    entryBarrier = { minX: CX - doorWidth / 2, maxX: CX + doorWidth / 2, minZ: FRONT - 0.12, maxZ: FRONT + 0.12 };
    for (const x of [CX - 1.18, CX + 1.18]) w.b(0.07, 2.5, 0.08, x, 0.15, FRONT, gold, NO);
    // Entrance mat and low-glare neon trim.
    w.b(2.2, 0.035, 0.72, CX, 0.21, FRONT + 0.65, 0x583b5e, NO);
    stripe(CX, 0.34, FRONT + 0.65, 1.9, 0.04, 0.04, 0x35d8eb);
    w.b(5.6, 0.035, 0.12, CX, 0.20, FRONT - 0.18, gold, NO);

    // Slot aisle: three low-poly machines with emissive screens and prompt hitboxes.
    const slotTexture = tex(256, 256, (c, cw, ch) => {
      c.fillStyle = '#142b38'; c.fillRect(0, 0, cw, ch);
      const colors = ['#f14e78', '#f5c451', '#5bd7c0'];
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = '900 88px Arial';
      ['7', '★', '◆'].forEach((s, i) => { c.fillStyle = colors[i]; c.fillText(s, 52 + i * 76, 112); });
      c.fillStyle = '#d8f4ff'; c.font = '800 22px Arial'; c.fillText('LUCKY CITY', cw / 2, 210);
    });
    for (let i = 0; i < 3; i++) {
      const x = LEFT + 1.05, z = FRONT + 2.05 + i * 1.63;
      w.b(0.86, 1.65, 0.8, x, 0.18, z, 0x262d39, { cast: false, collide: true });
      w.b(0.78, 0.22, 0.75, x, 1.78, z, i === 1 ? 0xc72c59 : 0x314b62, { cast: false });
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.60), new THREE.MeshBasicMaterial({ map: slotTexture, side: THREE.DoubleSide }));
      screen.position.set(x + 0.44, 1.25, z); screen.rotation.y = Math.PI / 2; w.root.add(screen);
      w.b(0.05, 0.1, 0.1, x + 0.47, 0.86, z, gold, NO);
      for (const dz of [-0.24, 0.24]) w.cyl(0.035, 0.12, x + 0.47, 0.68, z + dz, 0x7bd3e5, { low: true, cast: false });
      addHit('casino-slot-' + i, message('🎰 Slot oyna', '🎰 Play slots', '🎰 Slot oyna', '🎰 Играть в слоты'), [1.55, 1.75, 0.95, x + 0.55, 0.2, z], () => startTable('slot', x + 1.25, z), false);
    }

    // Reception desk and lobby lounge.
    w.b(2.15, 0.82, 0.78, CX - 1.42, 0.18, BACK - 1.0, 0x513d35, { cast: false, collide: true });
    w.b(2.25, 0.14, 0.88, CX - 1.42, 0.98, BACK - 1.0, 0xc9a45d, NO);
    w.b(1.55, 0.42, 0.05, CX - 1.42, 1.34, BACK - 1.4, 0x293743, NO);
    sign('RECEPTION', CX - 1.42, 2.42, BACK - 0.24, 2.4, 0.56, '#263441', '#f4d88c', 40, 0);
    w.b(1.15, 0.10, 0.76, CX + 0.9, 0.18, FRONT + 1.65, 0x596274, NO);
    chair(CX + 0.9, FRONT + 1.5, 0x3c4451);
    w.b(0.72, 0.78, 0.72, CX + 0.9, 0.15, FRONT + 2.7, 0x375747, NO);
    for (let i = 0; i < 4; i++) {
      const x = CX + 0.9 + (i - 1.5) * 0.16;
      w.put('sphere', 0.16, 0.25, 0.16, x, 1.12 + (i % 2) * 0.08, FRONT + 2.7, w.mat([0x2d8c58, 0x399b61, 0x69a558, 0x2b704c][i]), NO);
    }
    addHit('casino-reception', message('🎟️ Resepsiyon: sanal kredi al', '🎟️ Reception: get practice credits', '🎟️ Resepsiyon: virtual kredit al', '🎟️ Ресепшен: получить игровые кредиты'), [2.5, 2.1, 1.55, CX - 1.42, 0.2, BACK - 1.12], () => openUI('reception'), false);

    // Two card tables with felt, low-poly chairs and dealer positions.
    const table = (id, x, z, label, felt) => {
      w.cyl(1.05, 0.16, x, 0.92, z, 0x4b3428, { low: true, cast: false });
      w.cyl(0.94, 0.12, x, 1.04, z, felt, { low: true, cast: false });
      w.cyl(0.13, 0.90, x, 0.10, z, 0x51473f, { low: true, cast: false });
      w.colliders.push({ minX: x - 0.94, maxX: x + 0.94, minZ: z - 0.94, maxZ: z + 0.94 });
      sign(label, x, 1.46, z - 0.96, 1.6, 0.38, '#1b2832', '#f1d38a', 26, Math.PI);
      chair(x - 1.22, z, 0x2c3240, Math.PI / 2);
      chair(x + 1.22, z, 0x2c3240, -Math.PI / 2);
      chair(x, z - 1.13, 0x2c3240);
      return { x, z };
    };
    const bj = table('bj', CX + 2.17, FRONT + 3.08, 'BLACKJACK', 0x176046);
    const po = table('po', CX + 2.17, FRONT + 6.16, 'POKER', 0x164a67);
    addHit('casino-blackjack', message('🂡 Blackjack oyna', '🂡 Play blackjack', '🂡 Blackjack oyna', '🂡 Играть в блэкджек'), [2.7, 1.75, 2.55, bj.x, 0.35, bj.z], () => startTable('blackjack', bj.x - 1.45, bj.z - 0.25), false);
    addHit('casino-poker', message('♠ Poker oyna', '♠ Play poker', '♠ Poker oyna', '♠ Играть в покер'), [2.7, 1.75, 2.55, po.x, 0.35, po.z], () => startTable('poker', po.x - 1.45, po.z - 0.25), false);
    // A clean route between entry, reception, slots and the tables.
    for (const x of [CX - 0.15, CX + 0.9]) w.b(0.08, 0.55, 0.08, x, 0.20, BACK - 2.0, gold, NO);
    for (const z of [FRONT + 2.1, FRONT + 4.0, FRONT + 5.8]) w.b(0.75, 0.035, 0.12, CX + 0.6, 0.20, z, 0x59626d, NO);

    // Real 3D reception, dealers, security and visitors, using the project's existing character rigs.
    human('security', CX - 1.85, FRONT - 0.08, { shirt: 0x1b3046, pants: 0x18212b, vest: 0x223b55, cap: 0x172738, skin: 0xd4a078, hair: 0x26211e, scale: 0.97 }, [[CX - 2.0, FRONT - 0.2], [CX - 2.6, FRONT - 0.35], [CX - 2.0, FRONT - 0.2]]);
    human('reception', CX - 1.42, BACK - 0.55, { shirt: 0x273d55, pants: 0x252a33, vest: 0xb49757, skin: 0xe0ad82, hair: 0x33251d, scale: 0.90 });
    human('dealer-blackjack', bj.x + 0.05, bj.z + 1.35, { shirt: 0xf0eee7, pants: 0x252a33, vest: 0x7d2c3a, skin: 0xc98962, hair: 0x211d20, scale: 0.92 });
    human('guest-slots', LEFT + 2.1, FRONT + 3.0, { shirt: 0x7e3f79, pants: 0x31394b, skin: 0xe0ad82, hair: 0x4c3028, slim: true, scale: 0.92 }, [[LEFT + 2.1, FRONT + 3.0], [LEFT + 2.3, FRONT + 4.6], [CX - 1.2, FRONT + 4.0]]);
    human('guest-blackjack', bj.x - 1.14, bj.z - 0.05, { shirt: 0x477d66, pants: 0x30333b, skin: 0xd7a078, hair: 0x1e1b1b, scale: 0.94 });
    human('guest-poker', po.x - 1.14, po.z - 0.05, { shirt: 0x9a6638, pants: 0x313949, skin: 0xeac4a0, hair: 0x4a3225, scale: 0.92 }, [[po.x - 1.14, po.z - 0.05], [CX + 0.5, FRONT + 4.6], [po.x - 1.14, po.z - 0.05]]);

    addHit('casino-entry', message('🎰 Casinoya gir', '🎰 Enter casino', '🎰 Kazinoya daxil ol', '🎰 Войти в казино'), [3.0, 2.65, 1.25, CX, 0.05, FRONT - 0.12], enter, true);
    addHit('casino-exit', message('🚪 Casinodan çıx', '🚪 Exit casino', '🚪 Kazinodan çıx', '🚪 Выйти из казино'), [2.6, 2.5, 1.4, CX, 0.05, FRONT + 0.55], exit, false);
    setInterior(false);
    ensureUI();
  }

  function setInterior(on) {
    INSIDE = !!on;
    if (doorLeaf) doorLeaf.visible = !INSIDE;
    if (entryBarrier && WLD) {
      const i = WLD.colliders.indexOf(entryBarrier);
      if (INSIDE && i >= 0) WLD.colliders.splice(i, 1);
      else if (!INSIDE && i < 0) WLD.colliders.push(entryBarrier);
    }
    showHit('casino-entry', !INSIDE);
    showHit('casino-exit', INSIDE);
    showHit('casino-reception', INSIDE);
    showHit('casino-blackjack', INSIDE);
    showHit('casino-poker', INSIDE);
    for (let i = 0; i < 3; i++) showHit('casino-slot-' + i, INSIDE);
    if (BADGE) BADGE.style.display = INSIDE ? 'block' : 'none';
  }
  function enter() {
    if (!GAME || GAME.state !== 'playing') return;
    setInterior(true);
    GAME.player.setPosition(CX, FRONT + 1.0);
    GAME.fpsCam.setAngles(Math.PI, 0);
    GAME.fpsCam.update(0, GAME.player.pos, 0);
    GAME._promptKey = null;
    WLD.hooks.play?.('click');
  }
  function exit() {
    if (seated) leaveTable();
    setInterior(false);
    GAME.player.setPosition(CX, FRONT - 1.15);
    GAME.fpsCam.setAngles(0, 0);
    GAME.fpsCam.update(0, GAME.player.pos, 0);
    GAME._promptKey = null;
    WLD.hooks.play?.('click');
  }
  function safeSave(pos) { return INSIDE ? { x: CX, z: FRONT - 1.15 } : pos; }

  function ensureUI() {
    if (STYLE) return;
    STYLE = document.createElement('style');
    STYLE.textContent = `#mm-casino-balance{position:fixed;right:12px;top:calc(76px + env(safe-area-inset-top,0px));z-index:39;padding:7px 12px;border:1px solid rgba(247,210,121,.6);border-radius:12px;background:rgba(15,22,31,.92);color:#ffe5a1;font:800 14px system-ui,sans-serif;pointer-events:none;display:none}#mm-casino{position:fixed;inset:0;z-index:120;display:none;align-items:center;justify-content:center;padding:12px;background:rgba(5,9,16,.78);font:600 15px system-ui,sans-serif;color:#f5f1e8}#mm-casino.show{display:flex}#mm-casino .cc-panel{width:min(600px,96vw);max-height:min(90vh,820px);overflow:auto;border:1px solid rgba(243,207,123,.65);border-radius:20px;background:radial-gradient(ellipse at top,#34414e 0%,#18222c 55%,#121820 100%);box-shadow:0 20px 70px rgba(0,0,0,.55);padding:clamp(14px,3vw,24px)}#mm-casino h2{margin:0;color:#f7d27d;font-size:clamp(20px,4vw,28px)}#mm-casino h3{margin:12px 0 6px;color:#f4d991}#mm-casino p{margin:7px 0;color:#e1e5e7}#mm-casino .cc-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}#mm-casino .cc-balance{padding:8px 11px;border-radius:999px;background:rgba(255,211,116,.12);color:#ffe4a2;font-weight:900;white-space:nowrap}#mm-casino .cc-note{padding:10px 12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.04);font-size:13px;line-height:1.4}#mm-casino .cc-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:12px 0}#mm-casino .cc-row.spread{justify-content:space-between}#mm-casino button,#mm-casino select{font:inherit;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.17);border-radius:11px;background:#344452;padding:10px 13px;min-height:42px;cursor:pointer}#mm-casino button.primary{background:linear-gradient(135deg,#d3a84e,#f1d889);color:#1a2027;border:0}#mm-casino button.secondary{background:#5c3448}#mm-casino button:disabled{opacity:.45;cursor:not-allowed}#mm-casino .cc-card{display:inline-flex;align-items:center;justify-content:center;min-width:48px;height:66px;margin:3px;border-radius:8px;background:#f4f1e8;color:#19222a;font:900 17px Georgia,serif;box-shadow:0 3px 8px #0005}#mm-casino .cc-card.red{color:#bd2438}#mm-casino .cc-card.back{background:repeating-linear-gradient(45deg,#4d6c89,#4d6c89 5px,#283b50 5px,#283b50 10px);color:#fff}#mm-casino button.cc-card{padding:0;border:2px solid transparent}#mm-casino button.cc-card.selected{border-color:#ffcb5c;transform:translateY(-4px)}#mm-casino .cc-table{padding:10px 12px;border-radius:13px;background:rgba(19,76,57,.34);border:1px solid rgba(137,217,181,.2);margin:8px 0}#mm-casino .cc-result{padding:10px 12px;border-radius:12px;background:rgba(246,211,126,.13);color:#ffe4a2;font-weight:900;min-height:40px}#mm-casino .cc-small{font-size:12px;opacity:.8}#mm-casino .cc-pack{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px;margin:8px 0;border:1px solid rgba(255,255,255,.12);border-radius:13px;background:rgba(255,255,255,.04)}@media(max-width:520px){#mm-casino .cc-panel{padding:14px;border-radius:15px}#mm-casino .cc-row>*{flex:1}#mm-casino .cc-card{min-width:40px;height:58px}}`;
    document.head.appendChild(STYLE);
    BADGE = document.createElement('div'); BADGE.id = 'mm-casino-balance'; document.body.appendChild(BADGE);
    UI = document.createElement('div'); UI.id = 'mm-casino';
    UI.innerHTML = '<section class="cc-panel" role="dialog" aria-modal="true" aria-live="polite"></section>';
    document.body.appendChild(UI);
    UI.addEventListener('pointerdown', e => e.stopPropagation());
    UI.addEventListener('click', onUIClick);
    window.addEventListener('keydown', e => {
      if (UI?.classList.contains('show') && e.code === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); closeUI(); }
    }, true);
    updateBadge();
  }
  function updateBadge() { if (BADGE) { BADGE.style.display = INSIDE ? 'block' : 'none'; BADGE.textContent = '🎟️ ' + t('balance') + ': ' + money(wallet.balance); } }
  function renderUI() {
    if (!UI) return;
    updateBadge();
    const root = UI.querySelector('.cc-panel');
    const header = `<div class="cc-head"><h2>${UIKind === 'reception' ? t('receptionTitle') : UIKind === 'slot' ? t('slot') : UIKind === 'blackjack' ? t('blackjack') : t('poker')}</h2><span class="cc-balance">🎟️ ${money(wallet.balance)} ${t('credits')}</span></div>`;
    const note = `<p class="cc-note">${t('practice')}<br>${t('rules')}</p>`;
    const footer = UIKind === 'reception'
      ? `<div class="cc-row spread"><button data-act="close">${t('back')}</button></div>`
      : `<div class="cc-row spread"><button data-act="stand" class="secondary">${t('stand')}</button></div>`;
    let body = '';
    if (UIKind === 'reception') {
      body = `<h3>${t('pack')}</h3><p>${t('practice')}</p>${[100,500,1000].map(n => `<div class="cc-pack"><span><b>+${money(n)}</b> ${t('credits')}<br><small class="cc-small">${t('practice')}</small></span><button class="primary" data-act="claim" data-amount="${n}">${t('free')}</button></div>`).join('')}<h3>${ct('title')}</h3><p class="cc-small">${ct('info')}<b>${cashLeft()} $</b></p><div class="cc-row">${[100, 250].map(n => `<button data-act="cash" data-amount="${n}" ${wallet.balance < 1 || cashLeft() < 1 ? 'disabled' : ''}>${n} $</button>`).join('')}<button class="primary" data-act="cash" data-amount="max" ${wallet.balance < 1 || cashLeft() < 1 ? 'disabled' : ''}>${ct('all')}</button></div><p class="cc-small">${t('rules')}</p>`;
    } else if (UIKind === 'slot') {
      const s = gameState?.slot;
      const reels = s ? s.reels.map((x, i) => `<span class="cc-card ${x === '♥' || x === '♦' ? 'red' : ''}">${x}</span>`).join('') : '🎰　🎰　🎰';
      body = `<p>${t('slots')}: ${t('slotHelp')}</p><div class="cc-table"><div style="font-size:32px;text-align:center;padding:8px">${reels}</div></div><div class="cc-row"><label>${t('wager')} <select id="mm-casino-wager">${[5,10,25,50,100].map(v => `<option value="${v}" ${v === (s?.bet || 10) ? 'selected' : ''}>${v}</option>`).join('')}</select></label><button class="primary" data-act="spin">${t('spin')}</button></div><div class="cc-result">${s?.message || t('menu')}</div><p class="cc-small">🍒 ×5 · ⭐ ×8 · 777 ×12 · ${t('pair')}</p>`;
    } else if (UIKind === 'blackjack') {
      const b = gameState?.blackjack;
      const renderCards = (cards, hideSecond = false) => cards.map((c, i) => hideSecond && i === 1 ? '<span class="cc-card back">◆</span>' : cardHTML(c)).join('');
      const inHand = b && !b.done;
      body = `<div class="cc-table"><h3>${t('dealerHand')}</h3><div>${renderCards(b?.dealer || [], !!inHand)}</div><p>${inHand ? '' : (b?.dealerValue ? t('value') + ': ' + b.dealerValue : '')}</p><h3>${t('yourHand')}</h3><div>${renderCards(b?.player || [])}</div><p>${b?.playerValue ? t('value') + ': ' + b.playerValue : ''}</p></div>${inHand ? `<div class="cc-row"><button class="primary" data-act="bj-hit">${t('hit')}</button><button data-act="bj-stand">${t('stay')}</button></div>` : `<div class="cc-row"><label>${t('wager')} <select id="mm-casino-wager">${[5,10,25,50,100].map(v => `<option value="${v}" ${v === (b?.bet || 10) ? 'selected' : ''}>${v}</option>`).join('')}</select></label><button class="primary" data-act="bj-deal">${t('deal')}</button></div>`}<div class="cc-result">${b?.message || t('menu')}</div>`;
    } else {
      const p = gameState?.poker;
      const started = p && !p.done;
      const dealer = p ? p.dealer.map((c, i) => started ? '<span class="cc-card back">◆</span>' : cardHTML(c)).join('') : '';
      const player = p ? p.player.map((c, i) => `<button class="cc-card ${c.suit === '♥' || c.suit === '♦' ? 'red' : ''} ${(p.hold || []).includes(i) ? 'selected' : ''}" data-act="hold" data-index="${i}" ${started ? '' : 'disabled'}>${cardLabel(c)}</button>`).join('') : '';
      body = `<div class="cc-table"><h3>${t('dealerHand')}</h3><div>${dealer}</div><h3>${t('yourHand')}</h3><div>${player || `<span class="cc-small">${t('start')}</span>`}</div></div>${started ? `<div class="cc-row"><button class="primary" data-act="poker-draw">${t('draw')}</button><button data-act="poker-clear">${t('clear')}</button></div><p class="cc-small">${t('holdHelp')}</p>` : `<div class="cc-row"><label>${t('wager')} <select id="mm-casino-wager">${[5,10,25,50,100].map(v => `<option value="${v}" ${v === (p?.bet || 10) ? 'selected' : ''}>${v}</option>`).join('')}</select></label><button class="primary" data-act="poker-deal">${t('deal')}</button></div>`}<div class="cc-result">${p?.message || t('menu')}</div>`;
    }
    root.innerHTML = `${header}${body}${note}${footer}`;
    const close = root.querySelector('[data-act="close"]'); if (close) close.focus({ preventScroll: true });
  }
  function openUI(kind, returnTo = null) {
    ensureUI();
    if (!UI) return;
    if (!UI.classList.contains('show')) {
      if (document.exitPointerLock) document.exitPointerLock();
      GAME.controls.setEnabled(false);
      UIReturn = returnTo;
    }
    UIKind = kind;
    if (kind === 'slot') gameState = { slot: { bet: 10, reels: ['🎰','🎰','🎰'], message: t('menu') } };
    if (kind === 'blackjack') gameState = { blackjack: null };
    if (kind === 'poker') gameState = { poker: null };
    UI.classList.add('show'); renderUI();
  }
  function closeUI() {
    if (!UI?.classList.contains('show')) return;
    if (seated) { leaveTable(); return; }
    UI.classList.remove('show');
    if (UIReturn) {
      const back = UIReturn; UIReturn = null;
      if (back === 'reception') openUI('reception'); else openUI(back);
      return;
    }
    UIKind = null; gameState = null;
    if (GAME?.controls) GAME.controls.setEnabled(GAME.state === 'playing');
    if (GAME) GAME._promptKey = null;
  }
  function leaveTable() {
    if (!seated) { closeUI(); return; }
    if (UI?.classList.contains('show')) { UIReturn = null; UI.classList.remove('show'); }
    UIKind = null; gameState = null;
    seated = false;
    if (returnPose && GAME) {
      GAME.player.setPosition(returnPose.x, returnPose.z);
      GAME.fpsCam.setAngles(returnPose.yaw, 0);
      GAME.fpsCam.update(0, GAME.player.pos, 0);
    }
    returnPose = null;
    if (GAME?.controls) GAME.controls.setEnabled(GAME.state === 'playing');
    if (GAME) GAME._promptKey = null;
  }
  function startTable(kind, sx, sz) {
    if (!INSIDE || !GAME || GAME.state !== 'playing') return;
    seated = true;
    returnPose = { x: GAME.player.pos.x, z: GAME.player.pos.z, yaw: GAME.fpsCam.yaw };
    GAME.player.setPosition(sx, sz);
    GAME.fpsCam.setAngles(kind === 'slot' ? Math.PI / 2 : -Math.PI / 2, -0.02);
    GAME.fpsCam.update(0, GAME.player.pos, 0);
    openUI(kind);
  }

  function wager() {
    const el = UI?.querySelector('#mm-casino-wager');
    const bet = Math.floor(Number(el?.value) || 0);
    if (![5,10,25,50,100].includes(bet)) return 0;
    return bet;
  }
  function placeBet(bet) {
    if (!bet || wallet.balance < bet) { flash(message('Yetersiz casino kredisi.', 'Not enough casino credits.', 'Kazino krediti kifayət etmir.', 'Недостаточно кредитов казино.')); return false; }
    wallet.balance -= bet; wallet.played++; saveWallet(); updateBadge(); return true;
  }
  function settle(outcome, amount) {
    amount = Math.max(0, Math.floor(amount || 0));
    wallet.balance += amount;
    if (outcome === 'win') wallet.wins++; else if (outcome === 'lose') wallet.losses++;
    saveWallet(); updateBadge();
    return amount;
  }
  const symbols = ['🍒','🍋','🔔','💎','⭐','7️⃣'];
  function spin() {
    const bet = wager(); if (!bet) return;
    if (!placeBet(bet)) return;
    const reels = [0,1,2].map(() => symbols[Math.floor(Math.random() * symbols.length)]);
    const counts = {}; reels.forEach(x => counts[x] = (counts[x] || 0) + 1);
    const max = Math.max(...Object.values(counts));
    let mult = 0;
    if (max === 3) mult = reels[0] === '7️⃣' ? 12 : reels[0] === '⭐' ? 8 : 5;
    else if (max === 2) mult = 1.25;
    const returned = settle(mult ? 'win' : 'lose', Math.round(bet * mult));
    const state = gameState.slot;
    state.bet = bet; state.reels = reels;
    state.message = mult ? `${t('win')}! ${t('payout')}: ${money(returned)} ${t('credits')} (${mult}×)` : `${t('lose')}. -${money(bet)} ${t('credits')}`;
    renderUI();
  }
  function makeDeck() {
    const deck = [];
    for (const suit of ['♠','♥','♦','♣']) for (let rank = 2; rank <= 14; rank++) deck.push({ rank, suit });
    for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    return deck;
  }
  const cardLabel = c => `${c.rank === 14 ? 'A' : c.rank === 13 ? 'K' : c.rank === 12 ? 'Q' : c.rank === 11 ? 'J' : c.rank}${c.suit}`;
  const cardHTML = c => `<span class="cc-card ${c.suit === '♥' || c.suit === '♦' ? 'red' : ''}">${cardLabel(c)}</span>`;
  function bjValue(cards) {
    let total = 0, aces = 0;
    for (const c of cards) { if (c.rank === 14) { total += 11; aces++; } else total += Math.min(c.rank, 10); }
    while (total > 21 && aces) { total -= 10; aces--; }
    return total;
  }
  function blackJackDeal() {
    const bet = wager(); if (!bet) return;
    if (!placeBet(bet)) return;
    const deck = makeDeck(), player = [deck.pop(), deck.pop()], dealer = [deck.pop(), deck.pop()];
    const b = gameState.blackjack = { bet, deck, player, dealer, done: false, message: '', playerValue: bjValue(player), dealerValue: 0 };
    const pn = b.playerValue === 21, dn = bjValue(dealer) === 21;
    if (pn || dn) {
      b.done = true; b.dealerValue = bjValue(dealer);
      if (pn && dn) { settle('push', bet); b.message = `${t('push')} · ${money(bet)} ${t('credits')} ${t('returned')}`; }
      else if (pn) { const paid = settle('win', Math.round(bet * 2.5)); b.message = `Blackjack! ${t('win')} · ${t('payout')}: ${money(paid)}`; }
      else { settle('lose', 0); b.message = `${t('lose')} · ${t('dealerBlackjack')}`; }
    }
    renderUI();
  }
  function blackJackHit() {
    const b = gameState?.blackjack; if (!b || b.done) return;
    b.player.push(b.deck.pop());
    b.playerValue = bjValue(b.player);
    if (b.playerValue >= 21) {
      b.done = true;
      if (b.playerValue > 21) { b.dealerValue = bjValue(b.dealer); settle('lose', 0); b.message = `${t('lose')} · ${t('bust')} (${b.playerValue})`; }
      else { while (bjValue(b.dealer) < 17) b.dealer.push(b.deck.pop()); b.dealerValue = bjValue(b.dealer); finishBlackjack(b); }
    }
    renderUI();
  }
  function blackJackStand() {
    const b = gameState?.blackjack; if (!b || b.done) return;
    b.done = true;
    while (bjValue(b.dealer) < 17) b.dealer.push(b.deck.pop());
    b.dealerValue = bjValue(b.dealer); b.playerValue = bjValue(b.player);
    finishBlackjack(b); renderUI();
  }
  function finishBlackjack(b) {
    if (b.playerValue > 21) { settle('lose', 0); b.message = `${t('lose')} · ${t('bust')}`; return; }
    if (b.dealerValue > 21 || b.playerValue > b.dealerValue) { const paid = settle('win', b.bet * 2); b.message = `${t('win')} · ${t('payout')}: ${money(paid)}`; }
    else if (b.playerValue === b.dealerValue) { settle('push', b.bet); b.message = `${t('push')} · ${money(b.bet)} ${t('credits')} ${t('returned')}`; }
    else { settle('lose', 0); b.message = `${t('lose')} · ${t('dealer')} ${b.dealerValue}`; }
  }
  function pokerEval(hand) {
    const ranks = hand.map(c => c.rank).sort((a,b) => b-a), counts = {};
    ranks.forEach(r => counts[r] = (counts[r] || 0) + 1);
    const groups = Object.keys(counts).map(Number).sort((a,b) => counts[b] - counts[a] || b-a);
    const flush = hand.every(c => c.suit === hand[0].suit);
    const uniq = [...new Set(ranks)];
    let straightHigh = 0;
    if (uniq.length === 5) {
      if (uniq[0] - uniq[4] === 4) straightHigh = uniq[0];
      else if (uniq.join(',') === '14,5,4,3,2') straightHigh = 5;
    }
    let tier, tie;
    if (flush && straightHigh) { tier = straightHigh === 14 ? 9 : 8; tie = [straightHigh]; }
    else if (counts[groups[0]] === 4) { tier = 7; tie = [groups[0], groups[1]]; }
    else if (counts[groups[0]] === 3 && counts[groups[1]] === 2) { tier = 6; tie = [groups[0], groups[1]]; }
    else if (flush) { tier = 5; tie = ranks; }
    else if (straightHigh) { tier = 4; tie = [straightHigh]; }
    else if (counts[groups[0]] === 3) { tier = 3; tie = [groups[0], ...groups.slice(1).sort((a,b)=>b-a)]; }
    else if (counts[groups[0]] === 2 && counts[groups[1]] === 2) { tier = 2; tie = [Math.max(groups[0],groups[1]), Math.min(groups[0],groups[1]), groups.find(r => counts[r] === 1)]; }
    else if (counts[groups[0]] === 2) { tier = 1; tie = [groups[0], ...groups.slice(1).sort((a,b)=>b-a)]; }
    else { tier = 0; tie = ranks; }
    return { tier, tie };
  }
  const handName = n => EXTRA[lang()].hands[n];
  function compareHands(a,b) { const x=pokerEval(a), y=pokerEval(b); if(x.tier!==y.tier)return x.tier-y.tier; for(let i=0;i<Math.max(x.tie.length,y.tie.length);i++){const d=(x.tie[i]||0)-(y.tie[i]||0);if(d)return d;}return 0; }
  function pokerDeal() {
    const bet = wager(); if (!bet) return;
    if (!placeBet(bet)) return;
    const deck = makeDeck();
    gameState.poker = { bet, deck, player: deck.splice(0,5), dealer: deck.splice(0,5), hold: [], done: false, message: t('holdPrompt') };
    renderUI();
  }
  function pokerDraw() {
    const p = gameState?.poker; if (!p || p.done) return;
    const playerKeep = new Set(p.hold || []);
    p.player = p.player.map((c,i) => playerKeep.has(i) ? c : p.deck.pop());
    const dEval = pokerEval(p.dealer), counts = {};
    p.dealer.forEach(c => counts[c.rank] = (counts[c.rank] || 0) + 1);
    const ranked = p.dealer.map((c,i) => ({ c,i })).sort((a,b) => (counts[b.c.rank] > 1 ? 1 : 0) - (counts[a.c.rank] > 1 ? 1 : 0) || b.c.rank-a.c.rank);
    const keep = new Set(ranked.filter(x => counts[x.c.rank] > 1).map(x => x.i));
    if (!keep.size) ranked.slice(0,2).forEach(x => keep.add(x.i));
    p.dealer = p.dealer.map((c,i) => keep.has(i) ? c : p.deck.pop());
    p.done = true;
    const cmp = compareHands(p.player,p.dealer), playerEval = pokerEval(p.player), dealerEval = pokerEval(p.dealer);
    if (cmp > 0) { const paid = settle('win', p.bet * 2); p.message = `${t('win')} · ${handName(playerEval.tier)} ${t('versus')} ${handName(dealerEval.tier)} · ${t('payout')}: ${money(paid)}`; }
    else if (cmp === 0) { settle('push', p.bet); p.message = `${t('push')} · ${handName(playerEval.tier)}`; }
    else { settle('lose', 0); p.message = `${t('lose')} · ${handName(playerEval.tier)} ${t('versus')} ${handName(dealerEval.tier)}`; }
    renderUI();
  }
  function onUIClick(e) {
    const b = e.target.closest('[data-act]'); if (!b || !UI.contains(b)) return;
    const act = b.dataset.act;
    if (act === 'close') closeUI();
    else if (act === 'stand') leaveTable();
    else if (act === 'claim') {
      const amount = Math.max(0, Math.min(1000, Number(b.dataset.amount) || 0));
      if (!amount) return;
      wallet.balance = Math.min(100000000, wallet.balance + amount); saveWallet(); updateBadge();
      if (UIKind === 'reception') renderUI();
    } else if (act === 'cash') cashOut(b.dataset.amount);
    else if (act === 'spin') spin();
    else if (act === 'bj-deal') blackJackDeal();
    else if (act === 'bj-hit') blackJackHit();
    else if (act === 'bj-stand') blackJackStand();
    else if (act === 'poker-deal') pokerDeal();
    else if (act === 'poker-draw') pokerDraw();
    else if (act === 'poker-clear') { if (gameState?.poker) gameState.poker.hold = []; renderUI(); }
    else if (act === 'hold') {
      const p = gameState?.poker; const i = Number(b.dataset.index); if (!p || p.done || !Number.isInteger(i)) return;
      const set = new Set(p.hold || []);
      if (set.has(i)) set.delete(i); else if (set.size < 3) set.add(i);
      p.hold = [...set]; renderUI();
    }
  }
  function update(dt, game) {
    if (game?.state === 'playing') {
      npcClock += Math.min(dt, 0.05);
      for (const n of npcs) {
        const camera = game.player?.pos || {x:CX,z:CZ};
        const dist = Math.hypot(camera.x - n.x, camera.z - n.z);
        if (n.h.lowGroup) { const low = dist > 13 || game.settings?.quality === 'low'; n.h.group.visible = !low; n.h.lowGroup.visible = low; }
        if (!n.route.length) {
          n.h.walk?.(dt, 0.018 + Math.abs(Math.sin(npcClock * 1.5 + n.phase)) * 0.018);
          n.h.group.position.y = n.baseY + Math.sin(npcClock * 1.7 + n.phase) * 0.015;
          if (n.h.lowGroup) n.h.lowGroup.position.y = n.h.group.position.y;
          continue;
        }
        n.changeAt -= dt;
        if (n.changeAt <= 0) { n.target = (n.target + 1) % n.route.length; n.changeAt = 5 + ((n.phase * 11) % 5); }
        const to = n.route[n.target], dx = to[0] - n.x, dz = to[1] - n.z, d = Math.hypot(dx,dz);
        if (d > 0.09) {
          const step = Math.min(d, dt * 0.42); n.x += dx / d * step; n.z += dz / d * step;
          n.h.group.rotation.y = Math.atan2(dx,dz); if (n.h.lowGroup) n.h.lowGroup.rotation.y = n.h.group.rotation.y;
          n.h.walk?.(dt, Math.min(1, d * 0.9));
        } else n.h.walk?.(dt, 0.025);
        n.h.group.position.x = n.x; n.h.group.position.z = n.z;
        if (n.h.lowGroup) { n.h.lowGroup.position.x = n.x; n.h.lowGroup.position.z = n.z; }
      }
    }
    updateBadge();
  }
  function reset() {
    if (UI?.classList.contains('show')) { UI.classList.remove('show'); UIKind = null; gameState = null; UIReturn = null; }
    seated = false; returnPose = null; setInterior(false);
    if (GAME?.controls) GAME.controls.setEnabled(GAME.state === 'playing');
  }
  function inspect() { return { inside: INSIDE, seated, balance: wallet.balance, wins: wallet.wins, losses: wallet.losses, played: wallet.played, npcCount: npcs.length }; }
  return { build, update, reset, safeSave, enter, exit, getBalance: () => wallet.balance, inspect, pokerEval, compareHands, bjValue, money, loadWallet, saveWallet, KEY };
})();
