/* v3.7: low-poly blue/black city bus, route 25, animated doors, passenger boarding and traffic-aware driving. */
(function () {
  'use strict';
  const game=window.__mms,T=window.THREE,traffic=window.__cityTraffic;
  if(!game||!T||!traffic||!window.MMS_VEH||window.__cityBusBuilt)return;
  window.__cityBusBuilt=true;
  const world=game.world,peopleApi=window.__mmsPeople,regions=__req('player').REGIONS;
  const BUS={length:10.9,width:2.55,height:3.28,halfLength:5.45,halfWidth:1.34,routeSpeed:8.4,accel:2.0,dwellSeconds:8.5};
  const paintBlue=0x0756b4, darkBlue=0x071b30, black=0x111820, glassColor=0x152631, blueTrim=0x0b3f82, silver=0xaab4bd, yellow=0xf2c230, seatBlue=0x254b74;
  const root=new T.Group();root.name='CITY BUS 25';world.root.add(root);
  // Gerçek zamanlı gölge haritası hareketli otobüste geride kalıp siyah leke yapıyordu; araca bağlı yumuşak gölge kullanılır.
  if(window.MMS_VEH&&window.MMS_VEH.blobShadow)window.MMS_VEH.blobShadow(root,BUS.length*1.08,BUS.width*1.3,0);
  const mats={};
  function mat(name,color,opts={}){if(!mats[name])mats[name]=new T.MeshLambertMaterial({color,flatShading:true,...opts});return mats[name];}
  const bodyMat=mat('bus-blue',paintBlue),darkMat=mat('bus-black',black),frameMat=mat('bus-frame',darkBlue),metalMat=mat('bus-metal',silver),rubberMat=mat('bus-rubber',0x151719),seatMat=mat('bus-seat',seatBlue),yellowMat=mat('bus-yellow',yellow),
    floorMat=mat('bus-floor',0x4b5055),glassMat=mat('bus-glass',glassColor,{transparent:true,opacity:.67,depthWrite:false}),
    ledMat=new T.MeshBasicMaterial({map:null,side:T.DoubleSide,toneMapped:false}),lampWhite=new T.MeshBasicMaterial({color:0xfff7dc}),lampAmber=new T.MeshBasicMaterial({color:0xffb52e}),lampRed=new T.MeshBasicMaterial({color:0xd52025});
  function box(parent,sx,sy,sz,x,y,z,material,staticMesh=false){
    if(!parent||typeof parent.add!=='function'){
      const a=arguments;parent=root;sx=a[0];sy=a[1];sz=a[2];x=a[3];y=a[4];z=a[5];material=a[6];staticMesh=!!a[7];
    }
    const mesh=new T.Mesh(world.geo('box'),material);mesh.scale.set(sx,sy,sz);mesh.position.set(x,y,z);mesh.castShadow=false;mesh.receiveShadow=!staticMesh;
    if(staticMesh)mesh.userData.static=true;parent.add(mesh);return mesh;
  }
  function cyl(parent,r,h,x,y,z,material,axis='y',segments=12){
    const mesh=new T.Mesh(new T.CylinderGeometry(r,r,h,segments),material);mesh.position.set(x,y,z);
    if(axis==='z')mesh.rotation.x=Math.PI/2;if(axis==='x')mesh.rotation.z=Math.PI/2;parent.add(mesh);return mesh;
  }
  function plane(parent,width,height,x,y,z,texture,yaw=0){
    const mesh=new T.Mesh(world.geo('plane'),new T.MeshBasicMaterial({map:texture,side:T.DoubleSide,toneMapped:false}));
    mesh.scale.set(width,height,1);mesh.position.set(x,y,z);mesh.rotation.y=yaw;mesh.castShadow=false;mesh.receiveShadow=false;mesh.userData.static=true;parent.add(mesh);return mesh;
  }
  function displayTexture(text,kind='front'){
    return world.canvasTex(768,256,(ctx,w,h)=>{
      ctx.fillStyle='#090d12';ctx.fillRect(0,0,w,h);
      ctx.fillStyle='#15202b';ctx.fillRect(0,0,w,25);
      ctx.strokeStyle='#34485c';ctx.lineWidth=8;ctx.strokeRect(8,8,w-16,h-16);
      ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffbf25';ctx.shadowColor='#ffae17';ctx.shadowBlur=12;
      ctx.font='900 112px Arial,sans-serif';ctx.fillText('25',120,133);
      ctx.font='900 74px Arial,sans-serif';ctx.fillText('CITY CENTER',455,133);
      ctx.shadowBlur=0;
    });
  }
  const routeTex=displayTexture('25 CITY CENTER');
  // Low-floor chassis, blue body, black glazed belt and roof cap.
  box(root,10.45,.52,2.46,0,.74,0,mat('bus-chassis',0x28323c),true);
  box(root,10.50,.96,2.62,0,1.34,0,bodyMat,true);
  box(root,10.30,.14,2.64,0,.87,0,mat('bus-lower-trim',0x0b3262),true);
  box(root,10.18,.22,2.64,0,1.92,0,frameMat,true);
  box(root,10.20,.18,2.66,0,2.93,0,darkMat,true);
  box(root,10.25,.14,2.70,0,3.06,0,mat('bus-roof',0x20272d),true);
  box(root,3.0,.11,1.38,-2.6,3.16,0,mat('roof-ac',0x39434b),true);
  for(const x of [-3.5,-2.6,-1.7])box(root,.08,.07,1.2,x,3.23,0,metalMat,true);
  // Wrapped front / rear façades with panoramic glass and bumpers.
  box(root,.16,2.45,2.49,5.17,1.78,0,bodyMat,true);
  box(root,.08,1.33,2.20,5.27,2.40,0,glassMat,true);
  box(root,.12,.20,2.55,5.24,1.04,0,black,true);
  box(root,.16,2.45,2.49,-5.17,1.78,0,bodyMat,true);
  box(root,.08,1.20,2.16,-5.27,2.40,0,glassMat,true);
  box(root,.15,.20,2.65,-5.21,1.04,0,black,true);
  box(root,.20,.28,2.7,5.29,.68,metalMat,true);box(root,.20,.28,2.7,-5.29,.68,metalMat,true);
  // Panoramic windows, individual mullions and contrasting black window belt on both sides.
  for(const side of [-1,1]){
    box(root,9.86,.07,.075,0,1.90,side*1.305,frameMat,true);
    box(root,9.86,.07,.075,0,2.86,side*1.305,frameMat,true);
    const spans=[[-4.72,-4.05],[-3.80,-2.50],[-2.38,-1.94],[-.95,.32],[.43,1.78],[1.9,2.30],[3.42,4.70]];
    for(const [a,b] of spans){
      box(root,b-a,.90,.035,(a+b)/2,2.39,side*1.355,glassMat,true);
      for(const x of [a,b])box(root,.045,.98,.065,x,2.38,side*1.38,metalMat,true);
      box(root,.04,.90,.06,(a+b)/2,2.39,side*1.38,frameMat,true);
    }
    box(root,10.22,.11,.08,0,1.84,side*1.38,black,true);
    // Yellow belt stripe, route indicator and blue wheel-arch accents.
    box(root,10.15,.055,.04,0,1.43,side*1.34,yellowMat,true);
    box(root,.58,.27,.045,-.25,3.00,side*1.36,darkMat,true);
    const sideLed=plane(root,.56,.21,-.25,3.00,side*1.389,routeTex,side<0?Math.PI:0);
    sideLed.userData.static=true;
    for(const x of [-3.55,3.58])box(root,1.45,.10,.06,x,.80,side*1.335,blueTrim,true);
    // Large side mirrors with rigid arms on front corners.
    box(root,.65,.07,.07,4.70,2.15,side*1.42,metalMat,true);
    box(root,.12,.56,.10,4.40,2.17,side*1.46,frameMat,true);
    box(root,.22,.40,.16,4.68,2.33,side*1.55,black,true);
    box(root,.16,.30,.025,4.68,2.33,side*1.64,glassMat,true);
  }
  // Route-end pull-in/pull-out aprons let the bus turn without running beyond the existing main street.
  world.b(10,.055,6.2,-66,.02,11.5,0x4b4f55,{cast:false,receive:false});
  // Route 25 digital signs at the front and rear, readable from both directions.
  plane(root,1.72,.48,5.29,3.00,0,routeTex,Math.PI/2);
  plane(root,1.72,.42,-5.29,3.00,0,routeTex,-Math.PI/2);
  const rearExitTex=world.canvasTex(384,96,(ctx,w,h)=>{ctx.fillStyle='#132033';ctx.fillRect(0,0,w,h);ctx.fillStyle='#ffd34e';ctx.font='900 62px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('ÇIKIŞ  EXIT  →',w/2,h/2);});
  plane(root,.80,.22,-4.95,2.61,-1.385,rearExitTex,Math.PI);
  const frontEntryTex=world.canvasTex(384,96,(ctx,w,h)=>{ctx.fillStyle='#132033';ctx.fillRect(0,0,w,h);ctx.fillStyle='#ffd34e';ctx.font='900 62px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('GİRİŞ  ENTER  →',w/2,h/2);});
  plane(root,.80,.22,3.64,2.61,-1.385,frontEntryTex,Math.PI);
  // Windshield wipers, front badge plate, grille and rear registration.
  for(const z of [-.58,.58]){box(root,.05,.055,.80,5.31,1.85,z,black,true);box(root,.12,.30,.12,5.30,.48,z,metalMat,true);}
  box(root,.02,.40,.78,5.29,.76,0,darkMat,true);box(root,.04,.20,.60,5.315,.76,0,metalMat,true);
  for(const z of [-.95,.95]){
    box(root,.08,.38,.34,5.31,.85,z,lampWhite,true);box(root,.08,.12,.34,5.31,.60,z,lampAmber,true);
    box(root,.08,.54,.25,-5.29,1.00,z,lampRed,true);box(root,.08,.18,.25,-5.29,.55,z,lampWhite,true);
  }
  // Black wheel assemblies with animated hubs, both axles and visible arches.
  const wheelGroups=[];
  for(const x of [-3.55,3.58])for(const side of [-1,1]){
    box(root,1.62,.06,.08,x,.47,side*1.315,frameMat,true);
    const spin=new T.Group();spin.position.set(x,.53,side*1.28);root.add(spin);
    const tire=cyl(spin,.49,.23,0,0,0,rubberMat,'z',14);tire.rotation.x=Math.PI/2;
    const hub=cyl(spin,.28,.25,0,0,0,metalMat,'z',12);hub.rotation.x=Math.PI/2;
    const cap=cyl(spin,.11,.26,0,0,0,mat('hub-cap',0x6e7780),'z',10);cap.rotation.x=Math.PI/2;
    wheelGroups.push(spin);
  }
  // Low-floor passenger cabin, aisle, raised rear seating, yellow poles and handrails.
  box(root,9.95,.10,2.25,-.02,1.00,0,floorMat,true);
  box(root,3.1,.06,.72,-3.38,1.11,0,mat('rear-deck',0x555b61),true);
  for(const x of [-4.1,-3.0,-1.8,-.6,.6,1.55]){
    for(const side of [-1,1]){
      box(.76,.15,.62,x,1.18,side*.70,seatMat,true);
      box(.16,.74,.62,x-.29,1.48,side*.70,seatMat,true);
      box(.55,.045,.48,x,1.29,side*.70,mat('seat-accent',0x1b3b5e),true);
    }
  }
  for(const x of [-4.45,-3.0,-1.5,.2,1.75,2.40]){
    cyl(root,.045,1.68,x,2.02,.98,yellowMat,'y',8);
    cyl(root,.045,1.68,x,2.02,-.98,yellowMat,'y',8);
    box(.06,.045,1.98,x,2.80,0,yellowMat,true);
  }
  // Seat-back rails, stop request buttons and overhead interior lamps.
  for(const x of [-3.4,-1.1,1.1]){
    cyl(root,.025,2.0,x,2.74,0,yellowMat,'x',8);
    box(.10,.12,.10,x,2.35,-1.12,yellowMat,true);
    box(.10,.12,.10,x,2.35,1.12,yellowMat,true);
  }
  for(const x of [-3.2,-1.0,1.0,2.1]){
    box(.90,.035,.24,x,2.77,-.79,mat('interior-light',0xffedb0,{emissive:0x5b4e20}),true);box(.90,.035,.24,x,2.77,.79,mat('interior-light',0xffedb0,{emissive:0x5b4e20}),true);
  }
  // Driver's dashboard and an independently animated steering wheel.
  box(1.25,.24,1.65,4.08,1.42,.30,mat('dashboard',0x151e27),true);
  box(.60,.06,.58,4.22,1.60,.30,mat('dash-screen',0x1c3548,{emissive:0x0b202f}),true);
  box(.74,.14,.66,3.15,1.05,.35,seatMat,true);box(.18,.88,.67,2.86,1.42,.35,seatMat,true);
  box(.58,.045,.46,3.15,1.145,.35,mat('driver-seat-trim',0x152f4b),true);
  const steering=new T.Group();steering.position.set(3.82,1.78,.30);root.add(steering);
  const steeringRing=new T.Mesh(new T.TorusGeometry(.31,.035,7,16),metalMat);steeringRing.rotation.y=Math.PI/2;steering.add(steeringRing);
  // Fix steering spokes in its own rotating assembly.
  const spoke=new T.Mesh(world.geo('box'),metalMat);spoke.scale.set(.05,.05,.55);spoke.position.set(0,0,0);steering.add(spoke);
  cyl(steering,.08,.12,0,0,0,frameMat,'x',8);
  // Driver model remains fully articulated and sits behind the wheel.
  const driver=peopleApi ? peopleApi.buildHuman({shirt:0x152436,pants:0x121820,skin:peopleApi.SKINS[2],hair:peopleApi.HAIRS[1],scale:.94,face:{hairStyle:'short',brows:true}}) : null;
  if(driver){driver.group.position.set(3.23,.08,.37);driver.group.rotation.y=Math.PI/2;driver.armL.rotation.x=-1.15;driver.armR.rotation.x=-1.15;driver.elbowL.rotation.x=-.35;driver.elbowR.rotation.x=-.35;root.add(driver.group);}
  // Front passenger doors: two-leaf sliding assemblies on the curb side, with visible seals and handles.
  const doorSets=[];
  function createDoor(x, side){
    box(1.08,.10,.10,x,1.94,side*1.385,metalMat,true);box(1.08,.10,.10,x,.44,side*1.385,metalMat,true);
    const leaves=[];
    for(const sign of [-1,1]){
      const leaf=new T.Group();leaf.position.set(x+sign*.22,.46,side*1.395);root.add(leaf);
      box(leaf,.42,1.42,.045,0,.71,0,glassMat,false);
      box(leaf,.045,1.48,.065,0,.71,side*.028,frameMat,false);
      box(leaf,.38,.42,.055,0,.40,side*.04,bodyMat,false);
      box(leaf,.38,.04,.06,0,.65,side*.065,yellowMat,false);
      leaves.push({group:leaf,sign});
    }
    doorSets.push({x,side,leaves});
    box(.05,1.58,.07,x-.56,1.20,side*1.385,frameMat,true);box(.05,1.58,.07,x+.56,1.20,side*1.385,frameMat,true);
  }
  // Ring-road platforms are on the opposite curb; create usable doors on both sides.
  for(const side of [-1,1]) for(const x of [2.45,.15,-3.72]) createDoor(x,side);
  // Put door leaves into a dedicated interactive subassembly, not the mobile-friendly static mesh batch.
  // The doors facing the current platform open; the opposite side stays closed.
  world.mergeStatic(root);
  // Independent hit volume follows the front curb-side door; passengers see doors, not the invisible trigger.
  world.addInteractable({id:'city-bus-door',label:{
    get tr(){return bus.doorsOpen>.72?'25 hattına bin':'25 hattı otobüsü'},
    get en(){return bus.doorsOpen>.72?'Board route 25':'Route 25 bus'},
    get az(){return bus.doorsOpen>.72?'25 nömrəli avtobusa min':'25 nömrəli avtobus'},
    get ru(){return bus.doorsOpen>.72?'Сесть на автобус 25':'Автобус маршрута 25'}
  },box:[1.8,2.5,1.4,0,.15,0],action:()=>{if(bus.doorsOpen>.72)openRouteMap();}});
  const doorHit=world.hitboxes[world.hitboxes.length-1];
  const bus={group:root,driver,doors:doorSets,wheels:wheelGroups,steering,doorHit,routeSpeed:BUS.routeSpeed,speed:0,distance:0,nextStop:0,stoppedAt:-1,dwell:0,doorsOpen:0,doorTarget:0,frontBoardOnly:true,rearAlightOnly:true,publicBus:true,_nominal:BUS.routeSpeed,_hornWait:0,stops:[],route:[],routeLength:0,loopCount:0};
  // A full-size bus needs a wider turn than the stadium connector offers.
  // Use the main street and the existing outer ring rather than turn through buildings.
  bus.route=[
    [-64,10.05],[-52,10.05],[-8,10.05],[75,10.05],[142,10.05],
    [147,9.5],[150,7],[151.2,3],[151.2,-10],[151.2,-20],
    [150,-22.5],[147,-24.2],[-20,-24.2],[-80,-24.2],
    [-84,-23.2],[-86.2,-20],[-86.2,5],[-85,8],[-82,10.05],[-64,10.05]
  ];
  const stopDefs=[
    {point:[-52,10.05],name:{tr:'Batı Mahallesi',en:'West Neighborhood',az:'Qərb məhəlləsi',ru:'Западный район'},platform:{x:-52,z:7.95}},
    {point:[-8,10.05],name:{tr:'Market',en:'Market',az:'Market',ru:'Магазин'},platform:{x:-8,z:7.95}},
    {point:[75,10.05],name:{tr:'Doğu Bulvarı',en:'East Boulevard',az:'Şərq bulvarı',ru:'Восточный бульвар'},platform:{x:75,z:7.95}},
    {point:[151.2,-10],name:{tr:'Doğu Çevre Yolu',en:'East Ring Road',az:'Şərq dairəvi yolu',ru:'Восточная кольцевая'},platform:{x:154.6,z:-10},boardSide:1},
    {point:[-20,-24.2],name:{tr:'Kuzey Çevre Yolu',en:'North Ring Road',az:'Şimal dairəvi yolu',ru:'Северная кольцевая'},platform:{x:-20,z:-27.5},boardSide:1}
  ];
  const routeCum=[0];for(let i=1;i<bus.route.length;i++)routeCum[i]=routeCum[i-1]+Math.hypot(bus.route[i][0]-bus.route[i-1][0],bus.route[i][1]-bus.route[i-1][1]);
  bus.routeLength=routeCum[routeCum.length-1];
  bus.stops=stopDefs.map((stop,id)=>{const index=bus.route.findIndex(p=>Math.abs(p[0]-stop.point[0])<.001&&Math.abs(p[1]-stop.point[1])<.001);if(index<0)throw new Error('Route 25 stop is missing from route geometry');return{...stop,id,index,distance:routeCum[index]};});
  function routePoint(distance){
    let d=((distance%bus.routeLength)+bus.routeLength)%bus.routeLength;
    const pts=bus.route.concat([bus.route[0]]);
    for(let i=1;i<pts.length;i++){
      const a=pts[i-1],b=pts[i],len=Math.hypot(b[0]-a[0],b[1]-a[1]);
      if(d<=len){const t=len>0?d/len:0;return{x:a[0]+(b[0]-a[0])*t,z:a[1]+(b[1]-a[1])*t,yaw:-Math.atan2(b[1]-a[1],b[0]-a[0])};}
      d-=len;
    }
    return{x:bus.route[0][0],z:bus.route[0][1],yaw:0};
  }
  function localToWorld(lx,lz,ly=0){
    const p=root.position,yaw=root.rotation.y,c=Math.cos(yaw),s=Math.sin(yaw);
    return{x:p.x+lx*c+lz*s,y:ly,z:p.z-lx*s+lz*c};
  }
  function worldToLocal(x,z){
    const dx=x-root.position.x,dz=z-root.position.z,yaw=root.rotation.y,c=Math.cos(yaw),s=Math.sin(yaw);
    return{x:dx*c-dz*s,z:dx*s+dz*c};
  }
  function syncCollider(){
    Object.assign(bus.collider,traffic.bounds(root.position.x,root.position.z,root.rotation.y,BUS.halfLength,BUS.halfWidth),{vehicleOwner:bus,trafficBody:true,publicBus:true});
  }
  bus.collider={minX:0,maxX:0,minZ:0,maxZ:0,vehicleOwner:bus,trafficBody:true,publicBus:true};
  // Ensure the bus does not spawn inside existing traffic: advance along its lane in modest increments if needed.
  for(let tryIndex=0;tryIndex<16;tryIndex++){
    const p=routePoint(bus.distance);
    if(traffic.canSpawnAt(p.x,p.z,p.yaw,bus,BUS.halfLength,BUS.halfWidth))break;
    bus.distance+=8;
  }
  {const p=routePoint(bus.distance);root.position.set(p.x,0,p.z);root.rotation.y=p.yaw;syncCollider();}
  world.colliders.push(bus.collider);
  {const p=localToWorld(2.45,-1.55,1.1);doorHit.position.set(p.x,p.y,p.z);doorHit.rotation.y=root.rotation.y;}
  const doorPlatform=(stop)=>stop.platform;
  function buildStop(stop){
    const x=stop.platform.x,z=stop.platform.z;
    const dx=stop.point[0]-x,dz=stop.point[1]-z;
    const yaw=Math.atan2(-dx,-dz); // local front is -Z and must face the road
    const vertical=Math.abs(dx)>Math.abs(dz);
    world.b(vertical?1.95:3.8,.10,vertical?3.8:1.95,x,0,z,0x9da19d,{cast:false,receive:false}); // .10: kaldırım (.07) ile aynı düzlemde titremesin
    regions.push({minX:x-(vertical?1.25:2.25),maxX:x+(vertical?1.25:2.25),minZ:z-(vertical?2.25:1.25),maxZ:z+(vertical?2.25:1.25)});
    const shelter=new T.Group();shelter.position.set(x,0,z);shelter.rotation.y=yaw;world.scene.add(shelter);
    const put=(sx,sy,sz,px,py,pz,color)=>{const m=world.b(sx,sy,sz,px,py,pz,color,{parent:shelter,cast:false,receive:false});m.userData.static=true;return m;};
    put(2.75,.14,1.0,0,2.42,0,0x273743);put(2.65,.08,.90,0,1.56,0,0x718b94);
    for(const px of [-1.25,1.25]){put(.09,2.35,.09,px,.02,0,0x34434c);put(.06,2.05,.05,px,.14,-.42,0x8aabb6);}
    put(1.85,.12,.46,0,.50,.25,0x625444);put(1.85,.4,.12,0,.61,.49,0x625444);
    const tex=world.canvasTex(256,128,(ctx,w,h)=>{ctx.fillStyle='#183f72';ctx.fillRect(0,0,w,h);ctx.fillStyle='#fff';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='900 40px Arial';ctx.fillText('BUS 25',w/2,39);ctx.font='700 22px Arial';ctx.fillText('CITY',w/2,83);});
    const sign=new T.Mesh(world.geo('plane'),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));sign.scale.set(1.15,.58,1);sign.position.set(1.20,2.08,-.48);sign.rotation.y=Math.PI/2;sign.castShadow=false;shelter.add(sign);
    put(.08,2.2,.08,-1.8,.02,-.20,0x3a4850);put(.68,.44,.10,-1.8,1.45,-.20,0x12613e);
    world.mergeStatic(shelter);
    stop.shelterYaw=yaw;
  }
  for(const stop of bus.stops)buildStop(stop);
  window.__cityBusMap=bus.stops.map(stop=>({x0:stop.platform.x-.9,x1:stop.platform.x+.9,z0:stop.platform.z-.7,z1:stop.platform.z+.7,c:'#1d5e9b',l:stop.name.tr,e:'🚌'}));
  // Driver and riders are original in-game NPCs, not copied from the concept-art brand markings.
  const passengers=[];
  const skins=peopleApi?.SKINS||[0xe0ac69,0x8d5524,0xf1c27d,0xffdbac];
  const outfits=[
    {shirt:0x6e83a0,pants:0x252b35,hair:0x30231d}, {shirt:0x8a5c48,pants:0x303b51,hair:0x5a3825},
    {shirt:0x39746c,pants:0x262a30,hair:0x1b1b1b}, {shirt:0xb58d48,pants:0x3d3c4b,hair:0x70482b},
    {shirt:0x773c4b,pants:0x2d3640,hair:0x31221e}, {shirt:0x5485a2,pants:0x38343a,hair:0xc1a16a},
    {shirt:0x9e765b,pants:0x1f3044,hair:0x25211f}, {shirt:0x6a6d83,pants:0x504236,hair:0x5b3d2d}
  ];
  const passengerPlan=[
    [0,2], [0,3], [1,4], [1,3], [2,4], [2,0], [3,1], [4,2]
  ];
  const seatList=[[-3.45,-.59],[-3.45,.59],[-2.05,-.59],[-2.05,.59],[-.65,-.59],[-.65,.59],[.75,-.59],[.75,.59]];
  for(let i=0;i<passengerPlan.length;i++){
    const [origin,target]=passengerPlan[i],look=outfits[i];
    const actor=peopleApi?.buildHuman({female:i%2===0,slim:true,shirt:look.shirt,pants:look.pants,hair:look.hair,skin:skins[i%skins.length],shoes:0x202329,scale:.91,face:{hairStyle:i%3===0?'longFringe':'short',blush:i%2===0},lod:true});
    if(!actor)continue;
    actor.group.scale.setScalar(actor.group.scale.x*.78);if(actor.lowGroup)actor.lowGroup.scale.setScalar(actor.lowGroup.scale.x*.78);
    const stop=bus.stops[origin],wait={x:stop.platform.x+(i%3-1)*.48,z:stop.platform.z+(i%2)*.46};
    actor.group.position.set(wait.x,0,wait.z);world.root.add(actor.group);
    if(actor.lowGroup){actor.lowGroup.position.set(wait.x,0,wait.z);world.root.add(actor.lowGroup);actor.lowGroup.visible=false;}
    passengers.push({id:'p'+i,actor,origin,target,state:'waiting',wait,seat:null,elapsed:0,exitWorld:null,travelTarget:target});
  }
  bus.passengers=passengers;
  function setVisual(actor,x,y,z,yaw,visible=true){actor.group.position.set(x,y,z);actor.group.rotation.y=yaw;actor.group.visible=visible;if(actor.lowGroup){actor.lowGroup.position.set(x,y,z);actor.lowGroup.rotation.y=yaw;actor.lowGroup.visible=false;}}
  function activeSide(){return bus.stoppedAt>=0 ? (bus.stops[bus.stoppedAt].boardSide||-1) : -1;}
  function nearActiveDoor(loc){const side=activeSide();return Math.abs(loc.x)<=4.6 && loc.z*side>0 && Math.abs(loc.z-side*1.55)<=2.25;}
  function busDoorWorld(){return localToWorld(2.45,activeSide()*1.55,0);}
  function rearDoorWorld(){return localToWorld(-3.72,activeSide()*1.55,0);}
  function beginStop(index){
    bus.stoppedAt=index;bus.dwell=BUS.dwellSeconds;bus.extraDwell=0;bus.speed=0;bus.doorTarget=1;bus.stopEvents=(bus.stopEvents||0)+1;
    const stop=bus.stops[index],door=busDoorWorld();
    for(const rider of passengers){
      if(rider.state==='riding'&&rider.target===index){rider.state='standing';rider.exitStop=index;rider.elapsed=0;}
    }
    bus.playerMayBoard=true;
    bus.doorHit.position.set(door.x,1.1,door.z);
  }
  function updatePassengers(dt){
    const stopIndex=bus.stoppedAt,door=busDoorWorld();
    if(game.playerAboard&&stopIndex>=0&&bus.doorsOpen>.72&&
       (bus.exitRequested || bus.playerDestination===stopIndex)){bus.exitRequested=false;exitPlayer();}
    for(const rider of passengers){
      if(rider.state==='standing'){
        rider.elapsed+=dt;const t=Math.min(1,rider.elapsed/.65);
        rider.actor.legL.rotation.x=-.95*(1-t);rider.actor.legR.rotation.x=-.95*(1-t);
        rider.actor.armL.rotation.x=-.40*(1-t);rider.actor.armR.rotation.x=-.40*(1-t);
        if(t>=1)rider.state='exitPending';
      }
      if(rider.state==='exitPending'&&bus.doorsOpen>.72){
        const stop=bus.stops[rider.exitStop];
        root.remove(rider.actor.group);world.root.add(rider.actor.group);
        if(rider.actor.lowGroup){root.remove(rider.actor.lowGroup);world.root.add(rider.actor.lowGroup);}
        const p=rearDoorWorld();bus.lastNpcExitDoor={x:p.x,z:p.z};
        setVisual(rider.actor,p.x,0,p.z,root.rotation.y,true);
        rider.state='exiting';const exit=rearDoorWorld();rider.exitWorld={x:exit.x,z:exit.z};rider.platform={x:stop.platform.x,z:stop.platform.z};rider.elapsed=0;
        bus.alightedTotal=(bus.alightedTotal||0)+1;
      }
      if(rider.state==='cooldown'){
        rider.elapsed-=dt;
        if(rider.elapsed<=0){const s=bus.stops[rider.origin],q=s.platform;rider.wait={x:q.x+(rider.id.charCodeAt(1)%3-1)*.42,z:q.z+.25};setVisual(rider.actor,rider.wait.x,0,rider.wait.z,0,true);rider.state='waiting';}
      } else if(rider.state==='waiting'){
        rider.actor.walk(dt,0);
        if(stopIndex===rider.origin&&bus.doorsOpen>.78){
          const reserved=new Set(passengers.filter(p=>p!==rider&&(p.state==='boarding'||p.state==='riding')).map(p=>p.seat?.join(',')));
          rider.seat=seatList.find(seat=>!reserved.has(seat.join(',')))||null;
          if(rider.seat){rider.state='boarding';rider.elapsed=0;rider.boardDoor=door;bus.lastNpcEntryDoor={x:door.x,z:door.z};}
        }
      } else if(rider.state==='boarding'){
        rider.elapsed+=dt;
        const p=rider.actor.group.position,dx=door.x-p.x,dz=door.z-p.z,d=Math.hypot(dx,dz),step=Math.min(d,1.45*dt);
        if(d>.14){p.x+=dx/d*step;p.z+=dz/d*step;rider.actor.group.rotation.y=Math.atan2(dx,dz);rider.actor.walk(dt,.65);}
        if(d<=.20||rider.elapsed>3.6){
          world.root.remove(rider.actor.group);root.add(rider.actor.group);
          if(rider.actor.lowGroup){world.root.remove(rider.actor.lowGroup);root.add(rider.actor.lowGroup);}
          const local=worldToLocal(door.x,door.z);
          rider.actor.group.position.set(local.x,0,local.z);rider.actor.group.rotation.y=Math.PI/2;
          rider.actor.group.visible=true;rider.state='entering';rider.elapsed=0;rider.aislePoint={x:1.28,z:-.68};rider.actor.walk(dt,.55);
        }
      } else if(rider.state==='entering'){
        const p=rider.actor.group.position,target=rider.aislePoint,dx=target.x-p.x,dz=target.z-p.z,d=Math.hypot(dx,dz),step=Math.min(d,1.15*dt);
        if(d>.12){p.x+=dx/d*step;p.z+=dz/d*step;rider.actor.group.rotation.y=Math.atan2(dx,dz);rider.actor.walk(dt,.5);}
        else {rider.state='walkingToSeat';rider.elapsed=0;}
      } else if(rider.state==='walkingToSeat'){
        const p=rider.actor.group.position,[sx,sz]=rider.seat,dx=sx-p.x,dz=sz-p.z,d=Math.hypot(dx,dz),step=Math.min(d,1.0*dt);
        if(d>.12){p.x+=dx/d*step;p.z+=dz/d*step;rider.actor.group.rotation.y=Math.atan2(dx,dz);rider.actor.walk(dt,.45);}
        else {p.set(sx,.14,sz);rider.actor.legL.rotation.x=rider.actor.legR.rotation.x=-.95;rider.actor.armL.rotation.x=rider.actor.armR.rotation.x=-.40;rider.actor.walk(dt,0);rider.state='riding';rider.elapsed=0;bus.boardedTotal=(bus.boardedTotal||0)+1;}
      } else if(rider.state==='riding'){
        rider.actor.walk(dt,0);
        rider.actor.group.position.set(rider.seat[0],.14,rider.seat[1]);
      } else if(rider.state==='exiting'){
        const p=rider.actor.group.position,target=rider.exitWorld,dx=target.x-p.x,dz=target.z-p.z,d=Math.hypot(dx,dz),step=Math.min(d,1.5*dt);
        if(d>.15){p.x+=dx/d*step;p.z+=dz/d*step;rider.actor.group.rotation.y=Math.atan2(dx,dz);rider.actor.walk(dt,.7);}
        else {rider.state='exitWalk';rider.actor.group.position.set(target.x,0,target.z);}
      } else if(rider.state==='exitWalk'){
        const p=rider.actor.group.position,target=rider.platform,dx=target.x-p.x,dz=target.z-p.z,d=Math.hypot(dx,dz),step=Math.min(d,1.5*dt);
        if(d>.18){p.x+=dx/d*step;p.z+=dz/d*step;rider.actor.group.rotation.y=Math.atan2(dx,dz);rider.actor.walk(dt,.65);}
        else{
          rider.state='cooldown';rider.elapsed=28;rider.origin=(stopIndex+1)%bus.stops.length;rider.target=(rider.origin+2)%bus.stops.length;
          rider.wait={...bus.stops[rider.origin].platform};rider.actor.group.visible=false;
        }
      }
    }
  }
  function updateDoors(dt){
    const target=bus.doorTarget;bus.doorsOpen+=(target-bus.doorsOpen)*(1-Math.exp(-dt*4.8));
    if(Math.abs(target-bus.doorsOpen)<.008)bus.doorsOpen=target;
    for(const door of doorSets)for(const leaf of door.leaves)leaf.group.position.x=door.x+leaf.sign*(.22+(door.side===activeSide()?bus.doorsOpen:0)*.34);
  }
  function nextStopDistance(){
    let d=bus.stops[bus.nextStop].distance;
    while(d<bus.distance-.0001)d+=bus.routeLength;
    return d;
  }
  function updateBus(dt,playing){
    updateDoors(dt);
    const door=busDoorWorld();bus.doorHit.position.set(door.x,1.15,door.z);bus.doorHit.rotation.y=root.rotation.y;
    if(!playing)return;
    if(bus.dwell>0){
      if(bus.mapOpen) bus.dwell=Math.max(bus.dwell,2);
      else bus.dwell=Math.max(0,bus.dwell-dt);
      updatePassengers(dt);
      // Never leave while a passenger is boarding or exiting, but cap the
      // extension so a broken animation can never block the entire route.
      const inTransition=passengers.some(p=>['boarding','entering','walkingToSeat','standing','exitPending','exiting','exitWalk'].includes(p.state));
      if(bus.dwell===0 && inTransition && (bus.extraDwell||0)<12){bus.extraDwell=(bus.extraDwell||0)+dt;bus.dwell=.001;}
      if(bus.dwell===0){bus.stoppedAt=-1;bus.doorTarget=0;bus.playerMayBoard=false;bus.nextStop=(bus.nextStop+1)%bus.stops.length;}
      return;
    }
    bus.doorTarget=0;
    const targetDist=nextStopDistance(),distLeft=targetDist-bus.distance;
    // Braking against distLeft-.20 stops the bus 20 cm short forever, so the
    // stop event never fires. Brake to the actual target instead.
    const desired=Math.min(BUS.routeSpeed,Math.sqrt(Math.max(0,2*2.4*distLeft)));
    bus.speed+=Math.max(-BUS.accel*dt,Math.min(BUS.accel*dt,desired-bus.speed));
    const delta=Math.min(distLeft,bus.speed*dt),stoppingNow=delta>=distLeft-.0001,candidateDistance=bus.distance+delta,p=routePoint(candidateDistance);
    if(delta>.0001&&traffic.canMoveVehicle&&!traffic.canMoveVehicle(bus,p.x,p.z,p.yaw,dt,BUS.halfLength,BUS.halfWidth)){
      // Keep a modest retry speed. Resetting to zero each blocked frame made
      // the bus advance only millimetres as a lead vehicle pulled away.
      bus.speed=Math.min(bus.speed,3);return;
    }
    bus.distance=candidateDistance;root.position.set(p.x,0,p.z);root.rotation.y=p.yaw;
    for(const wheel of wheelGroups)wheel.rotation.z-=delta/.49;
    const yawDelta=bus.lastYaw===undefined?0:Math.atan2(Math.sin(p.yaw-bus.lastYaw),Math.cos(p.yaw-bus.lastYaw));
    steering.rotation.x=Math.max(-.18,Math.min(.18,yawDelta*2.4));bus.lastYaw=p.yaw;
    if(driver)driver.walk(dt,bus.speed>1?.08:0);
    syncCollider();
    if(stoppingNow){bus.distance=targetDist;const fixed=routePoint(bus.distance);root.position.set(fixed.x,0,fixed.z);root.rotation.y=fixed.yaw;syncCollider();beginStop(bus.nextStop);}
    updatePassengers(dt);
  }
  function boardPlayer(destination){
    if(bus.doorsOpen<.72||game.playerAboard)return false;
    const loc=worldToLocal(game.player.pos.x,game.player.pos.z);
    if(!nearActiveDoor(loc))return false;
    if(!Number.isInteger(destination)||destination<0||destination>=bus.stops.length||destination===bus.stoppedAt)return false;
    bus.playerDestination=destination;
    game.playerAboard=true;bus.playerSeated=true;bus.playerSeat={x:2.05,z:-.15};bus.playerLookOffset=0;game.player.speed01=0;
    game.fpsCam.eyeHeight=1.44;game.fpsCam.setAngles(root.rotation.y-Math.PI/2,0);
    syncPlayer();game.ui.toast({tr:'Hedef: '+bus.stops[destination].name.tr,en:'Destination: '+bus.stops[destination].name.en,az:'Hədəf: '+bus.stops[destination].name.az,ru:'Пункт назначения: '+bus.stops[destination].name.ru});
    return true;
  }
  function syncPlayer(){
    if(!game.playerAboard)return;
    const p=localToWorld(bus.playerSeat?.x??2.05,bus.playerSeat?.z??-.15,0);
    game.player.pos.x=p.x;game.player.pos.z=p.z;game.player.vel.x=0;game.player.vel.z=0;
  }
  function exitPlayer(){
    if(!game.playerAboard)return false;
    const p=localToWorld(-3.72,activeSide()*1.93,0);bus.lastPlayerExit={x:p.x,z:p.z};
    game.playerAboard=false;bus.playerSeated=true;bus.exitRequested=false;bus.playerDestination=null;game.player.setPosition(p.x,p.z);game.fpsCam.eyeHeight=1.62;game.fpsCam.setAngles(root.rotation.y-Math.PI/2+(bus.playerLookOffset||0),0);
    game.ui.toast({tr:'Otobüsten indin.',en:'You got off the bus.',az:'Avtobusdan düşdün.',ru:'Вы вышли из автобуса.'});
    return true;
  }
  function togglePlayerSeat(){
    if(!game.playerAboard)return false;
    bus.playerSeated=!bus.playerSeated;
    bus.playerSeat=bus.playerSeated?{x:2.05,z:-.15}:{x:1.0,z:0};
    game.fpsCam.eyeHeight=bus.playerSeated?1.44:2.15;
    syncPlayer();
    game.ui.toast(bus.playerSeated
      ?{tr:'Yolcu koltuğuna oturdun.',en:'You sat in a passenger seat.',az:'Sərnişin oturacağına əyləşdin.',ru:'Вы сели на пассажирское место.'}
      :{tr:'Ayağa kalktın. İstersen düğmeyle yeniden oturabilirsin.',en:'You stood up. Tap the button again to sit.',az:'Ayağa qalxdın. Oturmaq üçün düyməyə yenidən toxun.',ru:'Вы встали. Нажмите ещё раз, чтобы сесть.'});
    return true;
  }
  function requestExit(){
    bus.exitRequested=true;
    if(bus.stoppedAt>=0&&bus.doorsOpen>.72){bus.exitRequested=false;return exitPlayer();}
    game.ui.toast({tr:'İniş isteğin alındı, sonraki durakta arka kapıdan inebilirsin.',en:'Stop requested. Exit through the rear door at the next stop.',az:'Düşmə istəyin qəbul olundu, növbəti dayanacaqda arxa qapıdan düşə bilərsən.',ru:'Остановка запрошена. На следующей остановке выходите через заднюю дверь.'});
    return true;
  }
  // A route map with accessible buttons. The bus waits while the map is open.
  let routePanel=null;
  function closeRouteMap(){
    if(routePanel)routePanel.classList.remove('open');
    bus.mapOpen=false;
    game.setInputLocked(false);
  }
  function openRouteMap(){
    if(bus.stoppedAt<0||bus.doorsOpen<.72||game.playerAboard)return false;
    const loc=worldToLocal(game.player.pos.x,game.player.pos.z);
    if(!nearActiveDoor(loc))return false;
    if(!routePanel){
      const css=document.createElement('style');
      css.textContent='#bus-route-ui{position:fixed;inset:0;z-index:150;display:none;align-items:center;justify-content:center;padding:16px;background:#091b2bcc;color:#f6fbff;font:16px system-ui}#bus-route-ui.open{display:flex}#bus-route-ui .bus-panel{width:min(620px,96vw);max-height:90vh;overflow:auto;background:#102d40;border:2px solid #67d6c2;border-radius:18px;padding:20px;box-shadow:0 18px 55px #0008}#bus-route-ui h2{margin:0 0 6px;font-size:24px}#bus-route-ui p{margin:0 0 12px;color:#c7e1e5}#bus-route-ui svg{display:block;width:100%;height:155px;background:#1a4853;border-radius:12px;margin-bottom:12px}#bus-route-ui .bus-choices{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px}#bus-route-ui button{min-height:48px;border:0;border-radius:9px;padding:10px 12px;background:#f4d174;color:#142b32;font:700 15px system-ui;text-align:left;cursor:pointer}#bus-route-ui button:disabled{background:#41636a;color:#d2e2e1}#bus-route-ui .bus-close{margin-top:12px;background:#dbe7e8}';
      document.head.appendChild(css);
      routePanel=document.createElement('div');routePanel.id='bus-route-ui';
      routePanel.innerHTML='<section class="bus-panel" role="dialog" aria-modal="true" aria-labelledby="bus-title"><h2 id="bus-title"></h2><p></p><svg viewBox="0 0 480 155" role="img" aria-label="25"><path d="M40 125 L160 125 L270 77 L410 28 L315 135 Z" fill="none" stroke="#73d9c3" stroke-width="5" stroke-linejoin="round"></path><g class="bus-points"></g></svg><div class="bus-choices"></div><button class="bus-close" type="button"></button></section>';
      document.body.appendChild(routePanel);
      for(const ev of ['pointerdown','touchstart','mousedown','click'])routePanel.addEventListener(ev,e=>e.stopPropagation());
      routePanel.addEventListener('click',e=>{if(e.target===routePanel)closeRouteMap();});
      routePanel.querySelector('.bus-close').addEventListener('click',closeRouteMap);
      window.addEventListener('keydown',e=>{if(e.key==='Escape'&&bus.mapOpen){e.stopImmediatePropagation();closeRouteMap();}},true);
    }
    const lang=['tr','en','az','ru'].includes(game.ui.lang)?game.ui.lang:'tr';
    const labels={tr:['25 Hattı · Nereye gidiyorsun?','Bir durak seç. Otobüs seni oraya götürür.','Bulunduğun durak','Vazgeç'],en:['Route 25 · Where to?','Choose a stop. The bus will take you there.','Current stop','Cancel'],az:['25 xətti · Hara gedirsən?','Dayanacaq seç. Avtobus səni ora aparacaq.','Cari dayanacaq','Ləğv et'],ru:['Маршрут 25 · Куда едем?','Выберите остановку. Автобус отвезёт вас туда.','Текущая остановка','Отмена']}[lang];
    routePanel.querySelector('h2').textContent=labels[0];
    routePanel.querySelector('p').textContent=labels[1];
    routePanel.querySelector('.bus-close').textContent=labels[3];
    const points=bus.stops.map((stop,i)=>{const a=2*Math.PI*i/bus.stops.length-Math.PI/2;return [240+190*Math.cos(a),78+55*Math.sin(a)];});
    routePanel.querySelector('svg path').setAttribute('d',points.map(([x,y],i)=>(i?'L':'M')+x+' '+y).join(' ')+' Z');
    routePanel.querySelector('.bus-points').innerHTML=points.map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="8" fill="${i===bus.stoppedAt?'#ffe08a':'#fff'}"/><text x="${x+10}" y="${y-11}" fill="#fff" font-size="13" font-family="system-ui">${i+1}</text>`).join('');
    const choices=routePanel.querySelector('.bus-choices');choices.replaceChildren();
    bus.stops.forEach((stop,i)=>{
      const button=document.createElement('button');button.type='button';
      button.textContent=(i+1)+'. '+stop.name[lang]+(i===bus.stoppedAt?' · '+labels[2]:'');
      button.disabled=i===bus.stoppedAt;
      button.addEventListener('click',()=>{if(boardPlayer(i))closeRouteMap();});
      choices.appendChild(button);
    });
    bus.mapOpen=true;game.setInputLocked(true);routePanel.classList.add('open');
    return true;
  }
  const origPlayerUpdate=game.player.update.bind(game.player);
  game.player.update=function(dt,...args){if(game.playerAboard){syncPlayer();this.speed01=0;return;}return origPlayerUpdate(dt,...args);};
  const origCameraUpdate=game.fpsCam.update.bind(game.fpsCam);
  game.fpsCam.update=function(dt,pos,speed){
    if(game.playerAboard){
      syncPlayer();const base=root.rotation.y-Math.PI/2;this.yaw=base+(bus.playerLookOffset||0);
      const result=origCameraUpdate(dt,game.player.pos,0);
      bus.playerLookOffset=Math.atan2(Math.sin(this.yaw-base),Math.cos(this.yaw-base));return result;
    }
    return origCameraUpdate(dt,game.player.pos,speed);
  };
  const origAction=game.currentAction.bind(game);
  game.currentAction=function(){
    if(game.playerAboard)return{
      key:'city-bus-request-stop',
      label:{tr:bus.exitRequested?'İniş isteği verildi':'Sonraki durakta arka kapıdan in',en:bus.exitRequested?'Stop requested':'Exit at next stop',az:bus.exitRequested?'Düşmə istəyi verildi':'Növbəti dayanacaqda düş',ru:bus.exitRequested?'Остановка запрошена':'Выйти на следующей остановке'},run:requestExit,
      label2:bus.playerSeated?{tr:'Ayağa kalk',en:'Stand up',az:'Ayağa qalx',ru:'Встать'}:{tr:'Otur',en:'Sit down',az:'Əyləş',ru:'Сесть'},icon2:bus.playerSeated?'🧍':'💺',run2:togglePlayerSeat
    };
    const cur=game.interaction.current;
    if(cur&&cur.id==='city-bus-door')return{key:bus.doorsOpen>.72?'board-city-bus':'wait-city-bus',label:bus.doorsOpen>.72?{tr:'🚌 Gidilecek durağı seç',en:'🚌 Choose a destination',az:'🚌 Dayanacaq seç',ru:'🚌 Выбрать остановку'}:{tr:'25 hattı durakta bekliyor',en:'Route 25 is at the stop',az:'25 nömrəli avtobus dayanacaqda',ru:'Автобус 25 на остановке'},run:()=>{if(bus.doorsOpen>.72)openRouteMap();else game.ui.toast({tr:'Otobüs durakta değil.',en:'The bus is not stopped.',az:'Avtobus dayanacaqda deyil.',ru:'Автобус не на остановке.'});}};
    return origAction();
  };
  const origMenu=game.toMenu.bind(game);
  game.toMenu=function(){if(bus.mapOpen)closeRouteMap();if(game.playerAboard)exitPlayer();return origMenu();};
  const origSave=game.saveNow.bind(game);
  game.saveNow=function(){if(!game.playerAboard)return origSave();const px=game.player.pos.x,pz=game.player.pos.z,p=bus.stops[Math.max(0,bus.stoppedAt)].platform;game.player.pos.x=p.x;game.player.pos.z=p.z;const r=origSave();game.player.pos.x=px;game.player.pos.z=pz;return r;};
  const oldUpdate=world.update.bind(world);
  world.update=function(dt,pos,playing){const result=oldUpdate(dt,pos,playing);updateBus(dt,!!playing&&game.state==='playing');return result;};
  window.__cityBus={bus,stops:bus.stops,route:bus.route,boardPlayer,openRouteMap,requestExit,exitPlayer,togglePlayerSeat,inspect:()=>({speed:bus.speed,position:{x:root.position.x,z:root.position.z},distance:bus.distance,routeLength:bus.routeLength,stopCount:bus.stops.length,nextStop:bus.nextStop,playerSeated:!!bus.playerSeated,stoppedAt:bus.stoppedAt,doorsOpen:bus.doorsOpen,stopEvents:bus.stopEvents||0,passengers:passengers.map(p=>({id:p.id,state:p.state,origin:p.origin,target:p.target})),lastNpcEntryDoor:bus.lastNpcEntryDoor,lastNpcExitDoor:bus.lastNpcExitDoor,lastPlayerExit:bus.lastPlayerExit,boarded:bus.boardedTotal||0,alighted:bus.alightedTotal||0,playerAboard:!!game.playerAboard}),pointAt:routePoint};
})();
