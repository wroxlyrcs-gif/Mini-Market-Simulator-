/* Mini Market Simulator v2.8: persistent construction, furnishing and stair animation.
   Existing market inventory, money and save key remain the source of truth. */
(function () {
  'use strict';
  let g = window.__mms;
  if (!g || !window.THREE || typeof __req !== 'function') return;
  const T = window.THREE;
  const { Save } = __req('save');
  const { FIXTURES } = __req('fixtures');
  const { effectsFor, backDepth } = __req('expand');
  const { SiteUI } = __req('site');
  const { DepotSystem } = __req('depot');
  const { findPath } = __req('pathing');
  const L = (key,vars) => window.MMS_BUILD_TRANSLATIONS.t(g.ui.lang,key,vars);
  const names = id => Object.fromEntries(['tr','en','az','ru'].map(lang=>[lang,window.MMS_BUILD_TRANSLATIONS.t(lang,id)]));
  const CATALOG = {
    shelf:  { name: 'Ürün rafı', icon: '🗄️', price: 180, w: 1.6, d: 0.7, cap: 48, color: '#d58b39' },
    fridge: { name: 'Buzdolabı', icon: '🧊', price: 320, w: 1.1, d: 0.8, cap: 36, color: '#78a8ce' },
    till:   { name: 'Kasa', icon: '🧾', price: 250, w: 1.4, d: 0.8, color: '#d76658' },
    table:  { name: 'Masa', icon: '🪑', price: 120, w: 1.4, d: 0.9, color: '#ad774d' },
    decor:  { name: 'Dekorasyon / bitki', icon: '🪴', price: 65, w: 0.65, d: 0.65, color: '#53a569' }
  };
  const FLOOR_PRICE = 3500;
  const KEY = 'mms_save_v1';
  const ground = { minX: -6.7, maxX: 6.7, minZ: -4.7, maxZ: 4.7 };
  let feature;
  const REAR_WINDOW_MAT = MMS_NIGHT.reg(new T.MeshLambertMaterial({ color: 0x4b504d, emissive: 0xffc46b, emissiveIntensity: 0 }));

  const fixtureSets = new Map();
  const fixedFixtures = FIXTURES.filter(f => !f.manualOnly);
  function clean(raw) {
    const b = raw && typeof raw === 'object' ? raw : {};
    const seen = new Set();
    const items = [];
    for (const a of Array.isArray(b.items) ? b.items.slice(0, 100) : []) {
      if (!a || !CATALOG[a.type] || !/^(?:build|m2_build)_[0-9]{1,10}$/.test(a.id) || seen.has(a.id)) continue;
      seen.add(a.id);
      const placed = Number.isFinite(a.x) && Number.isFinite(a.z);
      items.push({ id: a.id, type: a.type, x: placed ? a.x : null, z: placed ? a.z : null,
        floor: a.floor === 1 ? 1 : 0, rot: Math.abs(Math.floor(Number(a.rot) || 0)) % 4 });
    }
    return { upper: b.upper === true, items, seq: Math.max(1, ...items.map(a => Number(a.id.slice(a.id.lastIndexOf('_') + 1)) + 1)) };
  }
  function syncFixtures(build, upgrades, owner = 'main') {
    const mult = effectsFor(upgrades || []).mult;
    const own = [];
    for (const a of build.items) {
      const c = CATALOG[a.type];
      if (a.x === null || !c.cap) continue;
      own.push({ id: a.id, type: a.type, baseCap: c.cap, cap: Math.round(c.cap * mult),
        manualOnly: true, name: names(a.type) });
    }
    fixtureSets.set(owner, own);
    FIXTURES.splice(0, FIXTURES.length, ...fixedFixtures, ...[...fixtureSets.values()].flat());
  }
  window.__MMS_REGISTER_MARKET_FIXTURES = function (fixtures) {
    for (const f of fixtures || []) if (f && f.id && !FIXTURES.some(x => x.id === f.id)) fixedFixtures.push(f);
    FIXTURES.splice(0, FIXTURES.length, ...fixedFixtures, ...[...fixtureSets.values()].flat());
  };
  // Reconstruct dynamic fixtures before the original sanitizer reads shelf stock.
  const oldLoad = Save.load.bind(Save);
  Save.load = function () {
    let raw = {};
    try { raw = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (_) {}
    const build = clean(raw.marketBuild);
    syncFixtures(build, raw.upgrades, 'main');
    const data = oldLoad();
    data.marketBuild = build;
    return data;
  };
  const oldNew = Save.createNew.bind(Save);
  Save.createNew = function () {
    syncFixtures(clean(null), [], 'main');
    const data = oldNew();
    data.marketBuild = clean(null);
    return data;
  };
  const oldWrite = Save.write.bind(Save);
  Save.write = function (data) {
    // Automatic saves must not commit an unfinished drag or defeat Cancel.
    if (feature && feature.data === data && feature.snapshot && feature.editor.classList.contains('open')) {
      return oldWrite({ ...data, marketBuild: JSON.parse(feature.snapshot) });
    }
    return oldWrite(data);
  };
  const oldResolve = DepotSystem.prototype.resolveAction;
  DepotSystem.prototype.resolveAction = function (cur) {
    const ownFeature = this.marketBuild || feature;
    if (cur && /^(?:build|m2_build)_[0-9]+$/.test(cur.id) && ownFeature && ownFeature.data && !this.carriedId) {
      const a = ownFeature.data.marketBuild.items.find(x => x.id === cur.id);
      if (a && (a.type === 'shelf' || a.type === 'fridge')) {
        return { key: a.id, label: { tr: 'Ürün yerleştir', en: 'Stock fixture', az: 'Məhsul yerləşdir', ru: 'Выложить товар' },
          run: () => this.openPanel('shelf', a.id) };
      }
      if (a && a.type === 'till') return { key: a.id, label: { tr: 'Kasayı aç', en: 'Open checkout', az: 'Kassanı aç', ru: 'Открыть кассу' }, run: () => this.openCashier() };
    }
    return oldResolve.call(this, cur);
  };
  const oldNav = SiteUI.prototype._renderNav;
  SiteUI.prototype._renderNav = function () {
    oldNav.call(this);
    this.$nav.insertAdjacentHTML('beforeend', `<button data-act="nav" data-v="build" class="${this.page === 'build' ? 'on' : ''}">${L('title')}</button>`);
  };
  SiteUI.prototype.p_build = function () { return (this.marketBuild || feature)?.catalogHTML() || ''; };

  const style = document.createElement('style');
  style.textContent = `
  .mb-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
  .mb-card{background:#f5faf5;border:1px solid #d6e6d9;border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:8px}
  .mb-card b{font-size:15px}.mb-card small{color:#486052;line-height:1.4}
  .mb-actions{display:flex;gap:8px;flex-wrap:wrap}.mb-actions button{min-height:42px}
  #mb-editor{position:fixed;inset:0;z-index:99999;background:rgba(12,26,20,.96);color:#f7fff9;display:none;overflow:auto;touch-action:pan-y;font:14px system-ui,sans-serif}
  #mb-editor.open{display:block}.mb-shell{max-width:1100px;margin:auto;padding:max(10px,env(safe-area-inset-top)) max(12px,env(safe-area-inset-right)) max(12px,env(safe-area-inset-bottom)) max(12px,env(safe-area-inset-left))}
  .mb-top{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.mb-top h2{margin:4px auto 4px 0;font-size:20px}
  #mb-editor button{border:0;border-radius:9px;background:#294c37;color:white;font:inherit;font-weight:700;padding:10px 12px;min-height:42px;cursor:pointer}
  #mb-editor button.active{background:#e1b94b;color:#182b1c}#mb-editor button.primary{background:#47bd70;color:#092414}
  .mb-layout{display:grid;grid-template-columns:minmax(0,1fr) 210px;gap:12px;margin-top:10px}
  .mb-mapwrap{background:#1a3226;border-radius:12px;padding:8px;min-width:0}
  #mb-map{display:block;width:100%;height:min(60vh,520px);background:#e8eee5;border-radius:8px;touch-action:none;cursor:crosshair}
  .mb-sidebar{max-height:60vh;overflow:auto;display:flex;flex-direction:column;gap:6px}
  .mb-sidebar button{text-align:left}.mb-note{color:#c6d9cb;line-height:1.4;margin:8px 0}
  #mb-status{min-height:1.4em;color:#f6d975;font-weight:700}
  @media(max-width:650px){.mb-layout{grid-template-columns:1fr}.mb-sidebar{max-height:120px;display:flex;flex-direction:row;overflow:auto}.mb-sidebar button{flex:none}.mb-mapwrap{order:2}#mb-map{height:45vh}.mb-shell{padding:8px}.mb-top h2{font-size:16px}}
  `;
  document.head.appendChild(style);

  class MarketBuild {
    constructor(options = {}) {
      this.owner = options.owner || 'main';
      this.idPrefix = options.idPrefix || 'build_';
      this.data = null;
      this.group = null;
      this.createdCols = [];
      this.createdHits = [];
      this.upperCols = [];
      this.floor = 0;
      this.selected = null;
      this.snapshot = null;
      this.drag = null;
      this.stairTrip = null;
      const updateCamera = g.fpsCam.update.bind(g.fpsCam);
      g.fpsCam.update = (dt, ...args) => {
        updateCamera(dt, ...args);
        if (this.stairTrip) this.animateStairs(dt);
      };
      this.makeEditor();
      g.depot.site.root.addEventListener('click', e => this.siteClick(e));
    }
    makeEditor() {
      const el = document.createElement('div');
      el.id = 'mb-editor';
      el.innerHTML = `<div class="mb-shell"><div class="mb-top"><h2 data-build-text="editor"></h2>
        <button data-mb="floor0" data-build-text="ground"></button><button data-mb="floor1" data-build-text="upper"></button>
        <button data-mb="rotate" data-build-text="rotate"></button><button data-mb="cancel" data-build-text="cancel"></button><button data-mb="save" class="primary" data-build-text="save"></button></div>
      <p class="mb-note" data-build-text="help"></p>
        <div id="mb-status" aria-live="polite"></div><div class="mb-layout"><div class="mb-mapwrap"><canvas id="mb-map"></canvas></div><div class="mb-sidebar" id="mb-items"></div></div></div>`;
      document.body.appendChild(el);
      this.editor = el;
      this.canvas = el.querySelector('#mb-map');
      this.status = el.querySelector('#mb-status');
      this.list = el.querySelector('#mb-items');
      el.addEventListener('click', e => this.editorClick(e));
      this.canvas.addEventListener('pointerdown', e => this.pointerDown(e));
      this.canvas.addEventListener('pointermove', e => this.pointerMove(e));
      this.canvas.addEventListener('pointerup', e => this.pointerUp(e));
      this.canvas.addEventListener('pointercancel', e => this.pointerUp(e));
      window.addEventListener('resize', () => { if (el.classList.contains('open')) this.draw(); });
    }
    catalogHTML() {
      if (!this.data) return '';
      const b = this.data.marketBuild, depth = backDepth(this.data.upgrades);
      const canFloor = depth >= 6 && this.data.money >= FLOOR_PRICE;
      const cards = Object.entries(CATALOG).map(([id, c]) => `<div class="mb-card"><b>${c.icon} ${L(id)}</b>
        <small>${c.cap ? L('capacity',{n:c.cap}) : id === 'till' ? L('tillDesc') : L('decorDesc')}</small>
        <button class="pc-btn pri" data-act="mb-buy" data-kind="${id}" ${this.data.money < c.price || b.items.length >= 100 ? 'disabled' : ''}>${L('buy',{price:c.price})}</button></div>`).join('');
      return `<div class="pc-box"><h3>${L('title')}</h3><p class="pc-muted">${L('balance',{money:Math.floor(this.data.money)})}</p>
        <div class="mb-actions"><button class="pc-btn pri" data-act="mb-edit">${L('openEditor')}</button>
        ${b.upper ? `<span class="pc-badge ok">${L('built')}</span>` : `<button class="pc-btn" data-act="mb-upper" ${canFloor ? '' : 'disabled'}>${L('buildUpper',{price:FLOOR_PRICE})}</button>`}</div>
        <p class="pc-muted">${L(b.upper ? 'stairsHelp' : 'needsExpansion')}</p>
        <div class="mb-list">${cards}</div><p class="pc-muted">${L('manual')}</p></div>`;
    }
    siteClick(e) {
      const button = e.target.closest('[data-act]');
      if (!button || !this.data || button.disabled) return;
      const act = button.dataset.act;
      if (act === 'mb-buy') {
        const c = CATALOG[button.dataset.kind], b = this.data.marketBuild;
        if (!c || b.items.length >= 100 || this.data.money < c.price) return;
        this.data.money -= c.price;
        b.items.push({ id: this.idPrefix + b.seq++, type: button.dataset.kind, x: null, z: null, floor: 0, rot: 0 });
        g.saveNow();
        g.audio.play('cash');
        g.depot.site.render(true);
        g.depot.site._snack(L('added',{name:L(button.dataset.kind)}));
      } else if (act === 'mb-upper') {
        if (this.data.marketBuild.upper || backDepth(this.data.upgrades) < 6 || this.data.money < FLOOR_PRICE) return;
        this.data.money -= FLOOR_PRICE;
        this.data.marketBuild.upper = true;
        this.rebuild();
        g.saveNow();
        g.audio.play('cash');
        g.depot.site.render(true);
      } else if (act === 'mb-edit') this.open();
    }
    attach(data) {
      this.data = data;
      data.marketBuild = clean(data.marketBuild);
      syncFixtures(data.marketBuild, data.upgrades, this.owner);
      for (const a of data.marketBuild.items) if (a.x !== null && CATALOG[a.type].cap && !data.fixtures[a.id]) data.fixtures[a.id] = {};
      this.rebuild();
    }
    reset() {
      if (this.editor.classList.contains('open')) this.close(false);
      this.stairTrip = null;
      this.clearWorld();
      if (g.player.marketUpper) { g.player.marketUpper = null; g.fpsCam.eyeHeight = 1.62; }
      this.data = null;
    }
    clearWorld() {
      if (this.group) { g.scene.remove(this.group); this.group = null; }
      for (const c of this.createdCols) { const i = g.world.colliders.indexOf(c); if (i >= 0) g.world.colliders.splice(i, 1); }
      for (const h of this.createdHits) { const i = g.world.hitboxes.indexOf(h); if (i >= 0) g.world.hitboxes.splice(i, 1); if (h.parent) h.parent.remove(h); }
      this.createdCols = []; this.createdHits = []; this.upperCols = [];
      if (g.world.extCeil) g.world.extCeil.visible = true;
    }
    box(parent, x, y, z, w, h, d, color) {
      const m = new T.Mesh(g.world.geo('box'), g.world.mat(color));
      m.scale.set(w, h, d); m.position.set(x, y + h / 2, z); m.castShadow = false; m.receiveShadow = true;
      parent.add(m); return m;
    }
    hit(id, x, y, z, w, h, d, action, label) {
      g.world.addInteractable({ id, label: label || { tr: 'Kullan', en: 'Use', az: 'İstifadə et', ru: 'Использовать' }, box: [w, h, d, x, y, z], action });
      this.createdHits.push(g.world.hitboxes[g.world.hitboxes.length - 1]);
    }
    stairFloor(up) {
      if (!this.data || !this.data.marketBuild.upper || this.stairTrip || g.depot.carriedId) {
        if (g.depot.carriedId) g.ui.toast(L('dropBox'), 2200);
        return;
      }
      if (up === !!g.player.marketUpper) return;
      this.stairTrip = { up, elapsed: 0, x: g.player.pos.x, z: g.player.pos.z,
        yaw: g.fpsCam.yaw, pitch: g.fpsCam.pitch, step: -1 };
      g.player.vel.x = 0;
      g.player.vel.z = 0;
      g.setInputLocked(true);
      g.ui.setPrompt(null);
      g.ui.setSecondary(null);
    }
    animateStairs(dt) {
      const trip = this.stairTrip;
      if (!trip) return;
      if (g.controls.enabled) g.setInputLocked(true);
      // Stage 1: approach, stage 2: twelve distinct risers, stage 3: step onto landing.
      const approach = .65, climb = 4.8, landing = .75, duration = approach + climb + landing;
      trip.elapsed = Math.min(duration, trip.elapsed + Math.max(0, dt));
      const t = trip.elapsed, mix = (a, b, p) => a + (b-a)*p;
      const smooth = p => { p = Math.max(0, Math.min(1, p)); return p*p*(3-2*p); };
      let x, z, height, bob = 0;
      const start = trip.up ? { x: 5.35, z: -5.6, h: 0 } : { x: 5.35, z: -9.1, h: 3.2 };
      const end = trip.up ? { x: 3.35, z: -7.2, h: 3.2 } : { x: 4.5, z: -4.1, h: 0 };
      if (t < approach) {
        const p = smooth(t / approach);
        x = mix(trip.x, start.x, p);
        z = mix(trip.z, start.z, p);
        height = start.h;
      } else if (t < approach + climb) {
        const p = (t - approach) / climb;
        const progress = trip.up ? p : 1-p;
        const steps = progress * 12;
        const whole = Math.min(11, Math.floor(steps));
        const fraction = steps - whole;
        height = (whole + smooth(fraction)) * 3.2 / 12;
        x = 5.35;
        z = mix(-5.6, -9.1, progress);
        bob = Math.sin(p * Math.PI * 24) * .018;
        const nextStep = Math.floor(p * 12);
        if (nextStep !== trip.step) {
          trip.step = nextStep;
          g.audio.play('place');
        }
      } else {
        const p = smooth((t - approach - climb) / landing);
        x = mix(5.35, end.x, p);
        z = mix(trip.up ? -9.1 : -5.6, end.z, p);
        height = end.h;
      }
      const targetYaw = trip.up ? 0 : Math.PI;
      const turn = Math.atan2(Math.sin(targetYaw-trip.yaw), Math.cos(targetYaw-trip.yaw));
      g.fpsCam.setAngles(trip.yaw + turn * smooth(t / approach), mix(trip.pitch, -.16, smooth(t / approach)));
      g.camera.rotation.set(g.fpsCam.pitch, g.fpsCam.yaw, 0);
      g.camera.position.set(x, 1.62 + height + bob, z);
      if (t >= duration - 1e-8) {
        this.stairTrip = null;
        this.finishStairs(trip.up);
        g.setInputLocked(false);
        g._promptKey = null;
        g.fpsCam.update(0, g.player.pos, 0);
      }
    }
    finishStairs(up) {
      if (up) {
        const depth = backDepth(this.data.upgrades);
        g.player.marketUpper = { bounds: { minX: -6.65, maxX: 6.65, minZ: -4.9-depth, maxZ: -5.55 }, colliders: this.upperCols };
        g.player.setPosition(3.35, -7.2); g.fpsCam.eyeHeight = 4.82;
      } else {
        g.player.marketUpper = null; g.fpsCam.eyeHeight = 1.62;
        g.player.setPosition(4.5, -4.1);
      }
      g.ui.toast(L(up ? 'wentUp' : 'wentDown'), 1600);
      g.saveNow();
    }
    rebuild() {
      if (!this.data) return;
      const wasUpper = !!g.player.marketUpper;
      this.clearWorld();
      const b = this.data.marketBuild, depth = backDepth(this.data.upgrades);
      this.group = new T.Group(); g.scene.add(this.group);
      this.buildLockedPreview(depth, b.upper);
      if (b.upper && depth >= 6) {
        if (g.world.extCeil) g.world.extCeil.visible = false;
        const z0 = -5.2-depth, z1 = -5.2, h = 3.2;
        // Rear hall upper slab with an opening above the staircase.
        this.box(this.group, -1.6, h-.12, (z0+z1)/2, 10.8, .12, depth, 0xc5bba7);
        this.box(this.group, 5.4, h-.12, (z0 + (-9.4))/2, 3.2, .12, Math.max(.1, -9.4-z0), 0xc5bba7);
        this.box(this.group, 5.4, h-.12, (-5.2 + -5.7)/2, 3.2, .12, .5, 0xc5bba7);
        this.box(this.group, -7.05, h, (z0+z1)/2, .18, 3, depth, 0xd8dfd5);
        this.box(this.group, 7.05, h, (z0+z1)/2, .18, 3, depth, 0xd8dfd5);
        this.box(this.group, 0, h, z0, 14.2, 3, .18, 0xd8dfd5);
        this.box(this.group, 0, h, z1, 14.2, 3, .18, 0xd8dfd5);
        this.box(this.group, 0, 6.2, (z0+z1)/2, 14.2, .12, depth, 0xecece4);
        for (let i = 0; i < 12; i++) this.box(this.group, 5.35, i*3.2/12, -5.8-i*.30, 1.35, .18, .34, 0x8e6e4e);
        this.box(this.group, 4.62, .2, -7.55, .06, 1.1, 3.8, 0x53635a);
        this.upperCols.push({ minX: 4.0, maxX: 6.9, minZ: -9.5, maxZ: -5.55 });
        this.hit('mb-stair-up', 5.35, 0, -6.4, 1.45, 1.8, .6, () => this.stairFloor(true), {tr:'Merdiven: 2. kata çık',en:'Stairs: go up',az:'Pilləkən: yuxarı qalx',ru:'Лестница: наверх'});
        this.hit('mb-stair-down', 3.7, 3.2, -7.2, .5, 1.8, 1.1, () => this.stairFloor(false), {tr:'Merdiven: zemin kata in',en:'Stairs: go down',az:'Pilləkən: aşağı en',ru:'Лестница: вниз'});
      }
      for (const a of b.items) if (a.x !== null) this.makeFurniture(a);
      if (b.upper && depth >= 6) this.buildRearUpperFacade(-5.2-depth);
      if (wasUpper && b.upper && depth >= 6) g.player.marketUpper = { bounds: { minX: -6.65, maxX: 6.65, minZ: -4.9-depth, maxZ: -5.55 }, colliders: this.upperCols };
    }
    buildLockedPreview(depth, upper) {
      // Architectural previews are non-interactive: existing walls and walk
      // bounds remain authoritative until each expansion has been purchased.
      if (depth >= 6 && upper) return;
      const preview = new T.Group(); preview.name = 'LOCKED MARKET EXPANSION PREVIEW'; this.group.add(preview);
      const material = this.previewMaterial || (this.previewMaterial=new T.MeshBasicMaterial({color:0x72c8ad,transparent:true,opacity:.32,depthWrite:false}));
      const walls=this.previewWalls || (this.previewWalls=new T.MeshBasicMaterial({color:0xd0eee1,transparent:true,opacity:.14,depthWrite:false}));
      const floor=this.previewFloor || (this.previewFloor=new T.MeshBasicMaterial({color:0xbde6c4,transparent:true,opacity:.22,depthWrite:false}));
      const windows=this.previewWindows || (this.previewWindows=new T.MeshBasicMaterial({color:0x9dd8ed,transparent:true,opacity:.28,depthWrite:false}));
      const bar=(x,y,z,sx,sy,sz,mat=material)=>{
        const mesh=new T.Mesh(g.world.geo('box'),mat);
        mesh.scale.set(sx,sy,sz);mesh.position.set(x,y,z);preview.add(mesh);
      };
      if(depth<6){
        const near=-5.2-depth,far=-11.2,mid=(near+far)/2,length=near-far;
        for(const x of [-7,7]){bar(x,1.55,far,.1,3.1,.1);bar(x,.08,mid,.1,.1,length);bar(x,3.1,mid,.1,.1,length);}
        bar(0,.08,far,14,.1,.1);bar(0,3.1,far,14,.1,.1);
        // Translucent shell and floor make the locked rear hall legible from
        // outside without changing the original walls, collision or access.
        bar(0,.06,mid,14,.08,length,floor);
        for(const x of [-6.98,6.98])bar(x,1.55,mid,.07,3.0,length,walls);
        bar(0,1.55,far,14,3.0,.07,walls);
        for(const x of [-4.5,-1.5,1.5,4.5])bar(x,1.8,far-.05,2.0,1.05,.05,windows);
      }
      if(!upper){
        const end=-5.2-Math.max(6,depth),mid=(-5.2+end)/2,len=-5.2-end;
        for(const x of [-7,7]){bar(x,4.75,-5.2,.1,3.1,.1);bar(x,4.75,end,.1,3.1,.1);bar(x,6.3,mid,.1,.1,len);bar(x,3.25,mid,.1,.1,len);}
        for(const z of [-5.2,end]){bar(0,6.3,z,14,.1,.1);bar(0,3.25,z,14,.1,.1);}
        bar(0,3.23,mid,14,.08,len,floor);
        for(const x of [-6.98,6.98])bar(x,4.75,mid,.07,3.0,len,walls);
        bar(0,4.75,end,14,3.0,.07,walls);
        bar(0,6.31,mid,14,.07,len,walls);
        for(const x of [-5,-3,-1,1,3,5])bar(x,4.75,end-.05,1.35,1.05,.05,windows);
      }
      const texture=this.previewTexture || (this.previewTexture=g.world.canvasTex(512,128,(ctx,w,h)=>{
        ctx.fillStyle='#183c38';ctx.fillRect(0,0,w,h);ctx.fillStyle='#d8fff2';
        ctx.font='bold 37px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText('KİLİTLİ · BİLGİSAYARDAN AÇ',w/2,h/2);
      }));
      const signMaterial=this.previewSignMaterial || (this.previewSignMaterial=new T.MeshBasicMaterial({map:texture,side:T.DoubleSide,transparent:true,opacity:.85}));
      const sign=new T.Mesh(g.world.geo('plane'),signMaterial);
      sign.scale.set(3.5,.88,1);sign.position.set(0,upper?2.2:5.0,-5.28-Math.max(6,depth));preview.add(sign);
    }
    buildRearUpperFacade(z0) {
      const y = 4.45, faceZ = z0 - .12, glow = REAR_WINDOW_MAT;
      // A readable second-storey rear elevation: warm lit windows, framing, and a market sign.
      for (let i=0;i<6;i++) {
        const x = -5.5 + i * 2.2;
        const pane = new T.Mesh(g.world.geo('box'), glow); pane.scale.set(1.35,1.05,.06); pane.position.set(x,y,faceZ); pane.userData.static=true; this.group.add(pane);
        this.box(this.group,x-.72,3.85,faceZ,.08,1.25,.12,0x394951);
        this.box(this.group,x+.72,3.85,faceZ,.08,1.25,.12,0x394951);
        this.box(this.group,x,4.52,faceZ,1.48,.08,.12,0x394951);
        this.box(this.group,x,3.18,faceZ,1.48,.08,.12,0x394951);
      }
      if (!this.rearSignTex) this.rearSignTex = g.world.canvasTex(512,96,(ctx,w,h)=>{ctx.fillStyle='#173e31';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#f2cf65';ctx.lineWidth=6;ctx.strokeRect(4,4,w-8,h-8);ctx.fillStyle='#fff';ctx.font='900 48px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('MARKET · UPPER FLOOR',w/2,h/2);});
      if (!this.rearSignMaterial) this.rearSignMaterial = new T.MeshBasicMaterial({map:this.rearSignTex,side:T.DoubleSide});
      const sign = new T.Mesh(g.world.geo('plane'),this.rearSignMaterial);
      sign.scale.set(6.2,1.05,1);sign.position.set(0,5.45,faceZ-.05);sign.userData.static=true;this.group.add(sign);
    }
    upperRoute(from, goal, depth) {
      const cell=.4, minX=-6.5, maxX=6.5, minZ=-5.2-depth, maxZ=-5.55;
      const nx=Math.floor((maxX-minX)/cell)+1,nz=Math.floor((maxZ-minZ)/cell)+1;
      const xx=i=>minX+i*cell,zz=j=>minZ+j*cell;
      const free=(i,j)=>i>=0&&j>=0&&i<nx&&j<nz&&!this.upperCols.some(c=>xx(i)>c.minX-.22&&xx(i)<c.maxX+.22&&zz(j)>c.minZ-.22&&zz(j)<c.maxZ+.22);
      const nearest=(x,z)=>{const i0=Math.round((x-minX)/cell),j0=Math.round((z-minZ)/cell);let best=null,bd=Infinity;for(let j=Math.max(0,j0-6);j<=Math.min(nz-1,j0+6);j++)for(let i=Math.max(0,i0-6);i<=Math.min(nx-1,i0+6);i++){if(!free(i,j))continue;const d=(xx(i)-x)**2+(zz(j)-z)**2;if(d<bd){bd=d;best={i,j};}}return best;};
      const a=nearest(from.x,from.z),b=nearest(goal.x,goal.z);if(!a||!b)return null;
      const key=(i,j)=>j*nx+i, ak=key(a.i,a.j),bk=key(b.i,b.j),open=[{...a,f:0}],prev=new Map(),score=new Map([[ak,0]]),closed=new Set();
      while(open.length){let bi=0;for(let i=1;i<open.length;i++)if(open[i].f<open[bi].f)bi=i;const c=open.splice(bi,1)[0],ck=key(c.i,c.j);if(closed.has(ck))continue;closed.add(ck);if(ck===bk){const out=[];let k=ck;while(k!==ak){out.unshift({x:xx(k%nx),z:zz(Math.floor(k/nx)),y:3.2});k=prev.get(k);}return out;}
        for(const [di,dj] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const i=c.i+di,j=c.j+dj;if(!free(i,j)||(di&&dj&&(!free(c.i+di,c.j)||!free(c.i,c.j+dj))))continue;const k=key(i,j),ng=score.get(ck)+(di&&dj?1.414:1);if(ng>=(score.get(k)??Infinity))continue;score.set(k,ng);prev.set(k,ck);open.push({i,j,f:ng+Math.hypot(i-b.i,j-b.j)});}
      }return null;
    }
    workerRoute(from,targetId) {
      if(!this.data||!this.data.marketBuild.upper)return null;
      const depth=backDepth(this.data.upgrades), items=this.data.marketBuild.items;
      const item=items.find(a=>a.id===targetId&&a.x!==null);
      const target=targetId==='__home__'?{x:-5.6,z:3.2,floor:0,rot:0}:(targetId&&typeof targetId==='object'?{...targetId,floor:targetId.floor===1?1:0,rot:targetId.rot||0}:item);
      if(!target)return null;
      let tx=target.x,tz=target.z+.95;
      if(target.rot%2){tx=target.x+1.05;tz=target.z;}
      const floor=target.floor===1?1:0, current=from.y>1.6?1:0;
      if(current===floor){
        if(floor){const r=this.upperRoute(from,{x:tx,z:tz},depth);return r&&r.length?r:[{x:tx,z:tz,y:3.2}];}
        const r=findPath(g.world.colliders,{x:from.x,z:from.z},{x:tx,z:tz},{r:.22});return r?r.map(p=>({x:p.x,z:p.z,y:0})):null;
      }
      const landing={x:3.35,z:-7.2,y:3.2},bottom={x:5.35,z:-5.6,y:0},top={x:5.35,z:-9.1,y:3.2};
      if(floor===1){
        const ground=findPath(g.world.colliders,{x:from.x,z:from.z},{x:bottom.x,z:bottom.z},{r:.22});if(!ground)return null;
        const stairs=[];for(let i=1;i<=12;i++)stairs.push({x:bottom.x,z:-5.6-i*3.5/12,y:i*3.2/12});
        const up=this.upperRoute(landing,{x:tx,z:tz},depth);if(!up)return null;return [...ground.map(p=>({x:p.x,z:p.z,y:0})),...stairs,landing,...up];
      }
      const upper=this.upperRoute(from,landing,depth);if(!upper)return null;
      const stairs=[top];for(let i=11;i>=0;i--)stairs.push({x:bottom.x,z:-5.6-i*3.5/12,y:i*3.2/12});
      const ground=findPath(g.world.colliders,{x:bottom.x,z:bottom.z},{x:tx,z:tz},{r:.22});if(!ground)return null;
      return [...upper,top,...stairs,...ground.map(p=>({x:p.x,z:p.z,y:0}))];
    }
    rect(a) {
      const c = CATALOG[a.type], swap = a.rot % 2;
      const w = swap ? c.d : c.w, d = swap ? c.w : c.d;
      return { minX: a.x-w/2, maxX: a.x+w/2, minZ: a.z-d/2, maxZ: a.z+d/2 };
    }
    makeFurniture(a) {
      const c = CATALOG[a.type], m = new T.Group();
      m.position.set(a.x, a.floor ? 3.2 : 0, a.z); m.rotation.y = a.rot * Math.PI/2;
      this.group.add(m);
      if (a.type === 'shelf') {
        this.box(m, 0, 0, 0, c.w, .12, c.d, 0x5b6563);
        for (let i=0;i<4;i++) {
          this.box(m, 0, .3+i*.43, 0, c.w, .07, c.d, 0xd9dcd0);
          for (let j=-2;j<=2;j++) this.box(m, j*.27, .38+i*.43, 0, .18, .18, .16, [0xd9a735,0xbd5746,0x67a35e,0x628dae,0xd58f4c][j+2]);
        }
        this.box(m, -.77, 0, 0, .06, 1.85, c.d, 0x69736d); this.box(m, .77, 0, 0, .06, 1.85, c.d, 0x69736d);
      } else if (a.type === 'fridge') {
        this.box(m, 0, 0, 0, c.w, 1.85, c.d, 0xc8d5d3);
        this.box(m, 0, .25, c.d/2+.01, .88, 1.35, .035, 0x6b9aaf);
        for(let i=0;i<3;i++) this.box(m, 0, .45+i*.38, c.d/2+.04, .8, .04, .04, 0xeaf1ed);
        this.box(m, .4, .45, c.d/2+.06, .04, .8, .05, 0x40545a);
      } else if (a.type === 'till') {
        this.box(m, 0, 0, 0, c.w, .85, c.d, 0xbe453e);
        this.box(m, 0, .85, 0, c.w, .1, c.d, 0xd3d8d2);
        this.box(m, .3, .95, 0, .35, .3, .25, 0x283b37);
      } else if (a.type === 'table') {
        this.box(m, 0, .72, 0, c.w, .12, c.d, 0xa56e3c);
        for(const x of [-.55,.55]) for(const z of [-.32,.32]) this.box(m, x, 0, z, .09, .72, .09, 0x77502d);
      } else {
        this.box(m, 0, 0, 0, .42, .42, .42, 0xa96448);
        for(const x of [-.16,0,.16]) this.box(m, x, .4, 0, .2, .65, .24, 0x4b9654);
      }
      const rect = this.rect(a);
      if (a.floor) this.upperCols.push(rect); else { g.world.colliders.push(rect); this.createdCols.push(rect); }
      if (c.cap || a.type === 'till') this.hit(a.id, a.x, a.floor ? 3.2 : 0, a.z, rect.maxX-rect.minX, 1.7, rect.maxZ-rect.minZ, () => {});
    }
    open() {
      g.depot.site.close();
      g.setInputLocked(true);
      this.snapshot = JSON.stringify(this.data.marketBuild);
      this.floor = 0; this.selected = null;
      this.setStatus(null);
      this.editor.classList.add('open');
      this.updateEditor();
    }
    setStatus(key) {
      this.statusKey = key;
      this.status.textContent = key ? L(key) : '';
    }
    close(commit) {
      if (!this.data) return;
      if (!commit && this.snapshot) this.data.marketBuild = clean(JSON.parse(this.snapshot));
      else {
        syncFixtures(this.data.marketBuild, this.data.upgrades, this.owner);
        for (const a of this.data.marketBuild.items) if (a.x !== null && CATALOG[a.type].cap && !this.data.fixtures[a.id]) this.data.fixtures[a.id] = {};
      }
      this.editor.classList.remove('open');
      this.snapshot = null; this.drag = null;
      this.rebuild();
      g.setInputLocked(false);
      if (commit) g.saveNow();
    }
    editorClick(e) {
      const button = e.target.closest('button');
      if (!button || !this.data) return;
      if (button.dataset.item) {
        this.selected = button.dataset.item;
        const a = this.data.marketBuild.items.find(x => x.id === this.selected);
        if (a && a.x !== null) this.floor = a.floor;
        this.updateEditor(); return;
      }
      const act = button.dataset.mb;
      if (act === 'save') return this.close(true);
      if (act === 'cancel') return this.close(false);
      if (act === 'floor0') { this.floor = 0; }
      if (act === 'floor1') {
        if (!this.data.marketBuild.upper) { this.setStatus('buildFirst'); return; }
        this.floor = 1;
      }
      if (act === 'rotate') {
        const a = this.data.marketBuild.items.find(x => x.id === this.selected);
        if (!a) { this.setStatus('chooseFirst'); return; }
        const old = a.rot; a.rot = (a.rot + 1) % 4;
        if (a.x !== null && !this.valid(a)) { a.rot = old; this.setStatus('noSpace'); }
      }
      this.updateEditor();
    }
    bounds() {
      const depth = backDepth(this.data.upgrades);
      return this.floor ? { minX: -6.7, maxX: 6.7, minZ: -5.2-depth, maxZ: -5.2 }
        : { minX: ground.minX, maxX: ground.maxX, minZ: -4.7-depth, maxZ: ground.maxZ };
    }
    overlaps(a,b,pad=0) { return a.minX < b.maxX+pad && a.maxX > b.minX-pad && a.minZ < b.maxZ+pad && a.maxZ > b.minZ-pad; }
    valid(a) {
      const r = this.rect(a), depth = backDepth(this.data.upgrades);
      const limits = a.floor ? { minX:-6.65,maxX:6.65,minZ:-5.15-depth,maxZ:-5.25 } : { minX:-6.65,maxX:6.65,minZ:-4.95-depth,maxZ:4.7 };
      if (a.floor && !this.data.marketBuild.upper) return false;
      if (r.minX < limits.minX || r.maxX > limits.maxX || r.minZ < limits.minZ || r.maxZ > limits.maxZ) return false;
      // Keep the passage and staircase/landing open.
      const reserved = [{ minX: 3.1, maxX: 5.9, minZ: -5.7, maxZ: -4.0 }, { minX:-1.5,maxX:1.5,minZ:3.6,maxZ:5.1 }];
      if (this.data.marketBuild.upper) reserved.push({minX:3.2,maxX:6.9,minZ:-9.7,maxZ:-5.55});
      if (reserved.some(q => this.overlaps(r,q,.12))) return false;
      if (this.data.marketBuild.items.some(o => o.id !== a.id && o.x !== null && o.floor === a.floor && this.overlaps(r,this.rect(o),.16))) return false;
      if (!a.floor) {
        const other = g.world.colliders.filter(c => !this.createdCols.includes(c));
        if (other.some(q => this.overlaps(r,q,.12))) return false;
        if (this.overlaps(r,{minX:g.player.pos.x-.5,maxX:g.player.pos.x+.5,minZ:g.player.pos.z-.5,maxZ:g.player.pos.z+.5})) return false;
      }
      return true;
    }
    updateEditor() {
      const b = this.data.marketBuild;
      this.editor.querySelectorAll('[data-build-text]').forEach(el=>{el.textContent=L(el.dataset.buildText);});
      if(this.statusKey)this.status.textContent=L(this.statusKey);
      this.editor.querySelector('[data-mb="floor0"]').classList.toggle('active', this.floor === 0);
      this.editor.querySelector('[data-mb="floor1"]').classList.toggle('active', this.floor === 1);
      this.list.innerHTML = b.items.length ? b.items.map(a => `<button data-item="${a.id}" class="${a.id === this.selected ? 'active' : ''}">${CATALOG[a.type].icon} ${L(a.type)}<br><small>${L(a.x === null ? 'inventory' : a.floor ? 'upper' : 'ground')}</small></button>`).join('')
        : `<span class="mb-note">${L('noItems')}</span>`;
      this.draw();
    }
    draw() {
      if (!this.data || !this.editor.classList.contains('open')) return;
      const c = this.canvas, rect = c.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
      c.width = Math.max(1, Math.round(rect.width*dpr)); c.height = Math.max(1, Math.round(rect.height*dpr));
      const ctx = c.getContext('2d'), b = this.bounds(), pad = 18*dpr;
      const scale = Math.min((c.width-2*pad)/(b.maxX-b.minX), (c.height-2*pad)/(b.maxZ-b.minZ));
      const ox = (c.width-(b.maxX-b.minX)*scale)/2, oy = (c.height-(b.maxZ-b.minZ)*scale)/2;
      this.mapTransform = { scale, ox, oy, b, dpr };
      ctx.fillStyle='#e7eee6'; ctx.fillRect(0,0,c.width,c.height);
      const X = x => ox+(x-b.minX)*scale, Z = z => oy+(z-b.minZ)*scale;
      ctx.fillStyle='#f9faf4'; ctx.fillRect(X(b.minX),Z(b.minZ),(b.maxX-b.minX)*scale,(b.maxZ-b.minZ)*scale);
      ctx.strokeStyle='#ccd9cd'; ctx.lineWidth=1*dpr;
      for(let x=Math.ceil(b.minX);x<=b.maxX;x++){ctx.beginPath();ctx.moveTo(X(x),Z(b.minZ));ctx.lineTo(X(x),Z(b.maxZ));ctx.stroke();}
      for(let z=Math.ceil(b.minZ);z<=b.maxZ;z++){ctx.beginPath();ctx.moveTo(X(b.minX),Z(z));ctx.lineTo(X(b.maxX),Z(z));ctx.stroke();}
      if (!this.floor) {
        ctx.save();ctx.beginPath();ctx.rect(X(b.minX),Z(b.minZ),(b.maxX-b.minX)*scale,(b.maxZ-b.minZ)*scale);ctx.clip();
        ctx.fillStyle='#abb7aa';
        for (const q of g.world.colliders) if (!this.createdCols.includes(q) && q.maxX>b.minX && q.minX<b.maxX && q.maxZ>b.minZ && q.minZ<b.maxZ)
          ctx.fillRect(X(q.minX),Z(q.minZ),(q.maxX-q.minX)*scale,(q.maxZ-q.minZ)*scale);
        ctx.restore();
      }
      if (this.data.marketBuild.upper) { ctx.fillStyle='#d8c998';ctx.fillRect(X(4),Z(-9.5),2.9*scale,3.95*scale); }
      for (const a of this.data.marketBuild.items) if (a.x !== null && a.floor === this.floor) {
        const r=this.rect(a);ctx.fillStyle=CATALOG[a.type].color;ctx.fillRect(X(r.minX),Z(r.minZ),(r.maxX-r.minX)*scale,(r.maxZ-r.minZ)*scale);
        ctx.strokeStyle=a.id===this.selected?'#142c1c':'#ffffff';ctx.lineWidth=(a.id===this.selected?3:1)*dpr;
        ctx.strokeRect(X(r.minX),Z(r.minZ),(r.maxX-r.minX)*scale,(r.maxZ-r.minZ)*scale);
        ctx.fillStyle='#173124';ctx.font=`bold ${Math.max(10*dpr,Math.min(15*dpr,scale*.35))}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText(CATALOG[a.type].icon,X(a.x),Z(a.z));
      }
    }
    worldPoint(e) {
      const r=this.canvas.getBoundingClientRect(), m=this.mapTransform;
      return { x: Math.round(((e.clientX-r.left)*m.dpr-m.ox)/m.scale*4)/4+m.b.minX,
        z: Math.round(((e.clientY-r.top)*m.dpr-m.oy)/m.scale*4)/4+m.b.minZ };
    }
    pointerDown(e) {
      e.preventDefault(); this.canvas.setPointerCapture(e.pointerId);
      const p=this.worldPoint(e);
      let a=[...this.data.marketBuild.items].reverse().find(o => o.x!==null && o.floor===this.floor && p.x>=this.rect(o).minX && p.x<=this.rect(o).maxX && p.z>=this.rect(o).minZ && p.z<=this.rect(o).maxZ);
      if (a) this.selected=a.id;
      else a=this.data.marketBuild.items.find(o => o.id===this.selected);
      if (!a) { this.setStatus('chooseInventory'); return; }
      this.drag={id:a.id, original:{x:a.x,z:a.z,floor:a.floor}, lastValid:null};
      this.moveTo(p); this.updateEditor();
    }
    pointerMove(e) { if (!this.drag) return; e.preventDefault(); this.moveTo(this.worldPoint(e)); this.draw(); }
    pointerUp(e) {
      if (!this.drag) return;
      const a=this.data.marketBuild.items.find(o=>o.id===this.drag.id);
      if (!this.valid(a)) Object.assign(a,this.drag.lastValid || this.drag.original);
      this.drag=null; this.updateEditor();
    }
    moveTo(p) {
      const a=this.data.marketBuild.items.find(o=>o.id===this.drag.id);
      a.x=p.x; a.z=p.z; a.floor=this.floor;
      if (this.valid(a)) { this.drag.lastValid={x:a.x,z:a.z,floor:a.floor};this.setStatus('valid'); }
      else this.setStatus('invalid');
    }
  }
  feature = new MarketBuild();
  g.marketBuild = feature;
  g.depot.marketBuild = feature;
  g.depot.site.marketBuild = feature;
  window.__MMS_CREATE_MARKET_BUILD = function (host, options = {}) {
    const previous = g;
    g = host;
    let instance;
    try {
      instance = new MarketBuild(options);
      const proto = MarketBuild.prototype;
      for (const name of Object.getOwnPropertyNames(proto)) {
        if (name === 'constructor' || typeof instance[name] !== 'function') continue;
        const original = instance[name].bind(instance);
        instance[name] = (...args) => {
          const before = g;
          g = host;
          try { return original(...args); }
          finally { g = before; }
        };
      }
    } finally {
      g = previous;
    }
    if (host.depot) host.depot.marketBuild = instance;
    if (host.depot && host.depot.site) host.depot.site.marketBuild = instance;
    return instance;
  };
  const oldLanguage = g.ui.setLanguage.bind(g.ui);
  g.ui.setLanguage = function(lang) {
    const result = oldLanguage(lang);
    if(feature.data && feature.editor.classList.contains('open'))feature.updateEditor();
    if(g.depot.site.isOpen){g.depot.site.retext();g.depot.site.render(false);}
    return result;
  };
  const oldAttach = g.depot.attach.bind(g.depot);
  g.depot.attach = function (data) {
    data.marketBuild = clean(data.marketBuild);
    syncFixtures(data.marketBuild, data.upgrades, 'main');
    const result = oldAttach(data);
    feature.attach(data);
    this.marketBuild = feature;
    return result;
  };
  const oldReset = g.depot.reset.bind(g.depot);
  g.depot.reset = function () { feature.reset(); return oldReset(); };
  const oldBack = g.expand.applyWorld.bind(g.expand);
  g.expand.applyWorld = function (depth) {
    const result = oldBack(depth);
    if (feature.data) feature.rebuild();
    return result;
  };
})();
