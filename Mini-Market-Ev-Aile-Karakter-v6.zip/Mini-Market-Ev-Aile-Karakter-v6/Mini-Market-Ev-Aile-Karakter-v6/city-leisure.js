/* Park picnic, three-round game and small-pitch football. */
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root){root.MMS_CITY_LEISURE=api;api.install(root);}
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  class PitchBall {
    constructor(){this.x=118;this.z=164;this.vx=0;this.vz=0;this.goals=0;}
    kick(player){
      let dx=this.x-player.x,dz=this.z-player.z;
      let d=Math.hypot(dx,dz);
      if(d<.001){dx=1;dz=0;d=1;}
      this.vx=dx/d*9;this.vz=dz/d*9;
    }
    update(dt){
      dt=Math.max(0,Math.min(.05,Number(dt)||0));
      this.x+=this.vx*dt;this.z+=this.vz*dt;
      const drag=Math.exp(-1.05*dt);this.vx*=drag;this.vz*=drag;
      if(Math.hypot(this.vx,this.vz)<.06){this.vx=0;this.vz=0;}
      if((this.x<=104.8||this.x>=131.2)&&Math.abs(this.z-164)<=2.5){
        this.goals++;this.x=118;this.z=164;this.vx=0;this.vz=0;return true;
      }
      if(this.x<102.7||this.x>133.3){this.x=Math.max(102.7,Math.min(133.3,this.x));this.vx*=-.55;}
      if(this.z<153.7||this.z>174.3){this.z=Math.max(153.7,Math.min(174.3,this.z));this.vz*=-.55;}
      return false;
    }
  }
  // 0 rock, 1 paper, 2 scissors.
  function result(player,opponent){
    if(!Number.isInteger(player)||!Number.isInteger(opponent)||player<0||player>2||opponent<0||opponent>2)return null;
    if(player===opponent)return 0;
    return (player-opponent+3)%3===1?1:-1;
  }
  function install(win){
    const g=win.__mms,T=win.THREE,doc=win.document;
    if(!g||!T||!g.world||win.__cityLeisure)return null;
    const w=g.world,group=new T.Group();group.name='PARK ETKINLIKLERI';w.scene.add(group);
    const b=(sx,sy,sz,x,y,z,color)=>{
      const m=w.b(sx,sy,sz,x,y,z,color,{parent:group,cast:false,receive:false});
      m.userData.static=true;return m;
    };
    // A small picnic lawn at the former carousel, separate from the street.
    b(7.6,.05,6.0,-11,.01,29.5,0x71af70);
    b(2.8,.025,2.0,-10.4,.07,29.4,0xe7d2aa);
    for(const x of [-11.2,-10.4,-9.6])b(.08,.015,2.0,x,.099,29.4,0xb65d50);
    for(const z of [28.8,29.4,30])b(2.8,.015,.08,-10.4,.101,z,0xb65d50);
    b(.8,.3,.5,-10.4,.12,29.4,0x996b42);
    // Small table with a checkerboard, left open so people can approach.
    b(1.25,.13,1.1,-13.3,.75,30.4,0x825b3e);
    for(const dx of [-.48,.48])for(const dz of [-.38,.38])b(.10,.72,.10,-13.3+dx,.03,30.4+dz,0x5c5148);
    for(let x=0;x<4;x++)for(let z=0;z<4;z++)b(.2,.014,.2,-13.6+x*.2,.885,30.1+z*.2,(x+z)%2?0x494b43:0xe5d9bb);
    for(const z of [28.9,31.9]){
      b(1.4,.12,.5,-13.3,.48,z,0x8a5a36);
      for(const dx of [-.5,.5])b(.12,.46,.12,-13.3+dx,.02,z,0x454545);
    }
    w.colliders.push({minX:-13.925,maxX:-12.675,minZ:29.85,maxZ:30.95});
    if(typeof w.mergeStatic==='function')w.mergeStatic(group);

    const words={
      tr:{picnic:'🧺 Piknik yap',start:'Piknik başladı. Biraz burada kal.',done:'Piknik bitti, güzel vakit geçirdin!',cancel:'Piknikten ayrıldın.',busy:'Piknik zaten sürüyor.',table:'🎲 Taş kağıt makas oyna',title:'Taş, kağıt, makas',hint:'Üç tur oyna.',rock:'Taş',paper:'Kağıt',scissors:'Makas',close:'Kapat',again:'Yeniden oyna',round:'Tur',score:'Sen / Park',won:'Bu turu kazandın!',lost:'Bu turu kaybettin.',draw:'Berabere!',end:'Oyun bitti.',ball:'⚽ Topa vur',goal:'GOOOL!', },
      en:{picnic:'🧺 Have a picnic',start:'Picnic started. Stay nearby.',done:'Picnic finished. Nice break!',cancel:'You left the picnic.',busy:'Picnic already underway.',table:'🎲 Play rock paper scissors',title:'Rock, paper, scissors',hint:'Play three rounds.',rock:'Rock',paper:'Paper',scissors:'Scissors',close:'Close',again:'Play again',round:'Round',score:'You / Park',won:'You won this round!',lost:'You lost this round.',draw:'Draw!',end:'Game over.',ball:'⚽ Kick the ball',goal:'GOAL!',},
      az:{picnic:'🧺 Piknik et',start:'Piknik başladı. Yaxınlıqda qal.',done:'Piknik bitdi, yaxşı vaxt keçirdin!',cancel:'Piknikdən ayrıldın.',busy:'Piknik artıq davam edir.',table:'🎲 Daş-kağız-qayçı oyna',title:'Daş, kağız, qayçı',hint:'Üç raund oyna.',rock:'Daş',paper:'Kağız',scissors:'Qayçı',close:'Bağla',again:'Yenidən oyna',round:'Raund',score:'Sən / Park',won:'Bu raundu qazandın!',lost:'Bu raundu uduzdun.',draw:'Heç-heçə!',end:'Oyun bitdi.',ball:'⚽ Topa vur',goal:'QOL!',},
      ru:{picnic:'🧺 Устроить пикник',start:'Пикник начался. Оставайтесь рядом.',done:'Пикник закончился!',cancel:'Вы ушли с пикника.',busy:'Пикник уже идёт.',table:'🎲 Камень, ножницы, бумага',title:'Камень, ножницы, бумага',hint:'Сыграйте три раунда.',rock:'Камень',paper:'Бумага',scissors:'Ножницы',close:'Закрыть',again:'Играть снова',round:'Раунд',score:'Вы / Парк',won:'Вы выиграли раунд!',lost:'Вы проиграли раунд.',draw:'Ничья!',end:'Игра окончена.',ball:'⚽ Пнуть мяч',goal:'ГОЛ!',}
    };
    const tr=key=>(words[g.ui?.lang]||words.tr)[key]||key;
    const multi=key=>Object.fromEntries(Object.keys(words).map(lang=>[lang,words[lang][key]]));
    const notice=key=>g.ui.toast(tr(key),2200);
    const picnic={remaining:0};
    function startPicnic(){
      if(g.state!=='playing')return false;
      if(picnic.remaining>0){notice('busy');return false;}
      picnic.remaining=8;notice('start');return true;
    }
    w.addInteractable({id:'park-picnic',label:multi('picnic'),box:[3.2,1.5,2.5,-10.4,0,29.4],action:startPicnic});

    let modal=null,round=0,playerScore=0,opponentScore=0,open=false,message='';
    function createModal(){
      if(modal)return;
      const style=doc.createElement('style');
      style.textContent='#park-mini-game{display:none;position:fixed;inset:0;z-index:180;background:#0e211acb;align-items:center;justify-content:center;padding:16px;font:16px system-ui;color:#243b31}#park-mini-game.open{display:flex}#park-mini-game section{width:min(430px,94vw);background:#f4f3e4;border:2px solid #d8bd70;border-radius:16px;padding:18px}#park-mini-game h2{margin:0 0 8px}#park-mini-game p{line-height:1.4}#park-mini-game .choices{display:flex;gap:6px;flex-wrap:wrap}#park-mini-game button{flex:1;min-height:46px;border:0;border-radius:9px;background:#2e704c;color:white;font:700 15px system-ui;padding:8px}#park-mini-game button:disabled{opacity:.45}#park-mini-game .close{width:100%;margin-top:10px;background:#52616a}';
      doc.head.appendChild(style);
      modal=doc.createElement('div');modal.id='park-mini-game';
      modal.innerHTML='<section role="dialog" aria-modal="true"><h2></h2><p class="status"></p><p class="message"></p><div class="choices"><button type="button" data-choice="0"></button><button type="button" data-choice="1"></button><button type="button" data-choice="2"></button></div><button type="button" class="again"></button><button type="button" class="close"></button></section>';
      doc.body.appendChild(modal);
      for(const e of ['pointerdown','touchstart','mousedown','click'])modal.addEventListener(e,event=>event.stopPropagation());
      const buttons=modal.querySelectorAll('[data-choice]');
      buttons.forEach(button=>button.addEventListener('click',()=>play(Number(button.dataset.choice))));
      modal.querySelector('.again').addEventListener('click',resetGame);
      modal.querySelector('.close').addEventListener('click',closeGame);
    }
    function draw(){
      if(!modal)return;
      modal.querySelector('h2').textContent=tr('title');
      modal.querySelector('.status').textContent=`${tr('round')}: ${Math.min(round+1,3)}/3 · ${tr('score')}: ${playerScore} / ${opponentScore}`;
      modal.querySelector('.message').textContent=message||tr('hint');
      const keys=['rock','paper','scissors'];
      modal.querySelectorAll('[data-choice]').forEach((b,i)=>{b.textContent=tr(keys[i]);b.disabled=round>=3;});
      modal.querySelector('.again').textContent=tr('again');
      modal.querySelector('.close').textContent=tr('close');
    }
    function resetGame(){round=0;playerScore=0;opponentScore=0;message='';draw();}
    function play(choice){
      if(!open||round>=3)return;
      const opponent=Math.floor(Math.random()*3),r=result(choice,opponent);
      if(r>0)playerScore++;else if(r<0)opponentScore++;
      round++;
      message=`${tr(r>0?'won':r<0?'lost':'draw')} ${tr(['rock','paper','scissors'][opponent])}${round===3?' · '+tr('end'):''}`;
      draw();
    }
    function openGame(){
      if(g.state!=='playing')return;
      createModal();open=true;resetGame();g.setInputLocked(true);modal.classList.add('open');
    }
    function closeGame(){
      if(!open)return;
      open=false;modal.classList.remove('open');
      if(g.state==='playing')g.setInputLocked(false);
    }
    w.addInteractable({id:'park-table-game',label:multi('table'),box:[2.3,2,1.8,-13.3,0,30.4],action:openGame});
    win.addEventListener('keydown',e=>{if(open&&e.key==='Escape'){e.stopImmediatePropagation();closeGame();}},true);
    for(const key of ['pause','toMenu']){
      const original=g[key].bind(g);
      g[key]=function(...args){closeGame();return original(...args);};
    }

    const ball=new PitchBall();
    const mesh=new T.Mesh(w.geo('sphere'),w.mat(0xf2f0e8));
    mesh.scale.set(.42,.42,.42);mesh.position.set(ball.x,.28,ball.z);mesh.castShadow=false;
    w.root.add(mesh);
    w.addInteractable({id:'outskirts-football',label:multi('ball'),box:[1.4,1.3,1.4,ball.x,0,ball.z],action:()=>{if(g.state==='playing'){ball.kick(g.player.pos);g.audio.play('click');}}});
    const ballHit=w.hitboxes[w.hitboxes.length-1];
    const update=w.update.bind(w);
    w.update=function(dt,...args){
      const r=update(dt,...args);
      if(g.state!=='playing')return r;
      if(picnic.remaining>0){
        const p=g.player.pos;
        if(Math.hypot(p.x+10.4,p.z-29.4)>6){picnic.remaining=0;notice('cancel');}
        else {picnic.remaining=Math.max(0,picnic.remaining-Math.max(0,dt));if(picnic.remaining===0)notice('done');}
      }
      if(ball.update(dt))notice('goal');
      mesh.position.set(ball.x,.28,ball.z);mesh.rotation.z+=ball.vx*dt*.4;mesh.rotation.x+=ball.vz*dt*.4;
      if(ballHit){ballHit.position.x=ball.x;ballHit.position.z=ball.z;}
      return r;
    };
    const api={startPicnic,openGame,closeGame,inspect:()=>({picnicRemaining:picnic.remaining,gameOpen:open,round,playerScore,opponentScore,ball:{x:ball.x,z:ball.z,goals:ball.goals}})};
    win.__cityLeisure=api;return api;
  }
  return {PitchBall,result,install};
});
