/* Local pedestrian spacing and traffic-body avoidance, independent of rendering. */
(function(root){
  'use strict';
  const CELL=3, GAP=.72, RADIUS=.28;
  const cellKey=(x,z)=>Math.floor(x/CELL)+','+Math.floor(z/CELL);
  const active=p=>p && Number.isFinite(p.x) && Number.isFinite(p.z) &&
    !['inside','spouse_home','dining'].includes(p.state);
  function frame(people,colliders){
    const grid=new Map(), vehicles=[];
    for(const p of people)if(active(p)){
      const key=cellKey(p.x,p.z);let bucket=grid.get(key);
      if(!bucket){bucket=[];grid.set(key,bucket);}bucket.push(p);
    }
    for(const c of colliders||[])if(c.trafficBody &&
      Number.isFinite(c.minX)&&Number.isFinite(c.maxX)&&Number.isFinite(c.minZ)&&Number.isFinite(c.maxZ))vehicles.push(c);
    return {grid,vehicles};
  }
  function blockedByPeople(p,x,z,f){
    const gx=Math.floor(p.x/CELL),gz=Math.floor(p.z/CELL);
    for(let a=gx-1;a<=gx+1;a++)for(let b=gz-1;b<=gz+1;b++){
      const bucket=f.grid.get(a+','+b);if(!bucket)continue;
      for(const other of bucket){
        if(other===p)continue;
        const before=Math.hypot(p.x-other.x,p.z-other.z);
        const after=Math.hypot(x-other.x,z-other.z);
        if(after<GAP && (before>=GAP || after<=before+.000001))return true;
      }
    }
    return false;
  }
  function depth(x,z,c){
    const minX=c.minX-RADIUS,maxX=c.maxX+RADIUS,minZ=c.minZ-RADIUS,maxZ=c.maxZ+RADIUS;
    if(x<=minX||x>=maxX||z<=minZ||z>=maxZ)return -1;
    return Math.min(x-minX,maxX-x,z-minZ,maxZ-z);
  }
  function blockedByVehicles(p,x,z,f){
    for(const c of f.vehicles){
      const next=depth(x,z,c);if(next<0)continue;
      const current=depth(p.x,p.z,c);
      // Existing overlaps may move out, but not farther into a vehicle.
      if(current<0 || next>current+.000001)return true;
      const cx=(c.minX+c.maxX)/2,cz=(c.minZ+c.maxZ)/2;
      if((x-cx)**2+(z-cz)**2 <= (p.x-cx)**2+(p.z-cz)**2+.000001)return true;
    }
    return false;
  }
  function choose(p,tx,tz,speed,dt,f,signals){
    const dx=tx-p.x,dz=tz-p.z,d=Math.hypot(dx,dz);
    if(!Number.isFinite(d)||d<.000001)return {x:p.x,z:p.z,moved:false,arrived:true};
    // The main loop caps dt at 50ms. Also cap here to prevent test/lag tunnelling.
    const distance=Math.min(d,Math.max(0,speed)*Math.min(.05,Math.max(0,dt)));
    if(distance<=0)return {x:p.x,z:p.z,moved:false,arrived:false};
    const direction=Math.atan2(dz,dx);
    // Opposite-direction pedestrians consistently pass on their own right.
    const angles=[0,-Math.PI/5,Math.PI/5,-Math.PI/3,Math.PI/3,-Math.PI/2,Math.PI/2];
    for(const turn of angles){
      const x=p.x+Math.cos(direction+turn)*distance,z=p.z+Math.sin(direction+turn)*distance;
      if(blockedByPeople(p,x,z,f)||blockedByVehicles(p,x,z,f))continue;
      // Check only the selected safe candidate: the signal controller reserves
      // an active walker when it authorizes a crossing.
      if(signals && !signals.canPedestrianMove(p,x,z))return {x:p.x,z:p.z,moved:false,arrived:false};
      return {x,z,moved:true,arrived:turn===0 && distance>=d-.000001};
    }
    return {x:p.x,z:p.z,moved:false,arrived:false};
  }
  const api={frame,choose,GAP};
  if(root)root.MMS_PEDESTRIAN_STEERING=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:null);
