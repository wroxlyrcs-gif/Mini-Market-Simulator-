/* Construction menu translations; language order is tr, en, az, ru. */
(function(root){
  'use strict';
  const languages=['tr','en','az','ru'];
  const entries={
    title:['🛠 Yapı ve Eşya','🛠 Construction & Furniture','🛠 Tikinti və Əşyalar','🛠 Строительство и мебель'],
    editor:['🛠 Yerleştirme modu','🛠 Placement mode','🛠 Yerləşdirmə rejimi','🛠 Режим размещения'],
    ground:['Zemin kat','Ground floor','Birinci mərtəbə','Первый этаж'],
    upper:['2. kat','Upper floor','Üst mərtəbə','Верхний этаж'],
    rotate:['↻ Döndür','↻ Rotate','↻ Fırlat','↻ Повернуть'],
    cancel:['İptal','Cancel','Ləğv et','Отмена'],
    save:['✓ Kaydet','✓ Save','✓ Yadda saxla','✓ Сохранить'],
    help:['Eşya seçip plana dokun; yerleştirilmiş eşyayı sürükle. Başka kata taşımak için eşyayı seçip katı değiştir. Döndür ile 90° çevir. Gri alanlar mevcut engellerdir.','Choose an item and tap the plan; drag placed items. Select an item and change floors to move it. Rotate turns it 90°. Gray areas are existing obstacles.','Əşya seçib plana toxun; yerləşdirilmiş əşyanı sürüşdür. Başqa mərtəbəyə keçirmək üçün əşyanı seç və mərtəbəni dəyiş. Fırlat ilə 90° döndər. Boz sahələr maneələrdir.','Выберите предмет и нажмите на план; размещённые предметы можно перетаскивать. Для переноса выберите предмет и смените этаж. Поворот: 90°. Серые области заняты.'],
    shelf:['Ürün rafı','Product shelf','Məhsul rəfi','Товарная полка'],
    fridge:['Buzdolabı','Refrigerator','Soyuducu','Холодильник'],
    till:['Kasa','Checkout','Kassa','Касса'],
    table:['Masa','Table','Masa','Стол'],
    decor:['Dekorasyon / bitki','Decoration / plant','Dekor / bitki','Декор / растение'],
    capacity:['{n} birim stok kapasitesi','Capacity: {n} units','{n} ədəd stok tutumu','Вместимость: {n} ед.'],
    tillDesc:['Mevcut kasa ekranını açar','Opens the existing checkout screen','Mövcud kassa ekranını açır','Открывает текущую кассу'],
    decorDesc:['Dekoratif eşya','Decorative item','Dekorativ əşya','Декоративный предмет'],
    buy:['Satın al · {price} $','Buy · ${price}','Al · {price} $','Купить · {price} $'],
    balance:['Bakiye: {money} $ · Eşyalar envantere eklenir, ardından plana yerleştirilir.','Balance: ${money} · Items are added to inventory, then placed on the plan.','Balans: {money} $ · Əşyalar inventara əlavə olunur, sonra planda yerləşdirilir.','Баланс: {money} $ · Предметы добавляются в инвентарь, затем размещаются на плане.'],
    openEditor:['📐 Yerleştirme modunu aç','📐 Open placement mode','📐 Yerləşdirmə rejimini aç','📐 Открыть режим размещения'],
    built:['✓ 2. kat inşa edildi','✓ Upper floor built','✓ Üst mərtəbə tikildi','✓ Верхний этаж построен'],
    buildUpper:['🏗 2. kat inşa et · {price} $','🏗 Build upper floor · ${price}','🏗 Üst mərtəbəni tik · {price} $','🏗 Построить верхний этаж · {price} $'],
    stairsHelp:['Merdivene bakıp etkileşimle kat değiştir.','Look at the stairs and interact to change floors.','Pilləkənə baxıb qarşılıqlı əlaqə ilə mərtəbəni dəyiş.','Посмотрите на лестницу и взаимодействуйте с ней, чтобы сменить этаж.'],
    needsExpansion:['İkinci kat için önce “Marketi Büyüt” bölümünden arka alanı en az 2 kez genişlet.','For the upper floor, first expand the rear area at least twice under “Expand Market”.','Üst mərtəbə üçün əvvəlcə “Marketi Böyüt” bölməsində arxa sahəni ən azı iki dəfə genişləndir.','Для верхнего этажа сначала расширьте задний зал минимум дважды в разделе «Расширение».'],
    manual:['Yeni raflar elle doldurulur. Müşteriler mevcut alışveriş rotalarını ve ana kasayı kullanır.','New shelves are stocked manually. Customers use existing shopping routes and the main register.','Yeni rəflər əl ilə doldurulur. Müştərilər mövcud alış-veriş yollarından və əsas kassadan istifadə edir.','Новые полки заполняются вручную. Покупатели используют существующие маршруты и основную кассу.'],
    added:['{name} envantere eklendi.','{name} added to inventory.','{name} inventara əlavə olundu.','{name}: добавлено в инвентарь.'],
    dropBox:['Önce taşıdığın koliyi bırak.','Put down the box you are carrying first.','Əvvəlcə daşıdığın qutunu yerə qoy.','Сначала поставьте коробку, которую несёте.'],
    wentUp:['2. kata çıktın.','You went upstairs.','Üst mərtəbəyə qalxdın.','Вы поднялись наверх.'],
    wentDown:['Zemin kata indin.','You went downstairs.','Birinci mərtəbəyə endin.','Вы спустились на первый этаж.'],
    buildFirst:['Önce 2. katı inşa et.','Build the upper floor first.','Əvvəlcə üst mərtəbəni tik.','Сначала постройте верхний этаж.'],
    chooseFirst:['Önce bir eşya seç.','Choose an item first.','Əvvəlcə əşya seç.','Сначала выберите предмет.'],
    noSpace:['Bu yönde yeterli boş alan yok.','Not enough space in this direction.','Bu istiqamətdə kifayət qədər boş yer yoxdur.','В этом направлении недостаточно места.'],
    inventory:['Envanterde','In inventory','İnventarda','В инвентаре'],
    noItems:['Henüz eşya yok. Bilgisayardan satın al.','No items yet. Buy them on the computer.','Hələ əşya yoxdur. Kompüterdən al.','Предметов пока нет. Купите их через компьютер.'],
    chooseInventory:['Önce envanterden bir eşya seç.','Choose an item from inventory first.','Əvvəlcə inventardan əşya seç.','Сначала выберите предмет в инвентаре.'],
    valid:['Uygun konum.','Valid position.','Uyğun mövqe.','Подходящее место.'],
    invalid:['Bu alan dolu, geçiş yolu veya sınır dışında.','This area is occupied, blocks a passage, or is out of bounds.','Bu sahə doludur, keçid yoludur və ya sərhəddən kənardadır.','Это место занято, перекрывает проход или находится за пределами.']
  };
  function t(lang,key,vars){
    const index=Math.max(0,languages.indexOf(lang)),row=entries[key];
    let value=row&&row[index]||row&&row[0]||['Metin kullanılamıyor','Text unavailable','Mətn mövcud deyil','Текст недоступен'][index];
    if(vars)for(const name of Object.keys(vars))value=value.split('{'+name+'}').join(String(vars[name]));
    return value.replace(/\{[A-Za-z0-9_]+\}/g,'');
  }
  const api={entries,t,languages};
  if(root)root.MMS_BUILD_TRANSLATIONS=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:null);
