/* Yeni şehir katmanı: orijinal dosyalar değiştirilmez. */
(function () {
  'use strict';
  const g=window.__mms, T=window.THREE;
  if (!g || !T || window.__sehirYenilikleri) return;
  const w=g.world, regions=__req('player').REGIONS;
  // Serbest dolaşım bina, araç ve iç mekan çarpışmalarını kaldırmaz.
  regions.push({minX:-89,maxX:154,minZ:-27,maxZ:230});
  const group=new T.Group(); group.name='YENİ MAHALLE'; w.scene.add(group);
  function box(sx,sy,sz,x,y,z,color) {
    const m=w.b(sx,sy,sz,x,y,z,color,{parent:group,cast:false,receive:false});
    m.userData.static=true; return m;
  }
  // Kaldırımlar taşıt şeritlerinin dışında.
  for (const z of [182.7,197.1]) box(102,.055,1.7,96,.09,z,0xd9d0bf);
  for (const [x,z,length] of [[55,210,16],[77,210,16],[113,211,18],[140,213,22]])
    box(1.5,.04,length,x,.075,z,0xe4d8c5);
  const homes=[
    {x:55,z:222,wall:0xe5cfb8,roof:0x9a5645,trim:0x634b3e},
    {x:77,z:222,wall:0xcad6cf,roof:0x53706c,trim:0x3c5550},
    {x:113,z:224,wall:0xf1e0c4,roof:0x9b704a,trim:0x6c503e},
    {x:140,z:224,wall:0xcddbe2,roof:0x5b7589,trim:0x42586a}
  ];
  for (const h of homes) {
    box(8,3.6,6,h.x,0,h.z,h.wall); box(8.5,.35,6.5,h.x,3.6,h.z,h.roof);
    box(1.4,2.2,.12,h.x,.02,h.z-3.08,h.trim);
    for (const dx of [-2.4,2.4]) {
      box(1.45,1.15,.10,h.x+dx,1.35,h.z-3.08,0x8fc1cb);
      box(.07,1.2,.12,h.x+dx,1.33,h.z-3.16,h.trim);
    }
    box(2,.14,.9,h.x,2.3,h.z-3.35,h.roof);
    w.colliders.push({minX:h.x-4,maxX:h.x+4,minZ:h.z-3,maxZ:h.z+3});
  }
  w.mergeStatic(group);
  window.__sehirYenilikleri={homes:homes.length, regions:regions.length};
})();
