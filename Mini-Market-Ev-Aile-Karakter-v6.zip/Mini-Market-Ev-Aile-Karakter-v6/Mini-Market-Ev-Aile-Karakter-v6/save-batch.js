/* Aggregate background writes; important purchases and lifecycle events still save immediately. */
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.MMS_SAVE_BATCH=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  class SaveBatch {
    constructor(interval=1.5){this.interval=interval;this.pending=false;this.elapsed=0;}
    mark(){this.pending=true;}
    clear(){this.pending=false;this.elapsed=0;}
    advance(dt,save){
      if(!this.pending)return false;
      this.elapsed+=Math.max(0,Number.isFinite(dt)?dt:0);
      if(this.elapsed<this.interval)return false;
      this.elapsed=0;
      if(save()!==false)this.clear();
      return true;
    }
    flush(save){
      if(!this.pending)return false;
      if(save()!==false)this.clear();
      return true;
    }
  }
  return {SaveBatch};
});
