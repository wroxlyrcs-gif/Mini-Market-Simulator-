/* Low-cost surface detail and time-of-day lighting. No extra model downloads. */
(function () {
  'use strict';
  const g=window.__mms,T=window.THREE;
  if(!g||!T||!g.world||!g.scene||window.__mmsGraphicsPolish)return;
  const road=new Set([0x4a4f57,0x444a50,0x555b62]);
  const pavement=new Set([0xe3d3c4,0xe2d6c4,0xd9d4c8]);
  const plaster=new Set([0xf1e6d0,0xd8dfd5]);
  const glass=new Set([0x8fd4ed,0x9fd8f0,0x547482]);
  const textures={},clones=new Map(),glassMaterials=[];
  let surfaceCount=0,glassCount=0;
  let reflectionsOn=g.settings?.quality!=='low' && (!Number.isFinite(g._renderScale)||g._renderScale>=.72);
  function makeTexture(kind){
    const c=document.createElement('canvas');c.width=c.height=128;
    const ctx=c.getContext('2d');ctx.fillStyle='#f0f0f0';ctx.fillRect(0,0,128,128);
    let seed=kind==='road'?3241:kind==='pavement'?7547:9029;
    const rand=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
    const n=kind==='road'?1300:kind==='pavement'?500:450;
    for(let i=0;i<n;i++){
      const shade=kind==='road'?Math.floor(210+rand()*44):Math.floor(220+rand()*35);
      ctx.fillStyle=`rgb(${shade},${shade},${shade})`;
      const size=kind==='road'?1:1+rand()*1.5;ctx.fillRect(rand()*128,rand()*128,size,size);
    }
    if(kind==='pavement'){
      ctx.strokeStyle='rgba(145,145,145,.12)';ctx.lineWidth=1;
      for(let x=0;x<128;x+=32){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,128);ctx.stroke();}
      for(let y=0;y<128;y+=32){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(128,y);ctx.stroke();}
    }
    const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;
    t.repeat.set(kind==='plaster'?2:4,kind==='plaster'?2:4);
    t.colorSpace=T.SRGBColorSpace;t.anisotropy=Math.min(2,g.renderer.capabilities.getMaxAnisotropy());
    return t;
  }
  function texture(kind){return textures[kind]||(textures[kind]=makeTexture(kind));}
  function reflection(){
    if(textures.environment)return textures.environment;
    const faces=[];
    for(let i=0;i<6;i++){
      const c=document.createElement('canvas');c.width=c.height=32;
      const ctx=c.getContext('2d'),gradient=ctx.createLinearGradient(0,0,0,32);
      gradient.addColorStop(0,'#8bb8cf');gradient.addColorStop(.55,'#d4dfe0');gradient.addColorStop(1,'#788b80');
      ctx.fillStyle=gradient;ctx.fillRect(0,0,32,32);faces.push(c);
    }
    const t=new T.CubeTexture(faces);t.colorSpace=T.SRGBColorSpace;t.needsUpdate=true;
    return textures.environment=t;
  }
  g.scene.traverse(obj=>{
    if(!obj.isMesh||obj.isInstancedMesh||Array.isArray(obj.material))return;
    const m=obj.material;
    if(!m||!m.isMeshLambertMaterial||!m.color||m.map||(m.emissive && m.emissive.getHex()!==0))return;
    const hex=m.color.getHex();
    let type=road.has(hex)?'road':pavement.has(hex)?'pavement':plaster.has(hex)?'plaster':null;
    const glazing=glass.has(hex)&&m.transparent&&m.opacity<.8;
    if(!type&&!glazing)return;
    const key=m.uuid+':'+(glazing?'glass':type);
    let replacement=clones.get(key);
    if(!replacement){
      replacement=m.clone();
      if(glazing){const environment=reflection();replacement.envMap=reflectionsOn?environment:null;replacement.reflectivity=.14;replacement.combine=T.MixOperation;glassMaterials.push(replacement);}
      else replacement.map=texture(type);
      replacement.needsUpdate=true;clones.set(key,replacement);
    }
    obj.material=replacement;
    if(glazing)glassCount++;else surfaceCount++;
  });
  // Subtle golden-hour tint, applied to existing directional light only.
  const noon=new T.Color(0xfff4e0),evening=new T.Color(0xffba80),night=new T.Color(0xc4d9ff),temp=new T.Color();
  let timer=1;
  const original=g.world.update.bind(g.world);
  g.world.update=function(dt,...args){
    const result=original(dt,...args);
    timer+=Math.max(0,dt);
    if(timer>=.75 && g.state==='playing'){
      timer=0;
      const minutes=Number(g.clock?.minutes)||0;
      const sunset=Math.max(0,Math.min(1,(minutes-1020)/120))*Math.max(0,Math.min(1,(1260-minutes)/60));
      const darkness=Math.max(0,Math.min(1,(minutes-1200)/120));
      temp.copy(noon).lerp(evening,sunset*.55).lerp(night,darkness*.45);
      if(g.world.sun?.color)g.world.sun.color.copy(temp);
      const scale=Number.isFinite(g._renderScale)?g._renderScale:1;
      const turnOn=g.settings?.quality!=='low' && (reflectionsOn?scale>=.72:scale>=.86);
      if(turnOn!==reflectionsOn){
        reflectionsOn=turnOn;
        for(const material of glassMaterials){material.envMap=turnOn?textures.environment:null;material.needsUpdate=true;}
      }
    }
    return result;
  };
  window.__mmsGraphicsPolish={inspect:()=>({surfaceMeshes:surfaceCount,glassMeshes:glassCount,sharedMaterials:clones.size,sharedTextures:Object.keys(textures).length,reflectionsOn,reflection:'static environment approximation'})};
})();
