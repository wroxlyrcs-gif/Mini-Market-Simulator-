'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
class Obj {constructor(){this.children=[];this.position={x:0,y:0,z:0,set(x,y,z){Object.assign(this,{x,y,z})}};this.rotation={};this.userData={};}add(...items){this.children.push(...items)}}
class Color {setHex(c){this.value=c}} class Material {constructor(){this.color=new Color()}} class Mesh extends Obj{}
const THREE={Group:Obj,Mesh,MeshBasicMaterial:Material,SphereGeometry:class {}};
const world={scene:new Obj(),colliders:[],b(){return new Obj()},mergeStatic(){},update(){}};
const window={THREE,__cityTraffic:{},__mms:{world}},regions=[];const ctx={window,Math,Set,Map,__req:()=>({REGIONS:regions})};
vm.runInNewContext(fs.readFileSync('city-signals-yeni.js','utf8'),ctx);
const s=window.__trafficSignals;assert.equal(s.crossings.length,3);assert.ok(!s.crossings.some(c=>c.id==='market'));assert.ok(s.crossings.some(c=>c.id==='west'));
const lamps=world.scene.children.find(c=>c.name==='TRAFFIC SIGNALS');assert.equal(lamps.children.length,6);
for(const lamp of lamps.children){const {x,z}=lamp.position;assert.ok(!(z>8.2&&z<14.6&&x>-70&&x<147),'traffic light on arterial');assert.ok(!(x> -3.5&&x<3.5&&z>11.65&&z<41.1),'traffic light on avenue');assert.ok(!(x>31.5&&x<41.5&&z>66&&z<107),'traffic light on district road')}
s.step(21.5);const people=Array.from({length:5},(_,i)=>({id:'test'+i,x:-32.3,z:8}));
for(let i=0;i<4;i++){assert.equal(s.canPedestrianMove(people[i],-32.3,8.3),true);people[i].z=8.3}
assert.equal(s.canPedestrianMove(people[4],-32.3,8.3),false,'fifth pedestrian waits');
people[0].z=15;s.step(.1);assert.equal(s.canPedestrianMove(people[4],-32.3,8.3),true,'next pedestrian admitted after exit');
s.step(12);people[1].z=9;assert.equal(s.canPedestrianMove(people[1],-32.3,9.3),true,'pedestrian already on road can finish');
vm.runInNewContext(fs.readFileSync('sehir-yenilikleri.js','utf8'),ctx);
assert.equal(window.__sehirYenilikleri.homes,4);assert.ok(regions.some(r=>r.minX<=-89&&r.maxX>=154&&r.minZ<=-27&&r.maxZ>=230));
assert.ok(world.colliders.some(c=>c.minX===51&&c.maxX===59&&c.minZ===219&&c.maxZ===225));
const html=fs.readFileSync('mini-market-yeni-surum.html','utf8');assert.ok(html.includes("['B1', 'BW'], ['B', 'BW']"));assert.ok(!html.includes("['A', 'B'], ['B', 'BW']"));assert.ok(html.includes('city-signals-yeni.js')&&html.includes('sehir-yenilikleri.js'));
console.log('OK: kaldırımdaki ışıklar, dört yaya sınırı, güvenli geçiş, serbest alan ve ev çarpışmaları');
