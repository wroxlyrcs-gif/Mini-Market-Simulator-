/* Frame pacing and adaptive resolution. Simulation keeps its own existing tick. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) { root.MMS_PERFORMANCE_BUDGET = api; api.install(root); }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const valid = n => [30,45,60].includes(Number(n)) ? Number(n) : 60;
  class FramePacer {
    constructor(fps) { this.fps=valid(fps); this.last=null; }
    setFPS(fps) { this.fps=valid(fps); this.last=null; }
    shouldRender(now) {
      if(!Number.isFinite(now)) return true;
      if(this.last===null || now<this.last || now-this.last>1000){this.last=now;return true;}
      const interval=1000/this.fps, delta=now-this.last;
      if(delta+0.25<interval)return false;
      this.last+=Math.max(1,Math.floor((delta+.25)/interval))*interval;
      return true;
    }
  }
  class AdaptiveScale {
    constructor() { this.elapsed=0;this.frames=0;this.good=0;this.fps=0; }
    sample(dt,target,current) {
      if(!Number.isFinite(dt)||dt<=0||dt>2)return current;
      this.elapsed+=dt;this.frames++;
      if(this.elapsed<2.5)return current;
      const fps=this.frames/this.elapsed;this.fps=fps;this.elapsed=0;this.frames=0;
      target=valid(target);let next=current;
      if(fps<target*.78){next=Math.max(.5,current-.12);this.good=0;}
      else if(fps<target*.88){next=Math.max(.5,current-.06);this.good=0;}
      else if(fps>target*.96){if(++this.good>=4){next=Math.min(1,current+.04);this.good=0;}}
      else this.good=0;
      return next;
    }
    reset() {this.elapsed=0;this.frames=0;this.good=0;}
  }
  function install(win) {
    const g=win.__mms, doc=win.document;
    if(!g||!g.renderer||!doc||win.__mmsPerformance)return null;
    const key='mms_fps_limit_v1';
    const mobile=/Android|iPhone|iPad|iPod|Mobile/i.test(win.navigator?.userAgent||'');
    let preferred=mobile?30:60;
    try { const saved=win.localStorage.getItem(key);if(saved!==null&&saved!=='')preferred=valid(saved); } catch (_) {}
    const pacer=new FramePacer(preferred), adaptive=new AdaptiveScale();
    const renderer=g.renderer, draw=renderer.render.bind(renderer);
    let rendered=0,drawElapsed=0,measuredFPS=0,lastDraw=null;
    const clock=()=>win.performance.now();
    renderer.render=function(scene,camera){
      const now=clock();
      if(doc.hidden)return;
      if(g.state==='playing' && !pacer.shouldRender(now))return;
      if(g.state!=='playing')pacer.last=null;
      const result=draw(scene,camera);
      if(g.state==='playing'){
        if(lastDraw!==null && now>lastDraw && now-lastDraw<2000){drawElapsed+=(now-lastDraw)/1000;rendered++;}
        lastDraw=now;
        if(drawElapsed>=2.5){measuredFPS=rendered/drawElapsed;rendered=0;drawElapsed=0;}
      } else {lastDraw=null;rendered=0;drawElapsed=0;}
      return result;
    };
    g.samplePerformance=function(dt){
      if(this.state!=='playing'||doc.hidden||dt<=0||dt>2)return;
      const next=adaptive.sample(dt,preferred,this._renderScale);
      if(adaptive.fps>0)this._fps=adaptive.fps;
      if(Math.abs(next-this._renderScale)>.005){
        this._renderScale=next;this.applyQualityRatio();
        this.renderer.setSize(win.innerWidth,win.innerHeight,false);
      }
    };
    const titles={tr:'FPS sınırı',en:'FPS limit',az:'FPS limiti',ru:'Ограничение FPS'};
    let row=null,label=null,buttons=[];
    function syncUI(){
      if(label)label.textContent=titles[g.ui?.lang]||titles.en;
      for(const b of buttons){const on=Number(b.dataset.fps)===preferred;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));}
    }
    function selectFPS(n){
      preferred=valid(n);pacer.setFPS(preferred);adaptive.reset();lastDraw=null;rendered=0;drawElapsed=0;measuredFPS=0;
      try{win.localStorage.setItem(key,String(preferred));}catch(_){}
      syncUI();return preferred;
    }
    const quality=doc.getElementById('set-quality');
    if(quality && quality.parentElement){
      row=doc.createElement('div');row.className='row';
      label=doc.createElement('label');row.appendChild(label);
      const seg=doc.createElement('div');seg.className='seg';seg.setAttribute('role','group');
      for(const n of [30,45,60]){
        const b=doc.createElement('button');b.type='button';b.dataset.fps=String(n);b.textContent=String(n);
        b.addEventListener('click',()=>selectFPS(n));seg.appendChild(b);buttons.push(b);
      }
      row.appendChild(seg);quality.parentElement.insertAdjacentElement('afterend',row);
      syncUI();
      const setLanguage=g.ui.setLanguage.bind(g.ui);
      g.ui.setLanguage=function(...args){const r=setLanguage(...args);syncUI();return r;};
    }
    doc.addEventListener('visibilitychange',()=>{pacer.last=null;adaptive.reset();lastDraw=null;rendered=0;drawElapsed=0;});
    const info=()=>({
      targetFPS:preferred,renderedFPS:Math.round(measuredFPS*10)/10,engineFPS:Math.round(adaptive.fps*10)/10,
      renderScale:g._renderScale,pixelRatio:renderer.getPixelRatio(),quality:g.settings.quality,
      drawCalls:renderer.info?.render?.calls??null,triangles:renderer.info?.render?.triangles??null,
      geometries:renderer.info?.memory?.geometries??null,textures:renderer.info?.memory?.textures??null,
      jsHeapBytes:win.performance.memory?.usedJSHeapSize??null,
    });
    win.__mmsPerformance={setFPS:selectFPS,inspect:info};
    return win.__mmsPerformance;
  }
  return { FramePacer,AdaptiveScale,install };
});
