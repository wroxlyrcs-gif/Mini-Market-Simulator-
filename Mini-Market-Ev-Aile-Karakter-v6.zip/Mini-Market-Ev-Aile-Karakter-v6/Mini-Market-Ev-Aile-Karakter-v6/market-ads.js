/* v3.6: roadside market billboards with saved, editable ad copy. */
(function () {
  'use strict';
  const game = window.__mms;
  if (!game || !window.THREE || window.__marketAdsBuilt) return;
  window.__marketAdsBuilt = true;
  const T = window.THREE, world = game.world;
  const STORAGE = 'mms_billboards_v1';
  const DEFAULT_AD = 'SÜPER MARKET\nTAZE ÜRÜNLER • HER GÜN';
  const copy = {
    tr: {edit:'Reklam panosunu düzenle',title:'Market reklamını düzenle',hint:'Pano başına en fazla 60 karakter. Reklam tüm panolara değil, bu panoya kaydedilir.',save:'Panoya uygula',cancel:'İptal',placeholder:'Örn. SÜPER MARKET\nTAZE ÜRÜNLER • HER GÜN',presets:'Hazır metinler',saved:'Reklam panoya yerleştirildi.'},
    en: {edit:'Edit market billboard',title:'Edit market advertisement',hint:'Up to 60 characters per board. Your ad is saved to this board only.',save:'Apply to board',cancel:'Cancel',placeholder:'e.g. SUPERMARKET\nFRESH GOODS • EVERY DAY',presets:'Quick text',saved:'Ad saved to billboard.'},
    az: {edit:'Market reklam lövhəsini redaktə et',title:'Market reklamını redaktə et',hint:'Hər lövhə üçün maksimum 60 simvol. Mətn yalnız bu lövhədə saxlanılır.',save:'Lövhəyə tətbiq et',cancel:'Ləğv et',placeholder:'Məs. SUPERMARKET\nHƏR GÜN TƏZƏ MƏHSUL',presets:'Hazır mətnlər',saved:'Reklam lövhədə saxlanıldı.'},
    ru: {edit:'Изменить рекламный щит',title:'Изменить рекламу магазина',hint:'До 60 символов на щит. Объявление сохраняется только на этом щите.',save:'Применить',cancel:'Отмена',placeholder:'Напр. СУПЕРМАРКЕТ\nСВЕЖИЕ ПРОДУКТЫ • КАЖДЫЙ ДЕНЬ',presets:'Готовые тексты',saved:'Реклама сохранена на щите.'}
  };
  const presets = {
    tr: [DEFAULT_AD,'ŞEHRİNİN MARKETİ\nARADIĞIN HER ŞEY BURADA','MARKETİMİZE BEKLERİZ\nKAPI AÇIK, ALIŞVERİŞ KOLAY'],
    en: ['SUPERMARKET\nFRESH GOODS • EVERY DAY','YOUR NEIGHBORHOOD MARKET\nEVERYTHING YOU NEED','COME ON IN\nEASY SHOPPING STARTS HERE'],
    az: ['SUPERMARKET\nHƏR GÜN TƏZƏ MƏHSUL','MƏHƏLLƏ MARKETİNİZ\nAxtardığınız hər şey burada','BUYURUN\nRahat alış-veriş buradan başlayır'],
    ru: ['СУПЕРМАРКЕТ\nСВЕЖИЕ ПРОДУКТЫ • КАЖДЫЙ ДЕНЬ','МАГАЗИН РЯДОМ С ДОМОМ\nВсё необходимое здесь','ЗАХОДИТЕ\nПокупки стали проще']
  };
  let ads = [];
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE) || '[]');
    if (Array.isArray(saved)) ads = saved.slice(0,4).map(v => String(v || '').slice(0,60));
  } catch (_) {}
  let active = null, panel = null;
  const boards = [];
  const staticGroup = new T.Group(); world.scene.add(staticGroup);
  const markStatic = mesh => { mesh.userData.static = true; return mesh; };
  function box(w,h,d,x,y,z,color) {
    return markStatic(world.b(w,h,d,x,y,z,color,{parent:staticGroup,cast:false,receive:false}));
  }
  function boardTexture(text) {
    const canvas=document.createElement('canvas'); canvas.width=1024; canvas.height=512;
    const ctx=canvas.getContext('2d');
    const tex=new T.CanvasTexture(canvas);
    if (T.SRGBColorSpace) tex.colorSpace=T.SRGBColorSpace;
    tex.anisotropy=world._textureAnisotropy||2;
    tex._canvas=canvas; tex._ctx=ctx;
    draw(ctx,canvas,text);
    return tex;
  }
  function wrapLines(ctx,text,maxWidth,maxLines) {
    const words=String(text||'').replace(/\r/g,'').split(/\s+/).filter(Boolean);
    const lines=[]; let line='';
    for(const word of words) {
      const test=line?line+' '+word:word;
      if(ctx.measureText(test).width<=maxWidth || !line) line=test;
      else { lines.push(line); line=word; }
    }
    if(line)lines.push(line);
    if(lines.length>maxLines){lines.length=maxLines;lines[maxLines-1]=lines[maxLines-1].replace(/[ .•]+$/,'')+'…';}
    return lines;
  }
  function draw(ctx,canvas,text) {
    const w=canvas.width,h=canvas.height;
    ctx.clearRect(0,0,w,h);
    // A genuinely blank board until the player buys/sets copy on the computer.
    if(!String(text||'').trim()){ctx.fillStyle='#e0ded4';ctx.fillRect(0,0,w,h);return;}
    ctx.fillStyle='#122a43'; ctx.fillRect(0,0,w,h);
    ctx.fillStyle='#e2bd67'; ctx.fillRect(0,0,w,22); ctx.fillRect(0,h-22,w,22);
    ctx.strokeStyle='#f2d98b'; ctx.lineWidth=16; ctx.strokeRect(18,18,w-36,h-36);
    ctx.fillStyle='#f4cf6a'; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.font='900 32px Arial, sans-serif'; ctx.fillText('ZUNEX  •  SUPERMARKET',w/2,78);
    const clean=String(text||DEFAULT_AD).slice(0,60).replace(/[<>]/g,'');
    const custom=clean.split('\n').map(x=>x.trim()).filter(Boolean).slice(0,3);
    const lines=custom.length?custom:wrapLines(ctx,clean,w-112,3);
    const count=Math.max(1,lines.length), font=count===1?94:count===2?76:62, gap=count===1?0:82;
    ctx.fillStyle='#ffffff'; ctx.shadowColor='#0008'; ctx.shadowBlur=4;
    ctx.font=`900 ${font}px Arial, sans-serif`;
    const startY=h/2-(count-1)*gap/2+10;
    lines.forEach((line,i)=>{
      let value=line;
      while(ctx.measureText(value).width>w-112 && value.length>3)value=value.slice(0,-2).trimEnd()+'…';
      ctx.fillText(value,w/2,startY+i*gap,w-112);
    });
    ctx.shadowBlur=0;
    ctx.fillStyle='#e7e1d5'; ctx.font='700 22px Arial, sans-serif'; ctx.fillText('WELCOME  •  XOŞ GƏLDİNİZ  •  ДОБРО ПОЖАЛОВАТЬ',w/2,h-51);
  }
  function buildBoard(cfg,index) {
    const {x,z,yaw,label}=cfg, width=9.2,height=4.3,centerY=5.7;
    // Steel supports and frame rotate with the billboard face, keeping the roadside structure coherent.
    const postColor=0x33424d, frameColor=0x22313b, ca=Math.cos(yaw),sa=Math.sin(yaw);
    const frame=(sx,sy,sz,lx,ly,lz,color)=>{
      const px=x+lx*ca+lz*sa, pz=z-lx*sa+lz*ca;
      const mesh=box(sx,sy,sz,px,ly,pz,color);mesh.rotation.y=yaw;return mesh;
    };
    frame(.34,6.1,.28,-width*.37,0,0,postColor);
    frame(.34,6.1,.28,width*.37,0,0,postColor);
    frame(width+.3,.28,.34,0,centerY+height/2+.15,0,frameColor);
    frame(width+.3,.28,.34,0,centerY-height/2-.15,0,frameColor);
    frame(.28,height+.3,.34,-width/2-.15,centerY,0,frameColor);
    frame(.28,height+.3,.34,width/2+.15,centerY,0,frameColor);
    frame(width*.72,.16,1.0,0,2.85,.3,0x52616b);
    for(const dx of [-.35,.35]) frame(.16,.5,.18,dx,3.2,.3,0x6e7c83);
    const texture=boardTexture(ads[index]||'');
    const material=new T.MeshBasicMaterial({map:texture,side:T.DoubleSide,toneMapped:false});
    const face=new T.Mesh(world.geo('plane'),material);
    face.scale.set(width,height,1);face.position.set(x,centerY,z);face.rotation.y=yaw;
    face.castShadow=false;face.receiveShadow=false;face.userData.dynamicBillboard=true;world.scene.add(face);
    const ad={index,label,texture,face,text:ads[index]||'',position:{x,z},yaw};
    boards.push(ad);
    // Solid support posts, so players and vehicles cannot pass through them.
    for(const dx of [-width*.37,width*.37]){
      const px=x+dx*ca,pz=z-dx*sa;
      world.colliders.push({minX:px-.24,maxX:px+.24,minZ:pz-.24,maxZ:pz+.24,marketBillboard:true});
    }
  }
  // Candidates are open verge plots, not the road, sidewalks or building footprints.
  // Validate the whole ground footprint against existing solid scenery and other boards.
  const plots=[
    {label:'Batı çevre yolu',yaw:0,candidates:[[-65,-32],[-50,-32],[-35,-32],[-20,-32]]},
    {label:'Doğu çevre yolu',yaw:0,candidates:[[65,-32],[80,-32],[95,-32],[110,-32]]},
    {label:'Güney çevre yolu',yaw:0,candidates:[[65,104],[82,104],[100,104],[120,104]]},
    {label:'Şehir çıkışı',yaw:Math.PI/2,candidates:[[23,145],[23,160],[23,175],[23,205]]}
  ];
  const occupied=[];
  const overlaps=(a,b)=>a.minX<b.maxX&&a.maxX>b.minX&&a.minZ<b.maxZ&&a.maxZ>b.minZ;
  plots.forEach((plot,index)=>{
    for(const [x,z] of plot.candidates){
      const across=Math.abs(Math.cos(plot.yaw))>.5;
      const rect={minX:x-(across?5.3:1.3),maxX:x+(across?5.3:1.3),minZ:z-(across?1.3:5.3),maxZ:z+(across?1.3:5.3)};
      if(world.colliders.some(c=>overlaps(rect,c))||occupied.some(c=>overlaps(rect,c)))continue;
      occupied.push(rect);buildBoard({x,z,yaw:plot.yaw,label:plot.label},index);break;
    }
  });
  world.mergeStatic(staticGroup);
  window.__marketBillboardsMap=boards.map(b=>({x0:b.position.x-1,x1:b.position.x+1,z0:b.position.z-1,z1:b.position.z+1,c:'#d1ad57',l:'Reklam Panosu',e:'📣'}));
  function language(){return copy[game.ui?.lang] ? game.ui.lang : 'tr';}
  function ensurePanel() {
    if(panel)return panel;
    const style=document.createElement('style');
    style.textContent='#market-ad-ui{position:fixed;inset:0;z-index:130;background:rgba(8,15,24,.72);display:none;align-items:center;justify-content:center;padding:14px;color:#fff;font:600 15px system-ui,sans-serif}#market-ad-ui.open{display:flex}#market-ad-ui .panel{width:min(490px,96vw);max-height:88vh;overflow:auto;background:#15263a;border:2px solid #d7b354;border-radius:16px;padding:18px;box-shadow:0 18px 55px #0009}#market-ad-ui h2{margin:0 0 6px;font-size:21px}#market-ad-ui p{line-height:1.42;opacity:.82;margin:7px 0 12px}#market-ad-ui textarea{box-sizing:border-box;width:100%;resize:vertical;min-height:86px;border:1px solid #718094;border-radius:10px;padding:11px;background:#f7f4eb;color:#172536;font:700 17px system-ui,sans-serif}#market-ad-ui .preset-title{margin:13px 0 6px;color:#e7cf8c}#market-ad-ui .preset{width:100%;text-align:left;background:#243a52;color:#fff;border:1px solid #52657b;border-radius:9px;padding:9px 11px;margin:3px 0;font:600 14px system-ui;white-space:pre-line}#market-ad-ui .actions{display:flex;gap:9px;margin-top:12px}#market-ad-ui button{cursor:pointer}#market-ad-ui .actions button{flex:1;border:0;border-radius:9px;padding:12px;font:800 15px system-ui}#market-ad-ui .save{background:#e2bd67;color:#182331}#market-ad-ui .cancel{background:#dfe4e7;color:#182331}#market-ad-ui .count{display:block;text-align:right;opacity:.72;font-size:12px;margin-top:3px}';
    document.head.appendChild(style);
    panel=document.createElement('div');panel.id='market-ad-ui';
    panel.innerHTML='<div class="panel"><h2></h2><p class="hint"></p><textarea maxlength="60" rows="2"></textarea><span class="count"></span><div class="preset-title"></div><div class="presets"></div><div class="actions"><button class="cancel"></button><button class="save"></button></div></div>';
    document.body.appendChild(panel);
    for(const ev of ['pointerdown','touchstart','mousedown','click'])panel.addEventListener(ev,e=>e.stopPropagation());
    panel.addEventListener('click',e=>{if(e.target===panel)close();});
    panel.querySelector('.cancel').addEventListener('click',close);
    panel.querySelector('.save').addEventListener('click',save);
    panel.querySelector('textarea').addEventListener('input',updateCount);
    return panel;
  }
  function updateCount(){if(panel)panel.querySelector('.count').textContent=`${panel.querySelector('textarea').value.length}/60`;}
  function open(ad){
    active=ad;const el=ensurePanel(),lang=language(),strings=copy[lang];
    el.querySelector('h2').textContent=strings.title+' · '+ad.label;
    el.querySelector('.hint').textContent=strings.hint;
    el.querySelector('textarea').value=ad.text;
    el.querySelector('textarea').placeholder=strings.placeholder;
    el.querySelector('.preset-title').textContent=strings.presets;
    el.querySelector('.cancel').textContent=strings.cancel;el.querySelector('.save').textContent=strings.save;
    const list=el.querySelector('.presets');list.replaceChildren();
    (presets[lang]||presets.tr).forEach(value=>{const b=document.createElement('button');b.className='preset';b.textContent=value;b.addEventListener('click',()=>{el.querySelector('textarea').value=value;updateCount();});list.appendChild(b);});
    el.classList.add('open');updateCount();
  }
  function close(){if(panel)panel.classList.remove('open');active=null;}
  function save(){
    if(!active)return;
    const text=String(panel.querySelector('textarea').value||'').trim().slice(0,60);
    active.text=text;draw(active.texture._ctx,active.texture._canvas,text);active.texture.needsUpdate=true;
    ads[active.index]=text;
    try{localStorage.setItem(STORAGE,JSON.stringify(ads));}catch(_){}
    const msg=copy[language()].saved;game.ui?.toast?.({tr:msg,en:msg,az:msg,ru:msg}[language()]||msg);
    close();
    if(game.depot.site.isOpen&&game.depot.site.page==='ads')game.depot.site.render(true);
  }
  // Add the board selector to the existing in-market computer rather than
  // requiring the player to walk to a billboard.
  const {SiteUI}=__req('site');
  const previousNav=SiteUI.prototype._renderNav;
  SiteUI.prototype._renderNav=function(){
    previousNav.call(this);
    const names={tr:'Reklam panoları',en:'Billboards',az:'Reklam lövhələri',ru:'Рекламные щиты'};
    this.$nav.insertAdjacentHTML('beforeend',`<button data-act="nav" data-v="ads" class="${this.page==='ads'?'on':''}">📣 ${names[language()]}</button>`);
  };
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  SiteUI.prototype.p_ads=function(){
    const lang=language(),labels={
      tr:['Reklam panoları','Pano seçip reklam yaz. Metni silersen pano yeniden boş kalır.','Boş pano','Düzenle'],
      en:['Billboards','Choose a board and write an ad. Clear the text to leave it blank.','Blank board','Edit'],
      az:['Reklam lövhələri','Lövhə seçib reklam yaz. Mətni silsən lövhə boş qalacaq.','Boş lövhə','Redaktə'],
      ru:['Рекламные щиты','Выберите щит и напишите рекламу. Удалите текст, чтобы очистить щит.','Пустой щит','Изменить']
    }[lang];
    return `<div class="pc-box"><h3>📣 ${labels[0]}</h3><p class="pc-muted">${labels[1]}</p>${boards.map(b=>`<div class="pc-row"><span><b>${esc(b.label)}</b><br><small>${esc(b.text||labels[2])}</small></span><button class="pc-btn pri sm" data-act="ad-edit" data-board="${b.index}">${labels[3]}</button></div>`).join('')}</div>`;
  };
  game.depot.site.root.addEventListener('click',e=>{
    const button=e.target.closest('[data-act="ad-edit"]');
    if(!button)return;
    const board=boards.find(b=>b.index===Number(button.dataset.board));
    if(board)open(board);
  });
  window.__marketAds={boards,open,inspect:()=>boards.map(b=>({index:b.index,label:b.label,text:b.text,position:b.position})),presets};
})();
