/* The second store reuses the game's DepotSystem, SiteUI, MarketBuild and worker features.
   Its data and local coordinates are isolated from the first store. */
(function () {
  'use strict';
  const g = window.__mms, T = window.THREE;
  if (!g || !T || !window.__MMS_CREATE_MARKET_BUILD || !window.__MMS_CREATE_WORKERS_FEATURE) return;
  window.__MMS_SECOND_DEPOT_ACTIVE = true;

  const { DepotSystem } = __req('depot');
  const { Save, defaultGameData, sanitizeGame } = __req('save');
  const { PRODUCTS, getProduct } = __req('products');
  const { FIXTURES, accepts } = __req('fixtures');
  const { cleanCounts } = __req('logistics');
  const { LINES, levelOf, effectsFor, backDepth, sanitizeUpgrades, canBuy, totalLevels, totalSpent } = __req('expand');
  const { sanitizeWorkers } = __req('workers');
  const { SiteUI } = __req('site');

  const DATA_KEY = 'mms_citymarket_depot_v1';
  const OWN_KEY = 'mms_citymarket_v1';
  const CENTER = { x: 51, z: 73 };
  const localToWorld = p => ({ x: CENTER.x - p.x, y: p.y || 0, z: CENTER.z - p.z });
  const worldToLocal = p => ({ x: CENTER.x - p.x, y: p.y || 0, z: CENTER.z - p.z });
  const read = key => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (_) { return null; } };
  const text = {
    tr: { locked:'Önce Süper Marketi satın al.', pc:'💻 İkinci market bilgisayarı', storage:'📦 İkinci market deposu', register:'🧾 İkinci market kasası', shelf:'Raf stoğu', balance:'Market bakiyesi', growth:'🏗 Marketi Büyüt' },
    en: { locked:'Buy the Supermarket first.', pc:'💻 Second Market computer', storage:'📦 Second Market stockroom', register:'🧾 Second Market register', shelf:'Shelf stock', balance:'Market balance', growth:'🏗 Expand Market' },
    az: { locked:'Əvvəlcə supermarketi alın.', pc:'💻 İkinci market kompüteri', storage:'📦 İkinci market anbarı', register:'🧾 İkinci market kassası', shelf:'Rəf ehtiyatı', balance:'Market balansı', growth:'🏗 Marketi böyüt' },
    ru: { locked:'Сначала купите супермаркет.', pc:'💻 Компьютер второго магазина', storage:'📦 Склад второго магазина', register:'🧾 Касса второго магазина', shelf:'Запас на полке', balance:'Баланс магазина', growth:'🏗 Расширить магазин' },
  };
  const tx = k => (text[g.ui.lang] || text.tr)[k] || k;
  const owned = () => read(OWN_KEY)?.owned === true;
  const fixtureNames = (id, tr, en, az, ru) => ({ id, name: { tr, en, az, ru } });
  const secondFixtures = [
    { ...fixtureNames('m2s_shelf1','Raf A · Ön','Shelf A · Front','Rəf A · Ön','Полка A · Перед'), type:'shelf', cap:56, baseCap:56 },
    { ...fixtureNames('m2s_shelf2','Raf B · Ön','Shelf B · Front','Rəf B · Ön','Полка B · Перед'), type:'shelf', cap:56, baseCap:56 },
    { ...fixtureNames('m2s_shelf3','Raf A · Arka','Shelf A · Rear','Rəf A · Arxa','Полка A · Задняя'), type:'shelf', cap:56, baseCap:56 },
    { ...fixtureNames('m2s_shelf4','Raf B · Arka','Shelf B · Rear','Rəf B · Arxa','Полка B · Задняя'), type:'shelf', cap:56, baseCap:56 },
    { ...fixtureNames('m2s_shelf5','Yan reyon','Side display','Yan bölmə','Боковая полка'), type:'shelf', cap:32, baseCap:32 },
    { ...fixtureNames('m2s_fruitstand','Meyve standı','Fruit stand','Meyvə stendi','Фруктовый стенд'), type:'fruit', cap:48, baseCap:48 },
    { ...fixtureNames('m2s_fridge1','Soğutucu A','Cooler A','Soyuducu A','Холодильник A'), type:'fridge', cap:36, baseCap:36 },
    { ...fixtureNames('m2s_fridge2','Soğutucu B','Cooler B','Soyuducu B','Холодильник B'), type:'fridge', cap:36, baseCap:36 },
  ];
  window.__MMS_REGISTER_MARKET_FIXTURES(secondFixtures);

  const saved = read(DATA_KEY);
  const legacy = read('mms_citymarket_stockworker_v4') || read('mms_citymarket_shelves_v3') || read('mms_citymarket_products_v2') || {};
  const data = sanitizeGame(saved || defaultGameData());
  data.money = saved && Number.isFinite(saved.money) ? saved.money : 500;
  data.upgrades = sanitizeUpgrades(saved?.upgrades);
  data.marketBuild = saved?.marketBuild && typeof saved.marketBuild === 'object'
    ? saved.marketBuild : { upper:false, items:[], seq:1 };
  data.workers = sanitizeWorkers(saved?.workers, data.day);
  data.secondMarketSales = Math.max(0, Math.floor(Number(saved?.secondMarketSales) || Number(legacy.sales) || 0));
  const rawFixtures = saved?.fixtures || {};
  data.fixtures = {};
  for (const f of secondFixtures) data.fixtures[f.id] = cleanCounts(rawFixtures[f.id]);
  for (const item of Array.isArray(data.marketBuild.items) ? data.marketBuild.items : []) {
    if (item && /^m2_build_[0-9]+$/.test(item.id)) data.fixtures[item.id] = cleanCounts(rawFixtures[item.id]);
  }
  if (!saved && Array.isArray(legacy.products)) {
    for (const p of legacy.products) {
      if (!p || !PRODUCTS.some(x => x.id === p.id)) continue;
      data.stock[p.id] = (data.stock[p.id] || 0) + Math.max(0, Math.floor(Number(p.reserve) || 0));
      let qty = Math.max(0, Math.floor(Number(p.shelf) || 0));
      const targets = p.id === 'milk' || p.id === 'yogurt' || p.id === 'eggs' ? ['m2s_fridge1','m2s_fridge2'] : ['m2s_shelf1','m2s_shelf2','m2s_shelf3','m2s_shelf4','m2s_fruitstand'];
      for (const id of targets) {
        const f = secondFixtures.find(x => x.id === id);
        const product = getProduct(p.id);
        if (!f || !accepts(f, product) || qty <= 0) continue;
        const take = Math.min(qty, f.cap);
        data.fixtures[id][p.id] = (data.fixtures[id][p.id] || 0) + take;
        qty -= take;
      }
      if (qty > 0) data.stock[p.id] += qty;
    }
  } else if (!saved) {
    Object.assign(data.fixtures.m2s_shelf1, { water:8, bread:8 });
    Object.assign(data.fixtures.m2s_shelf2, { chips:8, chocolate:8 });
    Object.assign(data.fixtures.m2s_fridge1, { milk:8, yogurt:8 });
    Object.assign(data.fixtures.m2s_fruitstand, { apple:8 });
  }

  let secondUpper = null;
  const secondRoot = new T.Group();
  secondRoot.name = 'SECOND MARKET SYSTEM ROOT';
  secondRoot.position.set(CENTER.x, 0, CENTER.z);
  secondRoot.rotation.y = Math.PI;
  g.scene.add(secondRoot);

  const localToGlobalCollider = new WeakMap();
  const globalToLocalCollider = new WeakMap();
  const rawColliders = g.world.colliders;
  function localCollider(c) {
    let l=globalToLocalCollider.get(c);
    if(!l){l={...c};globalToLocalCollider.set(c,l);localToGlobalCollider.set(l,c);}
    Object.assign(l,c);
    l.minX=CENTER.x-c.maxX;l.maxX=CENTER.x-c.minX;
    l.minZ=CENTER.z-c.maxZ;l.maxZ=CENTER.z-c.minZ;
    return l;
  }
  const colliderSnapshot=()=>rawColliders.map(localCollider);
  const localColliders = new Proxy([], {
    get(_target, prop) {
      if (prop === 'length') return rawColliders.length;
      if (prop === Symbol.iterator) return function* () { for(const c of rawColliders)yield localCollider(c); };
      if (typeof prop === 'string' && /^\d+$/.test(prop)) { const c=rawColliders[Number(prop)];return c?localCollider(c):undefined; }
      if (prop === 'push') return (...items) => {
        for (const l of items) {
          if (localToGlobalCollider.has(l)) { rawColliders.push(localToGlobalCollider.get(l)); continue; }
          const c = { ...l, minX:CENTER.x-l.maxX, maxX:CENTER.x-l.minX, minZ:CENTER.z-l.maxZ, maxZ:CENTER.z-l.minZ };
          localToGlobalCollider.set(l,c); globalToLocalCollider.set(c,l); rawColliders.push(c);
        }
        return rawColliders.length;
      };
      if (prop === 'indexOf') return item => rawColliders.indexOf(localToGlobalCollider.get(item) || item);
      if (prop === 'includes') return item => rawColliders.includes(localToGlobalCollider.get(item) || item);
      if (prop === 'splice') return (start, count, ...items) => {
        const loc = colliderSnapshot(), removed = loc.slice(start, start + count);
        for (const l of removed) { const i = rawColliders.indexOf(localToGlobalCollider.get(l) || l); if (i >= 0) rawColliders.splice(i,1); }
        if (items.length) {
          const actual = items.map(l => {
            if (localToGlobalCollider.has(l)) return localToGlobalCollider.get(l);
            const c = { ...l, minX:CENTER.x-l.maxX, maxX:CENTER.x-l.minX, minZ:CENTER.z-l.maxZ, maxZ:CENTER.z-l.minZ };
            localToGlobalCollider.set(l,c); globalToLocalCollider.set(c,l); return c;
          });
          rawColliders.splice(start,0,...actual);
        }
        return removed;
      };
      const list = colliderSnapshot();
      if (prop === 'filter') return fn => list.filter(fn);
      if (prop === 'map') return fn => list.map(fn);
      if (prop === 'some') return fn => list.some(fn);
      if (prop === 'every') return fn => list.every(fn);
      if (prop === 'find') return fn => list.find(fn);
      if (prop === 'forEach') return fn => list.forEach(fn);
      return Reflect.get(_target, prop);
    },
  });
  const world2 = Object.create(g.world);
  world2.root = secondRoot;
  world2.scene = g.scene;
  world2.colliders = localColliders;
  world2.hitboxes = g.world.hitboxes;
  world2.extCeil = { visible:true };

  let camera2;
  const position2 = {
    set(x,y,z) { g.camera.position.set(CENTER.x-x,y,CENTER.z-z); return this; },
    get x() { return CENTER.x-g.camera.position.x; }, get y() { return g.camera.position.y; }, get z() { return CENTER.z-g.camera.position.z; },
  };
  const rotation2 = {
    set(x,y,z) { g.camera.rotation.set(x,y+Math.PI,z); return this; },
    get x() { return g.camera.rotation.x; }, get y() { return g.camera.rotation.y-Math.PI; }, get z() { return g.camera.rotation.z; },
  };
  camera2 = new Proxy(g.camera, {
    get(target, key) {
      if (key === 'position') return position2;
      if (key === 'rotation') return rotation2;
      if (key === 'add' || key === 'remove') return target[key].bind(target);
      const value = Reflect.get(target,key,target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
  const scene2 = {
    add(...objects) { for (const o of objects) if (o === camera2 || o === g.camera) g.scene.add(g.camera); else secondRoot.add(o); return this; },
    remove(...objects) { for (const o of objects) { if (o === camera2 || o === g.camera) g.scene.remove(g.camera); else if (o?.parent) o.parent.remove(o); } return this; },
  };
  const player2 = Object.create(g.player);
  Object.defineProperties(player2, {
    pos: { get: () => worldToLocal(g.player.pos) },
    vel: { get: () => ({ get x(){return -g.player.vel.x;}, set x(v){g.player.vel.x=-v;}, get z(){return -g.player.vel.z;}, set z(v){g.player.vel.z=-v;} }) },
    marketUpper: {
      get: () => secondUpper,
      set: value => {
        secondUpper = value;
        if (!value) { g.player.marketUpper = null; return; }
        const b = value.bounds;
        g.player.marketUpper = {
          bounds:{minX:CENTER.x-b.maxX,maxX:CENTER.x-b.minX,minZ:CENTER.z-b.maxZ,maxZ:CENTER.z-b.minZ},
          colliders:(value.colliders||[]).map(c=>({ ...c,minX:CENTER.x-c.maxX,maxX:CENTER.x-c.minX,minZ:CENTER.z-c.maxZ,maxZ:CENTER.z-c.minZ })),
        };
      },
    },
  });
  player2.setPosition = (x,z) => g.player.setPosition(CENTER.x-x,CENTER.z-z);
  const fpsCam2 = {
    get yaw(){return g.fpsCam.yaw-Math.PI;}, set yaw(v){g.fpsCam.yaw=v+Math.PI;},
    get pitch(){return g.fpsCam.pitch;}, set pitch(v){g.fpsCam.pitch=v;},
    get eyeHeight(){return g.fpsCam.eyeHeight;}, set eyeHeight(v){g.fpsCam.eyeHeight=v;},
    get sens(){return g.fpsCam.sens;}, set sens(v){g.fpsCam.sens=v;},
    get invertY(){return g.fpsCam.invertY;}, set invertY(v){g.fpsCam.invertY=v;},
    setAngles(yaw,pitch){return g.fpsCam.setAngles(yaw+Math.PI,pitch);},
    update(dt,pos,speed){return g.fpsCam.update(dt,pos?localToWorld(pos):pos,speed);},
  };
  const game2 = {
    scene:scene2, world:world2, camera:camera2, player:player2, fpsCam:fpsCam2,
    ui:g.ui, audio:g.audio, clock:g.clock, settings:g.settings, controls:g.controls,
    data, marketBuildIdPrefix:'m2_build_',
    get state(){return g.state;}, set state(v){g.state=v;},
    setInputLocked:on=>g.setInputLocked(on),
    saveNow:saveSecond,
  };

  const { buildDepotComputer } = __req('pcmodel');
  const depotZone = { minX:-6.9,maxX:-3.5,minZ:-4.9,maxZ:-1.5 };
  const pcModel = buildDepotComputer(world2,{position:{x:6.05,z:-2.2},depotZone,id:'second-market-pc'});
  const secondDepot = new DepotSystem({
    scene:scene2,world:world2,camera:camera2,player:player2,fpsCam:fpsCam2,ui:g.ui,audio:g.audio,clock:g.clock,
    lockInput:on=>g.setInputLocked(on),requestSave:saveSecond,pcModel,depotZone,
    deliveryOptions:{toLocal:p=>worldToLocal(p),avoidTraffic:false,roadZ:7.4,parkX:-4.0,startX:-34,endX:36,curbZ:8.45},
  });
  secondDepot.lg.fixtureFilter=f=>f.id.startsWith('m2s_')||f.id.startsWith('m2_build_');
  game2.depot=secondDepot;
  window.__ikinciMarketComputer=secondDepot;
  const buildFeature = window.__MMS_CREATE_MARKET_BUILD(game2,{owner:'second',idPrefix:'m2_build_'});
  game2.marketBuild=buildFeature;
  buildFeature.attach(data);
  secondDepot.attach(data);
  secondDepot.marketBuild=buildFeature;
  secondDepot.site.marketBuild=buildFeature;

  function buildExpansion(depth) {
    if (window.__MMS_SECOND_MARKET_EXTENSION) {
      for (const c of window.__MMS_SECOND_MARKET_EXTENSION.colliders) { const i=localColliders.indexOf(c); if(i>=0)localColliders.splice(i,1); }
      if(window.__MMS_SECOND_MARKET_EXTENSION.group.parent)window.__MMS_SECOND_MARKET_EXTENSION.group.parent.remove(window.__MMS_SECOND_MARKET_EXTENSION.group);
    }
    const group=new T.Group();group.name='SECOND MARKET REAR EXPANSION';secondRoot.add(group);
    const colliders=[];
    const b=(sx,sy,sz,x,y,z,color,collide=false)=>{
      world2.b(sx,sy,sz,x,y,z,color,{parent:group,cast:false,receive:true});
      if(collide){const c={minX:x-sx/2,maxX:x+sx/2,minZ:z-sz/2,maxZ:z+sz/2};localColliders.push(c);colliders.push(c);}
    };
    if(depth>0){
      const z0=-5.2,z1=-5.2-depth,mid=(z0+z1)/2;
      b(14,.1,depth,0,-.02,mid,0xe4dece);
      b(.22,4.4,depth,-6.9,0,mid,0xf1e6d0,true); b(.22,4.4,depth,6.9,0,mid,0xf1e6d0,true);
      b(14,4.4,.22,0,0,z1,0xf1e6d0,true);
      const roof=new T.Group();group.add(roof);
      world2.b(14.2,.22,depth,0,4.4,mid,0x5a5f66,{parent:roof,cast:false,receive:false});
      window.__MMS_SECOND_MARKET_EXTENSION={group,colliders,roof};
    } else {
      // Keep the rear doorway sealed until the first expansion is purchased.
      b(4,4.4,.24,0,0,-5.2,0xf1e6d0,true);
      window.__MMS_SECOND_MARKET_EXTENSION={group,colliders,roof:null};
    }
    if(window.__MMS_SECOND_MARKET_ROOF)window.__MMS_SECOND_MARKET_ROOF.visible=!data.marketBuild.upper;
    if(window.__MMS_SECOND_MARKET_EXTENSION.roof)window.__MMS_SECOND_MARKET_EXTENSION.roof.visible=!data.marketBuild.upper;
    buildFeature.rebuild();
  }

  const exp=__req('expand'), CFG=__req('logistics').CFG, baseExpand=g.expand;
  const secondExpand=Object.create(baseExpand);
  secondExpand.g=game2;secondExpand.data=data;secondExpand.speed=1;
  secondExpand.applyWorld=depth=>buildExpansion(depth);
  secondExpand.prepare=d=>{d.upgrades=sanitizeUpgrades(d.upgrades);};
  secondExpand.attach=d=>{secondExpand.data=d;secondExpand.speed=effectsFor(d.upgrades).speed;applySecondEffects();};
  secondExpand.reset=()=>{secondExpand.data=null;secondExpand.speed=1;};
  secondExpand.update=dt=>{if(!secondExpand.data||secondExpand.speed<=1)return;const c=secondDepot.customers;if(c&&c.enabled&&c.spawnT>1)c.spawnT=Math.max(1,c.spawnT-dt*(secondExpand.speed-1));};
  const cfgBase={departDelay:CFG.departDelay,travelBase:CFG.travelBase,maxOrderUnits:CFG.maxOrderUnits,maxLineQty:CFG.maxLineQty};
  const withSecondConfig=fn=>{
    const e=effectsFor(data.upgrades);
    const old={departDelay:CFG.departDelay,travelBase:CFG.travelBase,maxOrderUnits:CFG.maxOrderUnits,maxLineQty:CFG.maxLineQty};
    Object.assign(CFG,{departDelay:e.depart,travelBase:e.travel,maxOrderUnits:e.order,maxLineQty:e.line});
    try{return fn();}finally{Object.assign(CFG,old);}
  };
  for(const method of ['quote','placeOrder']){
    const original=secondDepot.lg[method].bind(secondDepot.lg);
    secondDepot.lg[method]=(...args)=>withSecondConfig(()=>original(...args));
  }
  const site=secondDepot.site;
  const siteRender=site.render.bind(site);
  site.render=function(force){return withSecondConfig(()=>siteRender(force));};
  const siteClick=site._click.bind(site);
  site._click=function(e){return withSecondConfig(()=>siteClick(e));};
  const siteChange=site._change.bind(site);
  site._change=function(e){return withSecondConfig(()=>siteChange(e));};
  const siteInput=site._input.bind(site);
  site._input=function(e){return withSecondConfig(()=>siteInput(e));};
  site._etaFor=boxes=>withSecondConfig(()=>CFG.departDelay+CFG.travelBase+boxes*CFG.travelPerBox);

  function applySecondEffects(){
    const e=effectsFor(data.upgrades);
    secondExpand.speed=e.speed;
    for(const f of FIXTURES)if(f.id.startsWith('m2s_')||f.id.startsWith('m2_build_'))f.cap=Math.round((f.baseCap||f.cap)*e.mult);
    buildExpansion(e.depth);
  }
  const primaryUpgrade=g.expand.buyLine.bind(g.expand);
  g.expand.buyLine=function(...args){const r=primaryUpgrade(...args);applySecondEffects();return r;};
  const nameKey={shelf:'Shelf',ads:'Ads',cargo:'Cargo',back:'Back',wholesale:'Whole'};
  secondExpand.tabHTML=function(){
    if(!this.data)return '';
    const d=this.data,t=this.t,money=Math.floor(d.money),ownFx=FIXTURES.filter(f=>f.id.startsWith('m2s_')||f.id.startsWith('m2_build_'));
    const cap=ownFx.reduce((n,f)=>n+f.cap,0);
    const cards=LINES.map(l=>{
      const lv=levelOf(d.upgrades,l.id),check=canBuy(d,l.id),pips='●'.repeat(lv)+'○'.repeat(3-lv);
      const action=check.reason==='max'?`<span class="pc-badge ok">${t('xMax')}</span>`:`<button class="pc-btn pri sm" data-act="m2-e-buy" data-line="${l.id}" ${check.ok?'':'disabled'}>${t('xBuy',{n:check.cost})}</button>`;
      return `<div class="ex-card"><span class="ex-ico">${l.emoji}</span><span class="ex-info"><span><b>${t('x'+nameKey[l.id]+'Name')}</b> <span class="ex-pips">${pips}</span> <small>${t('xLevel',{n:lv,m:3})}</small></span><small>${t('x'+nameKey[l.id]+'Desc')}</small><span class="ex-now">${t('xNow',{eff:this._effText(l.id,lv)})}</span>${lv<3?`<span class="ex-next">${t('xNext',{eff:this._effText(l.id,lv+1)})}</span>`:''}</span><span class="ex-buy">${action}</span></div>`;
    }).join('');
    return `<section class="pc-stats"><div><small>${t('xStatLevel')}</small><b>${1+totalLevels(d.upgrades)}</b></div><div><small>${t('xStatSpent')}</small><b>${totalSpent(d.upgrades)} $</b></div><div><small>${t('xStatCap')}</small><b>${cap}</b></div><div><small>${t('xStatBalance')}</small><b>${money} $</b></div></section><div class="pc-box"><h3>🏗 ${t('xTitle')}</h3>${cards}</div><p class="pc-muted">${t('xNote')}</p>`;
  };
  secondExpand.buyLine=function(lineId){
    const check=canBuy(data,lineId),t=this.t;
    if(!check.ok){g.audio.play('error');if(check.reason==='money')site._snack(t('xNoMoney',{n:check.missing}));return;}
    data.money-=check.cost;data.upgrades=sanitizeUpgrades(data.upgrades);data.upgrades.push(lineId+(check.level+1));
    applySecondEffects();secondDepot.dirty=true;saveSecond();g.audio.play('cash');
    g.ui.toast(t('xBoughtToast',{name:t('x'+nameKey[lineId]+'Name'),n:check.level+1}),2600);
    if(site.isOpen)site.render(true);
  };
  secondExpand.navButton=baseExpand.navButton.bind(secondExpand);
  secondDepot.site.expandFeature=secondExpand;
  secondExpand.data=data;applySecondEffects();
  site.root.addEventListener('click',e=>{const b=e.target.closest('[data-act="m2-e-buy"]');if(b&&!b.disabled)secondExpand.buyLine(b.dataset.line);});

  const spot={x:-4.3,z:4.1};
  const homes={stocker:{x:5.5,z:-3.2},cleaner:{x:5.2,z:3.0}};
  let secondWorkers=null;
  try {
    secondWorkers=window.__MMS_CREATE_WORKERS_FEATURE(game2,{spot,block:{minX:-4.7,maxX:-4.0,minZ:3.8,maxZ:4.4},homes,idleHeading:Math.atan2(4.8-spot.x,2.7-spot.z)});
    game2.workers=secondWorkers;secondDepot.site.workersFeature=secondWorkers;secondWorkers.attach(data);
  } catch(err) { console.warn('Second market staff UI:',err); }

  const addHit=(id,label,box,action)=>world2.addInteractable({id,label,box,action});
  const labels={tr:s=>s,en:s=>s,az:s=>s,ru:s=>s};
  const staticHit=[
    ['m2_shelf1','m2s_shelf1',1.4,.8,8.4,1.8,1.1],
    ['m2_shelf2','m2s_shelf2',-3.8,.8,3.2,1.8,1.1],
    ['m2_shelf3','m2s_shelf3',1.4,-2.4,8.4,1.8,1.1],
    ['m2_shelf4','m2s_shelf4',-3.8,-2.4,3.2,1.8,1.1],
    ['m2_shelf5','m2s_shelf5',4.8,0,2.8,1.8,1.4],
    ['m2_fruit','m2s_fruitstand',4.8,3.1,3.4,1.7,1.4],
    ['m2_fridge1','m2s_fridge1',2.5,-5.2,5.0,2.0,1.2],
    ['m2_fridge2','m2s_fridge2',-2.5,-5.2,5.0,2.0,1.2],
  ];
  const fxById=id=>FIXTURES.find(f=>f.id===id);
  for(const [hitId,fid,x,z,sx,sy,sz] of staticHit){
    const f=fxById(fid);
    addHit(hitId,{tr:'🗄️ '+f.name.tr,en:'🗄️ '+f.name.en,az:'🗄️ '+f.name.az,ru:'🗄️ '+f.name.ru},[sx,sy,sz,x,0,z],()=>{});
  }
  addHit('m2_storage',{tr:tx('storage'),en:tx('storage'),az:tx('storage'),ru:tx('storage')},[1.4,1.8,1.4,-5.5,0,-3.5],()=>secondDepot.openPanel('depot'));
  addHit('m2_register',{tr:tx('register'),en:tx('register'),az:tx('register'),ru:tx('register')},[3.2,1.8,1.4,-4.3,0,4.1],()=>secondDepot.openCashier());
  const originalResolve=g.depot.resolveAction.bind(g.depot);
  g.depot.resolveAction=function(cur){
    if(secondDepot.carriedId)return secondDepot.resolveAction(cur);
    if(cur&&cur.id==='second-market-pc')return {key:'second-pc',label:cur.label,run:()=>owned()?secondDepot.openSite():g.ui.toast(tx('locked'))};
    if(cur&&cur.id==='m2_storage')return {key:cur.id,label:cur.label,run:()=>secondDepot.openPanel('depot')};
    if(cur&&cur.id==='m2_register')return {key:cur.id,label:cur.label,run:()=>secondDepot.openCashier()};
    if(cur&&/^m2_shelf|^m2_fruit|^m2_fridge/.test(cur.id)){
      const map={m2_shelf1:'m2s_shelf1',m2_shelf2:'m2s_shelf2',m2_shelf3:'m2s_shelf3',m2_shelf4:'m2s_shelf4',m2_shelf5:'m2s_shelf5',m2_fruit:'m2s_fruitstand',m2_fridge1:'m2s_fridge1',m2_fridge2:'m2s_fridge2'};
      return secondDepot.resolveAction({...cur,id:map[cur.id]});
    }
    if(cur&&cur.boxId&&secondDepot.boxes.has(cur.boxId))return secondDepot.resolveAction(cur);
    if(cur&&/^m2_build_[0-9]+$/.test(cur.id))return secondDepot.resolveAction(cur);
    return originalResolve(cur);
  };
  // v6: üst kat açılınca merdivenin önündeki soğutucu rafı otomatik kalkar; soğutucu etkileşimleri kalan kısma taşınır.
  const fridgeHits={f1:world2.hitboxes.find(h=>h.userData.interactable&&h.userData.interactable.id==='m2_fridge1'),f2:world2.hitboxes.find(h=>h.userData.interactable&&h.userData.interactable.id==='m2_fridge2')};
  let coolerState=null;
  function syncCooler(){
    const b=(buildFeature.data&&buildFeature.data.marketBuild)||data.marketBuild;
    const up=!!(b&&b.upper);
    if(up===coolerState)return;
    coolerState=up;
    if(window.__MMS_SECOND_COOLER)window.__MMS_SECOND_COOLER.apply(up);
    const set=(h,x,w)=>{if(h){h.position.x=x;h.scale.x=w;}};
    if(up){set(fridgeHits.f1,-3.0,2.0);set(fridgeHits.f2,-4.9,2.0);}else{set(fridgeHits.f1,2.5,5.0);set(fridgeHits.f2,-2.5,5.0);}
  }
  const origRebuild=buildFeature.rebuild.bind(buildFeature);
  buildFeature.rebuild=function(...a){const r=origRebuild(...a);syncCooler();return r;};
  syncCooler();
  const primaryAttach=g.depot.attach.bind(g.depot);
  const dirtySave=new window.MMS_SAVE_BATCH.SaveBatch(1.5);
  let cachedOwned=owned(),ownCheckElapsed=0;
  g.depot.attach=function(mainData){
    const result=primaryAttach(mainData);
    data.day=mainData.day;secondDepot.attach(data);buildFeature.attach(data);secondDepot.marketBuild=buildFeature;
    secondDepot.site.marketBuild=buildFeature;secondExpand.attach(data);if(secondWorkers)secondWorkers.attach(data);
    return result;
  };
  const primaryReset=g.depot.reset.bind(g.depot);
  g.depot.reset=function(){dirtySave.flush(saveSecond);const result=primaryReset();secondDepot.closeOverlays();secondDepot.reset();buildFeature.reset();if(secondWorkers)secondWorkers.reset();secondExpand.reset();return result;};
  const primaryClose=g.depot.closeOverlays.bind(g.depot);
  g.depot.closeOverlays=function(){primaryClose();secondDepot.closeOverlays();};
  const primaryUpdate=g.depot.update.bind(g.depot);
  g.depot.update=function(dt,speed){
    const result=primaryUpdate(dt,speed);
    syncCooler();
    data.day=g.data?.day||data.day;
    ownCheckElapsed+=Math.max(0,dt);
    if(ownCheckElapsed>=1){ownCheckElapsed=0;cachedOwned=owned();}
    if(cachedOwned&&g.state==='playing'){
      secondDepot.customers.enabled=!data.shopClosed;
      secondDepot.update(dt,speed);
      secondExpand.update(dt);
      if(secondWorkers)secondWorkers.update(dt);
      if(secondDepot.consumeDirty())dirtySave.mark();
      dirtySave.advance(dt,saveSecond);
    }
    return result;
  };
  const primaryLanguage=g.depot.onLanguage.bind(g.depot);
  g.depot.onLanguage=function(){const r=primaryLanguage();secondDepot.onLanguage();if(site.isOpen){site.retext();site.render(true);}if(buildFeature.editor.classList.contains('open'))buildFeature.updateEditor();if(secondWorkers)secondWorkers.onLanguage();return r;};
  const primarySave=g.saveNow.bind(g);
  g.saveNow=function(...args){const r=primarySave(...args);saveSecond();return r;};

  window.__MMS_SECOND_MARKET_LEDGER={credit(n){if(!Number.isFinite(n)||n<=0)return;data.money+=Math.floor(n);saveSecond();if(site.isOpen)site.render(false);}};
  window.__ikinciMarket={inspect:()=>({owned:owned(),money:data.money,stock:{...data.stock},fixtures:data.fixtures,upgrades:[...data.upgrades],build:data.marketBuild,workers:data.workers,activeOrders:secondDepot.lg.activeOrders().length}),open:()=>owned()?secondDepot.openSite():g.ui.toast(tx('locked'))};

  function saveSecond(){
    try{data.marketBuild=buildFeature.data?.marketBuild||data.marketBuild;data.workers=secondWorkers?.data?.workers||data.workers;localStorage.setItem(DATA_KEY,JSON.stringify(data));dirtySave.clear();return true;}catch(_){return false;}
  }
  window.addEventListener('pagehide',saveSecond);
  if(owned()){data.day=g.data?.day||data.day;saveSecond();}
})();
