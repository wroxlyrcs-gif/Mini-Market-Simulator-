/* Existing map labels: Turkish key -> tr/en/az/ru, no new locations. */
(function(root){
  'use strict';
  const labels={
    'Mahalle':['Mahalle','Neighborhood','Məhəllə','Район'],
    'Şehir Merkezi':['Şehir Merkezi','City Center','Şəhər mərkəzi','Центр города'],
    'Park':['Park','Park','Park','Парк'],
    'Basketbol':['Basketbol','Basketball','Basketbol','Баскетбол'],
    'Market':['Market','Market','Market','Магазин'],
    'Ev':['Ev','Home','Ev','Дом'],
    'Oyuncu':['Oyuncu','Player','Oyunçu','Игрок'],
    'Otobüs durakları':['Otobüs durakları','Bus stops','Avtobus dayanacaqları','Автобусные остановки'],
    'Lokanta':['Lokanta','Restaurant','Restoran','Ресторан'],
    'Casino':['Casino','Casino','Kazino','Казино'],
    'Kafe':['Kafe','Café','Kafe','Кафе'],
    'Stadyum':['Stadyum','Stadium','Stadion','Стадион'],
    'Yeni Bölge':['Yeni Bölge','New District','Yeni rayon','Новый район'],
    'ZUNEX CARS':['ZUNEX CARS','ZUNEX CARS','ZUNEX CARS','ZUNEX CARS'],
    'Süper Market':['Süper Market','Supermarket','Supermarket','Супермаркет'],
    'GYM':['GYM','Gym','İdman zalı','Спортзал'],
    'Kuleler':['Kuleler','Towers','Qüllələr','Башни'],
    'CITY MALL':['CITY MALL','CITY MALL','CITY MALL','CITY MALL'],
    'Hastane':['Hastane','Hospital','Xəstəxana','Больница'],
    'Otel':['Otel','Hotel','Otel','Отель'],
    'Okul':['Okul','School','Məktəb','Школа'],
    'Benzin':['Benzin','Gas station','Yanacaqdoldurma','Заправка'],
    'Oto Servis':['Oto Servis','Auto repair','Avtoservis','Автосервис'],
    'Şehir Parkı':['Şehir Parkı','City Park','Şəhər parkı','Городской парк'],
    'Futbol Sahası':['Futbol Sahası','Football field','Futbol meydançası','Футбольное поле'],
    'Polis Karakolu':['Polis Karakolu','Police station','Polis bölməsi','Полицейский участок'],
    'Otopark':['Otopark','Parking','Avtodayanacaq','Парковка'],
    'Market Otoparkı':['Market Otoparkı','Market parking','Market dayanacağı','Парковка магазина'],
    'Reklam Panosu':['Reklam Panosu','Billboard','Reklam lövhəsi','Рекламный щит'],
    'Batı Mahallesi':['Batı Mahallesi','West Neighborhood','Qərb məhəlləsi','Западный район'],
    'Doğu Bulvarı':['Doğu Bulvarı','East Boulevard','Şərq bulvarı','Восточный бульвар'],
    'Doğu Çevre Yolu':['Doğu Çevre Yolu','East Ring Road','Şərq dairəvi yolu','Восточная кольцевая'],
    'Kuzey Çevre Yolu':['Kuzey Çevre Yolu','North Ring Road','Şimal dairəvi yolu','Северная кольцевая']
  };
  const headings={title:['🗺️ Şehir Haritası ✕','🗺️ City Map ✕','🗺️ Şəhər xəritəsi ✕','🗺️ Карта города ✕'],close:['Kapatmak için dokun','Tap to close','Bağlamaq üçün toxun','Нажмите, чтобы закрыть']};
  const languages=['tr','en','az','ru'];
  function get(lang,row){const i=languages.indexOf(lang);return row[i<0?0:i]||row[0];}
  const api={labels,headings,place:(lang,key)=>labels[key]?get(lang,labels[key]):key,heading:(lang,key)=>headings[key]?get(lang,headings[key]):''};
  if(root)root.MMS_MAP_TRANSLATIONS=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:null);
