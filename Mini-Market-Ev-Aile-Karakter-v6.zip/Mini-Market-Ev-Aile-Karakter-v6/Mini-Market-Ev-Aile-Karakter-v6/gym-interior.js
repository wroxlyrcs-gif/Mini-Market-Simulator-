/* 4.0 stage 2: enterable compact gym with usable equipment and saved progress. */
(function () {
  'use strict';
  const game=window.__mms,T=window.THREE,people=window.__mmsPeople;
  if(!game||!T||!people||window.__gym)return;
  const w=game.world,{Save}=__req('save');
  const labels={
    tr:{door:'Spor salonu kapısı',doorBlocked:'Kapı kapanmadan önce biraz uzaklaş.',reception:'Resepsiyon: antrenmanlarım',
      info:'Tamamlanan antrenman: {n} · Su: {d}',treadmill:'Koşu bandını kullan',bike:'Bisiklete bin',bench:'Bench press yap',
      squat:'Squat yap',dumbbells:'Dambıl çalış',water:'Su al · 5 $',waterDone:'Su aldın · 5 $',noMoney:'Su için 5 $ gerekli.',
      locker:'Dolabı aç / kapat',shower:'Duşu aç / kapat',started:'Egzersiz sürüyor',done:'Antrenman tamamlandı!',cancel:'Bırak',seconds:'sn',exercising:'Antrenman',exit:'Bırak'},
    en:{door:'Gym door',doorBlocked:'Move away before closing the door.',reception:'Reception: my workouts',
      info:'Completed workouts: {n} · Water: {d}',treadmill:'Use treadmill',bike:'Ride exercise bike',bench:'Use bench press',
      squat:'Use squat rack',dumbbells:'Lift dumbbells',water:'Buy water · $5',waterDone:'Water purchased · $5',noMoney:'Water costs $5.',
      locker:'Open / close locker',shower:'Turn shower on / off',started:'Workout in progress',done:'Workout complete!',cancel:'Stop',seconds:'sec',exercising:'Workout',exit:'Stop'},
    az:{door:'İdman zalının qapısı',doorBlocked:'Qapını bağlamaq üçün uzaqlaş.',reception:'Resepsiyon: məşqlərim',
      info:'Tamamlanan məşq: {n} · Su: {d}',treadmill:'Qaçış trenajorundan istifadə et',bike:'Velotrenajora min',bench:'Ştanqla məşq et',
      squat:'Çömbəlmə məşqi et',dumbbells:'Qantellə məşq et',water:'Su al · 5 $',waterDone:'Su alındı · 5 $',noMoney:'Su üçün 5 $ lazımdır.',
      locker:'Dolabı aç / bağla',shower:'Duşu aç / bağla',started:'Məşq davam edir',done:'Məşq tamamlandı!',cancel:'Dayandır',seconds:'san',exercising:'Məşq',exit:'Dayandır'},
    ru:{door:'Дверь спортзала',doorBlocked:'Отойдите от двери, прежде чем закрыть её.',reception:'Ресепшен: мои тренировки',
      info:'Завершено тренировок: {n} · Вода: {d}',treadmill:'Беговая дорожка',bike:'Велотренажёр',bench:'Жим лёжа',
      squat:'Приседания',dumbbells:'Упражнение с гантелями',water:'Купить воду · 5 $',waterDone:'Вода куплена · 5 $',noMoney:'Для воды нужно 5 $.',
      locker:'Открыть / закрыть шкаф',shower:'Включить / выключить душ',started:'Тренировка продолжается',done:'Тренировка завершена!',cancel:'Остановить',seconds:'сек',exercising:'Тренировка',exit:'Остановить'}
  };
  const text=(key,vars={})=>{
    let value=(labels[game.ui.lang]||labels.tr)[key]||labels.en[key]||key;
    for(const [k,v] of Object.entries(vars))value=value.replaceAll('{'+k+'}',String(v));
    return value;
  };
  const L=key=>Object.fromEntries(Object.keys(labels).map(lang=>[lang,labels[lang][key]]));
  const clean=raw=>{
    const num=x=>Number.isFinite(Number(x))?Math.max(0,Math.min(1000000,Math.floor(Number(x)))):0;
    return {workouts:num(raw?.workouts),drinks:num(raw?.drinks),
      byKind:Object.fromEntries(['treadmill','bike','bench','squat','dumbbells'].map(k=>[k,num(raw?.byKind?.[k])]))};
  };
  const oldLoad=Save.load.bind(Save),oldNew=Save.createNew.bind(Save);
  Save.load=function(){
    const d=oldLoad();let raw=null;
    try{raw=JSON.parse(localStorage.getItem('mms_save_v1')||'null');}catch(_){}
    d.gym=clean(raw?.gym);return d;
  };
  Save.createNew=function(){const d=oldNew();d.gym=clean(null);return d;};
  const group=new T.Group();group.name='GYM INTERIOR';w.scene.add(group);
  function box(sx,sy,sz,x,y,z,color,parent=group){
    const m=w.b(sx,sy,sz,x,y,z,color,{parent,cast:false,receive:false});
    if(parent===group)m.userData.static=true;return m;
  }
  function solid(x,z,sx,sz){w.colliders.push({minX:x-sx/2,maxX:x+sx/2,minZ:z-sz/2,maxZ:z+sz/2,gym:true});}
  // Hollow shell, windows and a clearly unobstructed doorway.
  box(8.35,.08,9.8,63.75,.045,72,0x3c4650);
  for(const [x,z,sx,sz] of [[59.52,72,.18,10],[67.98,72,.18,10],[63.75,76.92,8.5,.18],
      [61.10,67,3.2,.18],[66.40,67,3.2,.18]]){
    box(sx,4,sz,x,0,z,0x6485a0);solid(x,z,sx,sz);
  }
  box(2.1,1.05,.18,63.75,2.65,67,0x6485a0);
  box(8.25,.08,.12,63.75,.07,76.79,0xd0a850);
  MMS_NIGHT.light(w,63.75,3.3,72,0xffe8c4,3,14);
  // Rubber flooring, broad exercise lanes and overhead strips.
  for(const x of [61.0,63.1,65.2,67.1])box(.035,.012,9.35,x,.13,72,0x596575);
  for(const x of [61.0,63.75,66.5])box(1.35,.045,.18,x,3.65,72,0xf4f0d8);
  // Glass panel slides to the right. The invisible barrier tracks its state.
  const glassMat=new T.MeshLambertMaterial({color:0x9bd6e3,transparent:true,opacity:.45,depthWrite:false});
  const door=new T.Mesh(w.geo('box'),glassMat);door.scale.set(1.95,2.55,.1);door.position.set(63.75,1.275,67);w.scene.add(door);
  const doorCollider={minX:62.77,maxX:64.73,minZ:66.90,maxZ:67.10,gymDoor:true};
  w.colliders.push(doorCollider);
  let doorTarget=0,doorOffset=0;
  function toggleDoor(){
    const p=game.player.pos;
    if(doorTarget>0&&Math.abs(p.x-63.75)<1.32&&Math.abs(p.z-67)<.8){game.ui.toast(text('doorBlocked'));return false;}
    doorTarget=doorTarget?0:1;return true;
  }
  function hit(id,key,x,z,sx,sz,action){
    w.addInteractable({id,label:L(key),box:[sx,2,sz,x,0,z],action});
  }
  hit('gym-door','door',63.75,67,2.2,.9,toggleDoor);
  // Reception, drinking water, changing lockers and shower alcove.
  box(1.3,.95,.55,65.5,0,67.95,0x8a674a);solid(65.5,67.95,1.3,.55);
  box(.8,.08,.4,65.5,.95,67.95,0xe5d0a1);
  hit('gym-reception','reception',65.5,68.35,1.3,.75,()=>{
    const d=game.data?.gym||clean(null);game.ui.toast(text('info',{n:d.workouts,d:d.drinks}),3500);
  });
  box(.65,1.6,.6,67.32,0,68.25,0xd1dce1);solid(67.32,68.25,.65,.6);
  box(.42,.38,.03,67.32,1.03,67.93,0x305d7a);
  hit('gym-water','water',67.32,68.25,.8,.75,()=>{
    if(!game.data)return false;
    if(game.data.money<5){game.ui.toast(text('noMoney'));return false;}
    game.data.money-=5;game.data.gym=clean(game.data.gym);game.data.gym.drinks++;
    game.saveNow();game.audio.play('cash');game.ui.toast(text('waterDone'));return true;
  });
  for(const x of [64.8,65.52,66.24,66.96]){
    box(.64,1.9,.5,x,0,76.58,0x6f7d85);
    box(.52,.04,.025,x,1.5,76.30,0xb9c8cc);
  }
  solid(65.88,76.58,2.8,.52);
  const locker=new T.Group();locker.position.set(64.47,.03,76.3);w.scene.add(locker);
  box(.58,1.84,.05,.3,0,0,0x92a3a8,locker);
  let lockerOpen=false;
  hit('gym-locker','locker',64.8,76.25,.8,.6,()=>{lockerOpen=!lockerOpen;locker.rotation.y=lockerOpen?1.05:0;});
  // Small changing/shower nook. It is usable, not a separate simulated room.
  box(1.65,.08,1.2,60.55,.13,76.15,0xc8d4d4);
  box(.05,2.25,1.22,61.38,0,76.15,0x9ab8bd);solid(61.38,76.15,.05,1.22);
  box(.08,1.75,.08,60.45,.45,76.69,0xb6c4c6);
  box(.52,.06,.15,60.45,2.24,76.44,0xb6c4c6);
  const drops=new T.Group();w.scene.add(drops);
  for(let i=0;i<7;i++)box(.025,.42,.025,60.22+i*.075,1.65-(i%2)*.12,76.38,0x79d6ed,drops);
  drops.visible=false;
  hit('gym-shower','shower',60.55,76.2,1.0,.9,()=>{drops.visible=!drops.visible;});
  // Non-reflective mirror panel: a mobile-friendly visual approximation.
  box(.04,2.05,2.0,67.83,.65,72.4,0x9db5bd);
  box(.05,.08,2.15,67.79,2.75,72.4,0xd6e5e7);

  const machines={};
  function treadmill(x,z,id){
    box(1.25,.24,2.1,x,.12,z,0x293a46);solid(x,z,1.25,2.1);
    box(.98,.055,1.68,x,.39,z,0x171f28);
    box(.08,1.2,.08,x-.49,.35,z-.77,0x8b999e);box(.08,1.2,.08,x+.49,.35,z-.77,0x8b999e);
    box(1.08,.12,.16,x,1.47,z-.77,0x253e4b);box(.65,.18,.12,x,1.5,z-.81,0x4bb3b0);
    const belt=new T.Group();belt.position.set(x,.43,z);w.scene.add(belt);
    for(const zz of [-.6,0,.6])box(.85,.02,.035,0,0,zz,0x677777,belt);
    machines[id]={x,z,belt};
  }
  treadmill(61.0,70.35,'treadmill');
  treadmill(61.0,73.12,'npcTreadmill');
  hit('gym-treadmill','treadmill',61.0,70.35,1.4,2.0,()=>start('treadmill'));
  // Exercise bike with rotating pedals.
  box(.85,.13,1.35,62.4,.08,75.12,0x394650);solid(62.4,75.12,.85,1.35);
  box(.12,.75,.12,62.4,.2,75.22,0x829295);box(.5,.12,.32,62.4,.95,75.36,0x202a32);
  box(.08,1.0,.08,62.4,.22,74.72,0x829295);box(.56,.08,.08,62.4,1.15,74.72,0x293d46);
  const pedals=new T.Group();pedals.position.set(62.4,.45,75);w.scene.add(pedals);
  box(.75,.08,.08,0,0,0,0xd8ad4b,pedals);machines.bike={x:62.4,z:75.12,pedals};
  hit('gym-bike','bike',62.4,75.12,1.1,1.4,()=>start('bike'));
  // Bench press with a moving bar.
  box(1.65,.18,.60,65.55,.62,70.3,0x394b58);solid(65.55,70.3,1.65,.68);
  for(const x of [64.9,66.2])box(.10,1.55,.10,x,.05,69.95,0x89999c);
  const bar=new T.Group();bar.position.set(65.55,1.45,69.95);w.scene.add(bar);
  box(1.9,.06,.06,0,0,0,0xd6ded8,bar);for(const x of [-.8,.8])box(.20,.42,.40,x,-.18,0,0x253039,bar);
  machines.bench={x:65.55,z:70.3,bar};
  hit('gym-bench','bench',65.55,70.3,1.75,1.0,()=>start('bench'));
  // Squat frame and weights.
  for(const x of [65.4,66.7])box(.09,2.4,.09,x,0,73.0,0x8f9fa1);
  box(1.4,.08,.08,66.05,2.25,73.0,0x8f9fa1);solid(66.05,73.0,1.55,.5);
  const squatBar=new T.Group();squatBar.position.set(66.05,1.4,73.0);w.scene.add(squatBar);
  box(1.9,.065,.065,0,0,0,0xd6ded8,squatBar);for(const x of [-.8,.8])box(.2,.42,.42,x,-.18,0,0x242e35,squatBar);
  machines.squat={x:66.05,z:73.0,bar:squatBar};
  hit('gym-squat','squat',66.05,72.65,1.7,.9,()=>start('squat'));
  // Dumbbell rack, with each weight readable from the central aisle.
  box(.65,.7,1.7,67.05,0,74.9,0x465763);solid(67.05,74.9,.65,1.7);
  for(const z of [74.35,74.72,75.09,75.46]){
    box(.45,.05,.05,67.05,.82,z,0xa4a9a8);
    for(const x of [66.86,67.24])box(.11,.18,.18,x,.75,z,0x202a31);
  }
  machines.dumbbells={x:67.05,z:74.9};
  hit('gym-dumbbells','dumbbells',66.7,74.9,.9,1.8,()=>start('dumbbells'));
  w.mergeStatic(group);

  // One gym-goer uses the second treadmill. They are intentionally not a
  // roaming city NPC, so they cannot interfere with traffic/pathfinding.
  const npc=people.buildHuman({female:true,slim:true,shirt:0x8cc5b9,pants:0x303b50,
    skin:0xd7a57f,hair:0x392c25,shoes:0xe9e5d9,face:{hairStyle:'highPonytail'},lod:true});
  npc.group.position.set(61.0,.40,73.12);npc.group.rotation.y=Math.PI;w.scene.add(npc.group);
  if(npc.lowGroup){npc.lowGroup.position.set(61.0,.40,73.12);npc.lowGroup.rotation.y=Math.PI;w.scene.add(npc.lowGroup);}
  const receptionist=people.buildHuman({shirt:0x203d47,pants:0x252e35,skin:0xd6a676,hair:0x352721,slim:true,lod:true});
  receptionist.group.position.set(65.5,0,67.55);w.scene.add(receptionist.group);
  if(receptionist.lowGroup){receptionist.lowGroup.position.set(65.5,0,67.55);w.scene.add(receptionist.lowGroup);}
  let workout=null,clock=0;
  const durations={treadmill:8,bike:8,bench:7,squat:7,dumbbells:6};
  const overlay=document.createElement('div');overlay.id='gym-workout-ui';
  overlay.innerHTML='<section><strong></strong><span class=\"gym-remaining\"></span><div class=\"gym-track\"><i></i></div><button type=\"button\"></button></section><div class=\"gym-hands\" aria-hidden=\"true\"><span>●</span><span>●</span></div>';
  const css=document.createElement('style');css.textContent=
    '#gym-workout-ui{position:fixed;inset:0;z-index:140;display:none;pointer-events:none;color:#f7fff9;font:700 16px system-ui}'+
    '#gym-workout-ui.open{display:block}#gym-workout-ui section{position:absolute;top:max(14px,env(safe-area-inset-top));left:50%;transform:translateX(-50%);width:min(340px,80vw);background:#142f32ee;border:2px solid #c7e16c;border-radius:14px;padding:12px;box-sizing:border-box}'+
    '#gym-workout-ui strong{display:block;padding-right:64px}#gym-workout-ui .gym-remaining{position:absolute;right:14px;top:12px;color:#dcebb7}'+
    '#gym-workout-ui .gym-track{height:8px;background:#31504d;border-radius:8px;margin:10px 0}#gym-workout-ui .gym-track i{display:block;height:100%;width:0;background:#c7e16c;border-radius:8px}'+
    '#gym-workout-ui button{pointer-events:auto;background:#e4ecd5;color:#172e2b;border:0;border-radius:8px;padding:9px 16px;font:800 14px system-ui;min-height:42px}'+
    '#gym-workout-ui .gym-hands{position:absolute;bottom:-14px;left:50%;width:min(290px,64vw);display:flex;justify-content:space-between;color:#d6a17c;font-size:46px;transform:translateX(-50%) translateY(var(--gym-bob,0px));text-shadow:0 4px #344f4d}';
  document.head.appendChild(css);document.body.appendChild(overlay);
  for(const ev of ['pointerdown','touchstart','mousedown','click'])overlay.addEventListener(ev,e=>e.stopPropagation());
  overlay.querySelector('button').addEventListener('click',()=>finish(false));
  function start(kind){
    if(!game.data||game.state!=='playing'||workout||!durations[kind])return false;
    const m=machines[kind],p=game.player.pos;
    if(Math.hypot(p.x-m.x,p.z-m.z)>2.7)return false;
    workout={kind,elapsed:0,duration:durations[kind]};
    overlay.querySelector('strong').textContent=text(kind);
    overlay.querySelector('button').textContent=text('exit');
    overlay.classList.add('open');game.setInputLocked(true);game.player.vel.x=0;game.player.vel.z=0;
    return true;
  }
  function finish(completed){
    if(!workout)return false;
    const kind=workout.kind;workout=null;overlay.classList.remove('open');
    if(game.state==='playing')game.setInputLocked(false);
    if(completed&&game.data){
      game.data.gym=clean(game.data.gym);game.data.gym.workouts++;game.data.gym.byKind[kind]++;
      game.saveNow();game.ui.toast(text('done'),2200);
    }
    if(machines.bench?.bar)machines.bench.bar.position.y=1.45;
    if(machines.squat?.bar)machines.squat.bar.position.y=1.4;
    return true;
  }
  function update(dt,playing){
    doorOffset+=(doorTarget-doorOffset)*(1-Math.exp(-dt*5));
    door.position.x=63.75+doorOffset*2.02;
    const idx=w.colliders.indexOf(doorCollider);
    if(doorOffset>.85&&idx>=0)w.colliders.splice(idx,1);
    else if(doorOffset<=.85&&idx<0)w.colliders.push(doorCollider);
    if(!playing)return;
    clock+=dt;
    const distance=Math.hypot(game.player.pos.x-61,game.player.pos.z-73);
    npc.group.visible=distance<28;if(npc.lowGroup)npc.lowGroup.visible=distance>=28&&distance<50;
    if(distance<50)npc.walk(dt,.85);
    const receptionDistance=Math.hypot(game.player.pos.x-65.5,game.player.pos.z-67.55);
    receptionist.group.visible=receptionDistance<28;if(receptionist.lowGroup)receptionist.lowGroup.visible=receptionDistance>=28&&receptionDistance<50;
    if(receptionDistance<50)receptionist.walk(dt,0);
    machines.npcTreadmill.belt.position.z=73.12+(clock*.8%0.6)-.3;
    if(!workout)return;
    workout.elapsed=Math.min(workout.duration,workout.elapsed+dt);
    const m=machines[workout.kind],wave=Math.sin(workout.elapsed*6);
    if(m.belt)m.belt.position.z=m.z+(workout.elapsed*.8%0.6)-.3;
    if(m.pedals)m.pedals.rotation.x+=dt*6;
    if(m.bar)m.bar.position.y=(workout.kind==='bench'?1.45:1.4)+wave*.18;
    overlay.querySelector('.gym-track i').style.width=(100*workout.elapsed/workout.duration)+'%';
    overlay.querySelector('.gym-remaining').textContent=Math.ceil(workout.duration-workout.elapsed)+' '+text('seconds');
    overlay.style.setProperty('--gym-bob',(wave*8).toFixed(1)+'px');
    if(workout.elapsed>=workout.duration)finish(true);
  }
  const oldUpdate=w.update.bind(w);
  w.update=function(dt,pos,playing){const result=oldUpdate(dt,pos,playing);update(dt,!!playing&&game.state==='playing');return result;};
  const oldCam=game.fpsCam.update.bind(game.fpsCam);
  game.fpsCam.update=function(dt,...args){
    const r=oldCam(dt,...args);
    if(workout&&game.state==='playing')game.camera.position.y+=Math.sin(workout.elapsed*6)*.035;
    return r;
  };
  const pause=game.pause.bind(game),menu=game.toMenu.bind(game);
  game.pause=function(){finish(false);return pause();};
  game.toMenu=function(){finish(false);return menu();};
  window.__gym={start,finish,toggleDoor,machines,doorCollider,
    inspect:()=>({doorTarget,doorOffset,doorBlocked:w.colliders.includes(doorCollider),workout:workout?{...workout}:null,
      data:game.data?.gym||null,shower:drops.visible,locker:lockerOpen,npcVisible:npc.group.visible,npcPhase:npc.phase})};
})();
