/* Trafikte ağaç temizliği ve yer seviyesindeki seçili nesneler için çarpışma. */
(function () {
  'use strict';
  const g=window.__mms,T=window.THREE;
  if(!g||!T||window.__sehirCarpisma)return;
  const w=g.world;
  // Bilinen asfalt alanları: ana cadde, stadyum yolu, çevre yolları ve güney mahallesi.
  const roads=[
    [-89,154,8.2,14.7],[-3.5,3.5,11.6,41.2],[-3.5,43.8,41.1,46.5],
    [31.2,43.8,46.5,66],[-89,154,-27,-17],[-89,154,107,117],
    [-89,-79,-27,117],[144,154,-27,130],[31.5,41.5,65.5,230],
    [31.5,154,120,130],[39,153,186.5,193.5],[149.5,160,120,194],[-32.2,-13,-4.4,6.4],[-16.4,-10,6.3,10.5]
  ];
  const onRoad=(x,z,margin=1.3)=>roads.some(([a,b,c,d])=>x>=a-margin&&x<=b+margin&&z>=c-margin&&z<=d+margin);
  const seen=new Set(), rejected=new Set(), matrix=new T.Matrix4(), worldPos=new T.Vector3(), zero=new T.Matrix4();
  let added=0, benchAdded=0, seenTrees=0;
  const nearExisting=(x,z)=>w.colliders.some(c=>!c.trafficBody&&x>c.minX-.12&&x<c.maxX+.12&&z>c.minZ-.12&&z<c.maxZ+.12);
  function solid(x,z,half,kind){
    if(nearExisting(x,z))return false;
    w.colliders.push({minX:x-half,maxX:x+half,minZ:z-half,maxZ:z+half,citySafety:kind});return true;
  }
  w.scene.updateMatrixWorld(true);
  w.scene.traverse(mesh=>{
    if(!mesh.isInstancedMesh)return;
    const special=mesh.userData.roadSafetyTrees, species=mesh.userData.vegetation;
    if(!species&&!special)return;
    for(let i=0;i<mesh.count;i++){
      mesh.getMatrixAt(i,matrix);worldPos.setFromMatrixPosition(matrix).applyMatrix4(mesh.matrixWorld);
      const x=worldPos.x,z=worldPos.z,key=x.toFixed(2)+','+z.toFixed(2);
      if(onRoad(x,z)){
        rejected.add(key);
        zero.makeScale(0,0,0);zero.setPosition(matrix.elements[12],matrix.elements[13],matrix.elements[14]);
        mesh.setMatrixAt(i,zero);mesh.instanceMatrix.needsUpdate=true;
      }else if(!seen.has(key)){
        seen.add(key);seenTrees++;
        if(solid(x,z,species==='shrub'?.28:.32,'tree'))added++;
      }
    }
  });
  // Seated park props are not tall enough for the engine's existing automatic box colliders.
  const benches=[[-6.4,27.2],[6.4,31],[80,152],[96,162],[80,163],[-62.2,58.8],[-53.8,58.8],[-62.2,67.2],[-53.8,67.2],[-67,54],[-49,54],[-67,72],[-49,72]];
  for(const [x,z] of benches)if(!onRoad(x,z,.2)&&!nearExisting(x,z)){
    w.colliders.push({minX:x-.85,maxX:x+.85,minZ:z-.48,maxZ:z+.48,citySafety:'bench'});benchAdded++;
  }
  // Only the traffic light poles, not their overhead boxes, get a small footprint.
  const lights=w.scene.getObjectByName('TRAFFIC SIGNALS');let lightAdded=0;
  if(lights)for(const post of lights.children){const x=post.position.x,z=post.position.z;
    if(!onRoad(x,z,.1)&&solid(x,z,.12,'light'))lightAdded++;
  }
  window.__sehirCarpisma={onRoad,inspect:()=>({roadTreesRemoved:rejected.size,trees:seenTrees,treeColliders:added,benchColliders:benchAdded,lightColliders:lightAdded})};
})();
