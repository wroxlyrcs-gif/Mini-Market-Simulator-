/* İkinci market: bağımsız müşteri, stok ve çalışan sistemi. */
(function () {
  'use strict';
  const g=window.__mms, T=window.THREE, people=window.__mmsPeople;
  if(!g||!T||!people||window.__ikinciMarket)return;
  const fleet=window.__ikinciTeslimat;
  const w=g.world, KEY='mms_citymarket_stockworker_v4', SOURCE='mms_citymarket_shelves_v3', SOURCE2='mms_citymarket_products_v2', LEGACY='mms_citymarket_staff_v1', OWN='mms_citymarket_v1';
  const WAGES={cashier:20,stocker:25}, BUY_AMOUNT=10, MAX_SHELF=12;
  const products=[
    {id:'water',name:{tr:'Su',en:'Water',az:'Su',ru:'Вода'},cost:2,price:4},
    {id:'bread',name:{tr:'Ekmek',en:'Bread',az:'Çörək',ru:'Хлеб'},cost:3,price:6},
    {id:'milk',name:{tr:'Süt',en:'Milk',az:'Süd',ru:'Молоко'},cost:4,price:8},
    {id:'snack',name:{tr:'Atıştırmalık',en:'Snack',az:'Qəlyanaltı',ru:'Закуска'},cost:5,price:10}
  ];
  function read(key){try{return JSON.parse(localStorage.getItem(key)||'{}')||{};}catch(_){return {};}}
  const current=read(KEY), version3=read(SOURCE), version2=read(SOURCE2), previous=read(LEGACY), saved=Array.isArray(current.products)?current:Array.isArray(version3.products)?version3:Array.isArray(version2.products)?version2:previous, fromCurrent=Array.isArray(saved.products);
  const number=(n,f,min,max)=>Math.max(min,Math.min(max,Math.floor(Number.isFinite(n)?n:f)));
  const split=(v,i)=>Math.floor(v/4)+(i<v%4?1:0);
  const oldShelf=number(previous.shelf,12,0,24),oldReserve=number(previous.reserve,20,0,999);
  const st={cashier:saved.cashier===true,stocker:saved.stocker===true,sales:number(saved.sales,0,0,100000000),
    products:products.map((p,i)=>{const a=fromCurrent?saved.products.find(v=>v&&v.id===p.id)||{}:{};
      return {id:p.id,shelf:number(a.shelf,split(oldShelf,i),0,p.id==='milk'?24:MAX_SHELF),reserve:number(a.reserve,split(oldReserve,i),0,999),price:number(a.price,p.price,1,500)};
    })};
  st.delivered=Array.isArray(saved.delivered)?saved.delivered.filter(x=>typeof x==='string').slice(-30):[];
  // Four gondola faces plus the refrigerator: each fixture has its own capacity.
  const shelfSpecs=[
    {id:'rack-water',product:'water',name:{tr:'Raf 1 · Su',en:'Shelf 1 · Water',az:'Rəf 1 · Su',ru:'Полка 1 · Вода'},z:71.96,standZ:70.85,color:0x9ccfe0},
    {id:'rack-bread',product:'bread',name:{tr:'Raf 2 · Ekmek',en:'Shelf 2 · Bread',az:'Rəf 2 · Çörək',ru:'Полка 2 · Хлеб'},z:72.44,standZ:73.1,color:0xd5a169},
    {id:'rack-snack',product:'snack',name:{tr:'Raf 3 · Atıştırmalık',en:'Shelf 3 · Snack',az:'Rəf 3 · Qəlyanaltı',ru:'Полка 3 · Закуска'},z:75.16,standZ:74.45,color:0xd56f42},
    {id:'rack-milk',product:'milk',name:{tr:'Raf 4 · Süt',en:'Shelf 4 · Milk',az:'Rəf 4 · Süd',ru:'Полка 4 · Молоко'},z:75.64,standZ:76.35,color:0xe9e8dd},
    {id:'fridge-milk',product:'milk',name:{tr:'Soğutucu · Süt',en:'Refrigerator · Milk',az:'Soyuducu · Süd',ru:'Холодильник · Молоко'},z:77.8,standZ:76.48,color:0xcde7ef}
  ];
  const records=Array.isArray(saved.fixtures)?saved.fixtures:[];
  st.fixtures=shelfSpecs.map((f,i)=>{const match=records.find(r=>r&&r.id===f.id),p=st.products.find(v=>v.id===f.product);
    const fallback=f.id==='fridge-milk'?Math.max(0,p.shelf-12):Math.min(12,p.shelf);
    return {id:f.id,product:f.product,qty:number(match?.qty,fallback,0,MAX_SHELF)};});
  st.payDay=number(saved.payDay,0,0,100000000);st.totalWages=number(saved.totalWages,0,0,100000000);
  st.cargo={};for(const p of products)st.cargo[p.id]=number(saved.cargo?.[p.id],0,0,24);
  st.cargoCursor=number(saved.cargoCursor,0,0,shelfSpecs.length-1);
  if(!st.stocker)for(const p of st.products){p.reserve=Math.min(999,p.reserve+st.cargo[p.id]);st.cargo[p.id]=0;}

  function syncTotals(){for(const p of st.products)p.shelf=st.fixtures.filter(f=>f.product===p.id).reduce((sum,f)=>sum+f.qty,0);}
  syncTotals();

  const item=id=>st.products.find(x=>x.id===id), spec=id=>products.find(x=>x.id===id);
  const productName=p=>p.name[g.ui?.lang]||p.name.tr;
  let own=false,ownTimer=0,spawnTimer=6,stockTimer=0,checkoutTimer=0,ui=null,uiOpen=false,created=0;
  const shoppers=[]; let cashier=null,stocker=null;
  let shelfVisual=null,workerPos={x:48.7,z:70.8},workerRoute=[],workerTarget=null,workerWait=0;
  let workerPhase='idle',workerArea='inside',workerHeading=0,workerBox=null,workerBoxLow=null;
  function save(){syncTotals();if(shelfVisual)shelfVisual.update();try{localStorage.setItem(KEY,JSON.stringify(st));}catch(_){} if(g.data&&g.saveNow)g.saveNow();}
  function owned(){try{return JSON.parse(localStorage.getItem(OWN)||'{}').owned===true;}catch(_){return false;}}
  const words={
    tr:{title:'Süper Market Yönetimi',locked:'Önce Süper Marketi satın al.',money:'Para',shelf:'Raftaki ürün',reserve:'Depodaki ürün',waiting:'Kasada bekleyen',sales:'Tamamlanan satış',cashier:'Kasiyer',stocker:'Raf görevlisi',hired:'Çalışıyor',none:'Yok',hire:'İşe al',fire:'İşten çıkar',cost:'tek seferlik',buy:'20 ürün al',fill:'Rafa ürün koy',pay:'Sıradaki müşteriyi öde',close:'Kapat',hint:'Müşteri satışları bakiyene eklenir. Önceki günlük market geliri ayrıca devam eder.',nomoney:'Yeterli paran yok.',empty:'Depo boş veya raf dolu.',noqueue:'Kasada bekleyen müşteri yok.',paid:'Müşteri ödemesi alındı.',purchased:'Depoya 20 ürün eklendi.'},
    en:{title:'Supermarket Management',locked:'Buy the supermarket first.',money:'Money',shelf:'On shelves',reserve:'In stockroom',waiting:'Waiting at checkout',sales:'Completed sales',cashier:'Cashier',stocker:'Shelf worker',hired:'Working',none:'Not hired',hire:'Hire',fire:'Dismiss',cost:'one-time',buy:'Buy 20 items',fill:'Restock shelves',pay:'Check out next customer',close:'Close',hint:'Customer sales go to your balance. Existing daily market income continues separately.',nomoney:'Not enough money.',empty:'Stockroom empty or shelves full.',noqueue:'No customer is waiting.',paid:'Customer payment received.',purchased:'20 items added to stockroom.'},
    az:{title:'Supermarket idarəsi',locked:'Əvvəlcə supermarketi alın.',money:'Pul',shelf:'Rəfdəki məhsul',reserve:'Anbardakı məhsul',waiting:'Kassada gözləyən',sales:'Tamamlanan satış',cashier:'Kassir',stocker:'Rəf işçisi',hired:'İşləyir',none:'Yoxdur',hire:'İşə al',fire:'İşdən çıxar',cost:'birdəfəlik',buy:'20 məhsul al',fill:'Rəfi doldur',pay:'Növbəti müştərini hesabla',close:'Bağla',hint:'Müştəri satışları balansınıza əlavə olunur. Mövcud gündəlik gəlir ayrıca davam edir.',nomoney:'Kifayət qədər pul yoxdur.',empty:'Anbar boşdur və ya rəf doludur.',noqueue:'Kassada gözləyən müştəri yoxdur.',paid:'Müştərinin ödənişi alındı.',purchased:'Anbara 20 məhsul əlavə edildi.'},
    ru:{title:'Управление супермаркетом',locked:'Сначала купите супермаркет.',money:'Деньги',shelf:'Товар на полках',reserve:'Товар на складе',waiting:'Ждут у кассы',sales:'Завершено продаж',cashier:'Кассир',stocker:'Работник полок',hired:'Работает',none:'Не нанят',hire:'Нанять',fire:'Уволить',cost:'разовый платёж',buy:'Купить 20 товаров',fill:'Пополнить полки',pay:'Обслужить покупателя',close:'Закрыть',hint:'Продажи зачисляются на баланс. Прежний ежедневный доход начисляется отдельно.',nomoney:'Недостаточно денег.',empty:'Склад пуст или полки заполнены.',noqueue:'У кассы никто не ждёт.',paid:'Оплата получена.',purchased:'На склад добавлено 20 товаров.'}
  };
  const tx=k=>(words[g.ui?.lang]||words.tr)[k]||k;
  function toast(k){g.ui.toast(tx(k));}
  const more={
    tr:{inTransit:'İşçide',daily:'gün',wages:'Günlük maaş',payroll:'Gün sonu maaşları ödendi',quit:'Maaşı ödenemediği için işten ayrıldı',products:'Ürünler ve fiyatlar',price:'Satış fiyatı',savePrice:'Kaydet',buy10:'10 adet sipariş ver',refill:'Rafa koy',unitCost:'Alış',invalid:'Fiyat 1 ile 500 arasında tam sayı olmalı.',bought:'Ürünler depoya eklendi.',priceSaved:'Fiyat kaydedildi.'},
    en:{inTransit:'With worker',daily:'day',wages:'Daily wage',payroll:'Daily wages paid',quit:'left because wages could not be paid',products:'Products and prices',price:'Sale price',savePrice:'Save',buy10:'Order 10',refill:'Restock',unitCost:'Cost',invalid:'Price must be a whole number from 1 to 500.',bought:'Items added to stockroom.',priceSaved:'Price saved.'},
    az:{inTransit:'İşçidə',daily:'gün',wages:'Gündəlik maaş',payroll:'Günlük maaşlar ödənildi',quit:'maaşı ödənmədiyi üçün işdən çıxdı',products:'Məhsullar və qiymətlər',price:'Satış qiyməti',savePrice:'Yadda saxla',buy10:'10 ədəd sifariş et',refill:'Rəfə qoy',unitCost:'Alış',invalid:'Qiymət 1 ilə 500 arasında tam ədəd olmalıdır.',bought:'Məhsullar anbara əlavə edildi.',priceSaved:'Qiymət yadda saxlanıldı.'},
    ru:{inTransit:'У работника',daily:'день',wages:'Дневная зарплата',payroll:'Зарплаты выплачены',quit:'уволился из-за невыплаты зарплаты',products:'Товары и цены',price:'Цена продажи',savePrice:'Сохранить',buy10:'Заказать 10',refill:'На полку',unitCost:'Закупка',invalid:'Цена должна быть целым числом от 1 до 500.',bought:'Товары добавлены на склад.',priceSaved:'Цена сохранена.'}
  };
  const t=k=>(more[g.ui?.lang]||more.tr)[k]||k;
  function fresh(){if(uiOpen && !(ui&&ui.contains(document.activeElement)&&document.activeElement.tagName==='INPUT'))draw();}
  function model(options,x,z){
    const h=people.buildHuman({...options,lod:true});
    h.group.position.set(x,0,z);h.group.visible=false;w.root.add(h.group);
    if(h.lowGroup){h.lowGroup.position.set(x,0,z);h.lowGroup.visible=false;w.root.add(h.lowGroup);}
    return h;
  }
  function appearance(h,x,z,rot,show){
    const dist=Math.hypot(g.player.pos.x-x,g.player.pos.z-z), high=show&&dist<23, low=show&&dist>=23&&dist<55;
    h.group.position.set(x,0,z);h.group.rotation.y=rot;h.group.visible=high;
    if(h.lowGroup){h.lowGroup.position.set(x,0,z);h.lowGroup.rotation.y=rot;h.lowGroup.visible=low;}
  }
  function ensureStaff(){
    if(st.cashier&&!cashier)cashier=model({shirt:0xc52f2a,pants:0x333c46,apron:0x283c34,skin:0xe0ac69,hair:0x30251d},57.3,68.9);
    if(st.stocker&&!stocker){
      stocker=model({shirt:0x3e714c,pants:0x30383f,apron:0x5f7447,skin:0xf1c27d,hair:0x35231e},workerPos.x,workerPos.z);
      const makeBox=parent=>{const m=w.b(.46,.38,.36,0,.85,.32,0xc59a64,{parent,cast:false,receive:false});m.visible=false;return m;};
      workerBox=makeBox(stocker.group);if(stocker.lowGroup)workerBoxLow=makeBox(stocker.lowGroup);
    }
  }
  function cargoTotal(){return Object.values(st.cargo).reduce((n,v)=>n+v,0);}
  function putCargoBack(){for(const p of st.products){p.reserve+=st.cargo[p.id];st.cargo[p.id]=0;}}
  function stopWorker(){putCargoBack();workerPhase='idle';workerArea='inside';workerTarget=null;workerRoute=[];workerWait=0;
    workerPos.x=48.7;workerPos.z=70.8;if(stocker)stocker.setCarry(false);if(workerBox)workerBox.visible=false;if(workerBoxLow)workerBoxLow.visible=false;}
  function hasNeed(){return st.fixtures.some(f=>f.qty<MAX_SHELF&&item(f.product).reserve>0);}
  function takeCargo(){
    let room=24;const len=st.fixtures.length;
    for(let k=0;k<len&&room>0;k++){
      const idx=(st.cargoCursor+k)%len,f=st.fixtures[idx],p=item(f.product);
      const assigned=st.cargo[f.product]||0;
      const totalNeed=st.fixtures.filter(v=>v.product===f.product).reduce((n,v)=>n+MAX_SHELF-v.qty,0);
      const n=Math.min(6,p.reserve,Math.max(0,totalNeed-assigned),room);
      if(n>0){p.reserve-=n;st.cargo[p.id]+=n;room-=n;}
    }
    st.cargoCursor=(st.cargoCursor+1)%len;save();fresh();return cargoTotal()>0;
  }
  function depositCargo(f){const p=item(f.product),n=Math.min(6,st.cargo[p.id],MAX_SHELF-f.qty);
    if(n<=0)return false;f.qty+=n;st.cargo[p.id]-=n;save();fresh();return true;}
  const fromInsideToDepot=()=>[[47.15,workerPos.z],[47.15,70.85],[50.5,70.7],[51,68],[51,64],[62,64],[62,55.1],[67.6,55.1]];
  function targetRoute(f){const v=shelfSpecs.find(x=>x.id===f.id);
    if(workerArea==='depot')return [[62,55.1],[62,64],[51,64],[51,68],[50.5,70.7],[47.15,70.85],[47.15,v.standZ],[48.7,v.standZ]];
    return [[47.15,workerPos.z],[47.15,v.standZ],[48.7,v.standZ]];
  }
  function beginToDepot(){workerPhase='depot';workerTarget=null;workerWait=0;workerRoute=fromInsideToDepot();}
  function tickWorker(dt){
    let walking=false;
    if(workerPhase==='idle'){
      if(cargoTotal()>0){workerPhase='select';}
      else if(hasNeed())beginToDepot();
    }
    if(workerPhase==='select'){
      const f=st.fixtures.filter(v=>v.qty<MAX_SHELF&&st.cargo[v.product]>0).sort((a,b)=>a.qty-b.qty)[0];
      if(f){workerTarget=f.id;workerPhase='shelf';workerWait=0;workerRoute=targetRoute(f);workerArea='inside';}
      else if(cargoTotal()>0){putCargoBack();save();fresh();workerPhase='idle';}
      else workerPhase='idle';
    }
    if(workerRoute.length){
      const [x,z]=workerRoute[0],dx=x-workerPos.x,dz=z-workerPos.z,d=Math.hypot(dx,dz),n=1.5*dt;
      if(d<=n||d<.02){workerPos.x=x;workerPos.z=z;workerRoute.shift();}
      else{const nx=workerPos.x+dx/d*n,nz=workerPos.z+dz/d*n;
        // Wait for vehicle bodies; do not block walking away from an overlap.
        const blocked=w.colliders.some(c=>c.trafficBody&&nx>c.minX-.25&&nx<c.maxX+.25&&nz>c.minZ-.25&&nz<c.maxZ+.25&&
          !(workerPos.x>c.minX-.25&&workerPos.x<c.maxX+.25&&workerPos.z>c.minZ-.25&&workerPos.z<c.maxZ+.25));
        if(!blocked){workerPos.x=nx;workerPos.z=nz;workerHeading=Math.atan2(dx,dz);walking=true;}
      }
    }else if(workerPhase==='depot'){
      workerWait+=dt;if(workerWait>=1){workerWait=0;workerArea='depot';workerPhase=takeCargo()?'select':'idle';}
    }else if(workerPhase==='shelf'){
      workerWait+=dt;if(workerWait>=2){workerWait=0;const f=st.fixtures.find(v=>v.id===workerTarget);if(f)depositCargo(f);workerTarget=null;workerPhase='select';}
    }
    const carrying=cargoTotal()>0;stocker.setCarry(carrying);if(workerBox)workerBox.visible=carrying;if(workerBoxLow)workerBoxLow.visible=carrying;
    appearance(stocker,workerPos.x,workerPos.z,workerHeading,st.stocker);stocker.walk(dt,walking?1:0);
  }
  // Worker pays at day change, like the first market: no separate hiring fee.
  function settleWages(){
    const day=number(g.data?.day,1,1,100000000);
    if(!st.payDay||day<st.payDay){st.payDay=day;save();return;}
    if(day===st.payDay)return;
    const days=Math.min(day-st.payDay,30);let paid=0;const quit=[];
    for(let d=0;d<days;d++)for(const role of ['cashier','stocker'])if(st[role]){
      if(g.data.money>=WAGES[role]){g.data.money-=WAGES[role];paid+=WAGES[role];st.totalWages+=WAGES[role];}
      else{st[role]=false;quit.push(role);if(role==='stocker')stopWorker();}
    }
    st.payDay=day;save();if(paid)g.ui.toast(t('payroll')+': -'+paid+' $');
    if(quit.length)g.ui.toast(quit.map(tx).join(', ')+' '+t('quit'));fresh();
  }
  function refill(id,fixtureId){
    const eligible=st.fixtures.filter(f=>(!id||f.product===id)&&(!fixtureId||f.id===fixtureId)&&f.qty<MAX_SHELF&&item(f.product).reserve>0);
    const f=eligible[0];if(!f)return false;const p=item(f.product),n=Math.min(6,p.reserve,MAX_SHELF-f.qty);
    f.qty+=n;p.reserve-=n;save();return true;
  }
  function takeProduct(id){const f=st.fixtures.find(x=>x.product===id&&x.qty>0);if(!f)return false;f.qty--;syncTotals();return true;}
  function spend(n){if(!g.data||g.data.money<n){toast('nomoney');return false;}g.data.money-=n;return true;}
  function hire(role){if(st[role]){st[role]=false;if(role==='stocker')stopWorker();save();draw();return;}
    if(!g.data||g.data.money<WAGES[role]){toast('nomoney');return;}
    if(!st.payDay)st.payDay=Math.max(1,g.data.day||1);
    st[role]=true;ensureStaff();save();draw();
  }
  function buyStock(id){const p=item(id),info=spec(id);if(!p||!info||p.reserve+st.cargo[id]>989)return;
    if(!fleet||!fleet.canOrder()){g.ui.toast(({tr:'Teslimat alanı meşgul. Araç ayrılınca tekrar dene.',en:'Delivery area busy. Try again when the vehicle leaves.',az:'Çatdırılma sahəsi məşğuldur.',ru:'Зона доставки занята.'}[g.ui.lang]||'Teslimat alanı meşgul.'));return;}
    const cost=info.cost*BUY_AMOUNT;if(!spend(cost))return;
    if(!fleet.order(id,BUY_AMOUNT)){g.data.money+=cost;return;}save();draw();}
  function receive(id,qty,token){const p=item(id);if(!p||qty!==10||typeof token!=='string')return false;
    if(st.delivered.includes(token))return true;
    if(p.reserve+st.cargo[id]>989)return false;
    p.reserve+=qty;st.delivered.push(token);if(st.delivered.length>30)st.delivered.shift();save();fresh();return true;
  }
  function manualStock(id){if(!refill(id))toast('empty');draw();}
  function setPrice(id){const p=item(id),input=ui.querySelector('[data-price="'+id+'"]');if(!p||!input)return;
    const raw=input.value.trim(),n=Number(raw);
    if(!/^[0-9]+$/.test(raw)||!Number.isInteger(n)||n<1||n>500){g.ui.toast(t('invalid'));return;}
    p.price=n;save();g.ui.toast(t('priceSaved'));draw();
  }
  function open(){
    if(!owned()){toast('locked');return;}
    if(!ui){ui=document.createElement('div');ui.id='second-shop-panel';document.body.appendChild(ui);
      for(const ev of ['pointerdown','touchstart','mousedown','click'])ui.addEventListener(ev,e=>e.stopPropagation());}
    uiOpen=true;g.setInputLocked(true);draw();
  }
  function close(){uiOpen=false;if(ui)ui.classList.remove('open');g.setInputLocked(false);}
  function draw(){if(!uiOpen)return;const q=shoppers.filter(c=>c.state==='waiting').length;
    const button=(id,label)=>`<button type="button" data-action="${id}">${label}</button>`;
    const ds=fleet?.inspect(), orderInfo=ds?.pending ? '🚚 '+(productName(spec(ds.pending.id)))+' · '+ds.pending.qty+' '+({tr:'yolda',en:'on the way',az:'yoldadır',ru:'в пути'}[g.ui.lang]||'yolda') : '';
    const rows=products.map(info=>{const p=item(info.id);return `<div class="ss-product"><b>${productName(info)}</b><small>${tx('shelf')}: ${p.shelf}/${st.fixtures.filter(f=>f.product===p.id).length*MAX_SHELF} · ${tx('reserve')}: ${p.reserve} · ${t('inTransit')}: ${st.cargo[p.id]} · ${t('unitCost')}: ${info.cost} $</small><small>${st.fixtures.filter(f=>f.product===p.id).map(f=>{const v=shelfSpecs.find(a=>a.id===f.id);return (v.name[g.ui?.lang]||v.name.tr)+': '+f.qty+'/'+MAX_SHELF;}).join(' · ')}</small><div class="ss-price"><label>${t('price')} ($)<input type="number" inputmode="numeric" min="1" max="500" step="1" data-price="${info.id}" value="${p.price}"></label><button type="button" data-action="price:${info.id}">${t('savePrice')}</button></div><div class="ss-actions"><button type="button" data-action="buy:${info.id}">${t('buy10')} · ${info.cost*BUY_AMOUNT} $</button><button type="button" data-action="fill:${info.id}">${t('refill')}</button></div></div>`;}).join('');
    ui.innerHTML=`<section class="ss-card"><header class="ss-head"><h2>${tx('title')}</h2><button type="button" data-action="close" aria-label="${tx('close')}">✕</button></header><p>${tx('money')}: <b>${Math.floor(g.data.money)} $</b></p><div class="ss-grid"><span>${tx('waiting')}: <b>${q}</b></span><span>${tx('sales')}: <b>${st.sales}</b></span></div>
      ${button('cashier',tx('cashier')+': '+(st.cashier?tx('hired')+' · '+tx('fire'):tx('hire'))+' · '+WAGES.cashier+' $/'+t('daily'))}
      ${button('stocker',tx('stocker')+': '+(st.stocker?tx('hired')+' · '+tx('fire'):tx('hire'))+' · '+WAGES.stocker+' $/'+t('daily'))}
      ${button('pay',tx('pay'))}<p>${orderInfo}</p><h3>${t('products')}</h3>${rows}<p class="ss-hint">${tx('hint')}</p>${button('close',tx('close'))}</section>`;
    ui.classList.add('open');for(const b of ui.querySelectorAll('button'))b.onclick=()=>{
      const [action,id]=b.dataset.action.split(':');
      switch(action){case 'cashier':hire('cashier');break;case 'stocker':hire('stocker');break;case 'buy':buyStock(id);break;case 'fill':manualStock(id);break;case 'price':setPrice(id);break;case 'pay':if(!checkout())toast('noqueue');draw();break;case 'close':close();break;}
    };
  }
  // Walkway coordinates pass through the open door, around the gondola and to the checkout aisle.
  const routeIn=[[51,65.5],[51,68],[50.5,70.7],[47.15,70.85]],routeOut=[[50.5,70.7],[51,68],[51,65.5],[51,63.7]];
  function chooseShelf(preferred,exclude){
    const all=st.fixtures.filter(f=>f.qty>0&&f.id!==exclude);
    const same=all.filter(f=>f.product===preferred),candidates=same.length?same:all;
    return candidates.length?candidates[(created+st.sales)%candidates.length]:null;
  }
  function shelfApproach(f){const v=shelfSpecs.find(s=>s.id===f.id);return [[47.15,v.standZ],[48.7,v.standZ]];}
  function aisleFromShelf(c){return [[47.15,c.z],[47.15,70.85],[50.5,70.7]];}
  function leaveFromShelf(c){return [...aisleFromShelf(c),...leavePath(c).slice(1)];}
  function reroute(c){
    const old=st.fixtures.find(f=>f.id===c.targetShelf),next=chooseShelf(old?.product,c.targetShelf);
    if(!next){c.state='leave';c.points=leaveFromShelf(c);return false;}
    c.targetShelf=next.id;c.redirects=(c.redirects||0)+1;c.state='enter';
    c.points=[[47.15,c.z],...shelfApproach(next)];return true;
  }
  function spawn(byCar=false){if(shoppers.length>=2||!st.products.some(p=>p.shelf>0))return false;
    if(!byCar && created%2===1 && fleet?.startCustomer())return true;
    const shirts=[0x698dac,0xc58d69,0xb487ad,0x8eaa77];
    const x=byCar?62:51,z=byCar?60:63.7;
    const h=model({shirt:shirts[created%shirts.length],pants:0x374653,skin:people.SKINS[created%people.SKINS.length],hair:0x382820},x,z);created++;
    const chosen=chooseShelf(null,null);if(!chosen){w.root.remove(h.group);if(h.lowGroup)w.root.remove(h.lowGroup);return false;}
    const path=[...(byCar?[[62,64],[51,64]]:[]),...routeIn,...shelfApproach(chosen)];
    shoppers.push({h,x,z,rot:0,state:'enter',points:path.map(p=>p.slice()),timer:0,queueOrder:0,byCar,targetShelf:chosen.id,redirects:0});return true;
  }
  function move(c,dt){
    const p=c.points[0];if(!p)return true;
    const dx=p[0]-c.x,dz=p[1]-c.z,d=Math.hypot(dx,dz),step=1.1*dt;
    if(d<=step||d<.02){c.x=p[0];c.z=p[1];c.points.shift();return c.points.length===0;}
    c.x+=dx/d*step;c.z+=dz/d*step;c.rot=Math.atan2(dx,dz);return false;
  }
  const leavePath=c=>c.byCar?[[50.5,70.7],[51,68],[51,64],[62,64],[62,60]]:routeOut;
  function checkout(){const c=shoppers.find(c=>c.state==='waiting');if(!c)return false;
    g.data.money+=c.price;st.sales++;c.state='leave';c.points=leavePath(c).map(p=>p.slice());
    c.h.setCarry(false);save();fresh();return true;
  }
  function step(dt){
    if(g.state!=='playing'||!g.data)return;
    ownTimer+=dt;if(ownTimer>=.5){ownTimer=0;own=owned();}
    if(!own){for(const h of [cashier,stocker])if(h)appearance(h,0,0,0,false);for(const c of shoppers)appearance(c.h,c.x,c.z,c.rot,false);return;}
    settleWages();ensureStaff();
    if(cashier)appearance(cashier,57.3,68.9,-Math.PI/2,st.cashier);
    if(stocker&&st.stocker)tickWorker(dt);
    else if(stocker)appearance(stocker,workerPos.x,workerPos.z,workerHeading,false);
    spawnTimer-=dt;if(spawnTimer<=0){spawnTimer=15;spawn();}
    for(let i=shoppers.length-1;i>=0;i--){const c=shoppers[i];let walking=false;
      if(c.state==='enter'){walking=true;if(move(c,dt)){c.state='browse';c.timer=2.5;}}
      else if(c.state==='browse'){c.timer-=dt;if(c.timer<=0){
        const shelf=st.fixtures.find(f=>f.id===c.targetShelf);
        if(shelf&&shelf.qty>0){const chosen=item(shelf.product);shelf.qty--;syncTotals();c.product=chosen.id;c.price=chosen.price;save();c.h.setCarry(true);c.state='queue';c.points=[...aisleFromShelf(c),[52.4,70.7],[52.4,69.7]];fresh();}
        else reroute(c);
      }}
      else if(c.state==='queue'){
        // One person at a time moves to the register; others wait in the aisle.
        const busy=shoppers.some(o=>o!==c&&o.state==='waiting');
        if(!busy){walking=true;if(move(c,dt)){c.state='waiting';checkoutTimer=0;fresh();}}
      }
      else if(c.state==='leave'){walking=true;if(move(c,dt)){w.root.remove(c.h.group);if(c.h.lowGroup)w.root.remove(c.h.lowGroup);if(c.byCar)fleet?.customerDone();shoppers.splice(i,1);continue;}}
      c.h.walk(dt,walking?1:0);appearance(c.h,c.x,c.z,c.rot,true);
    }
    if(st.cashier&&shoppers.some(c=>c.state==='waiting')){checkoutTimer+=dt;if(checkoutTimer>=2){checkoutTimer=0;checkout();}}else checkoutTimer=0;
  }
  const css=document.createElement('style');css.textContent=`#second-shop-panel{display:none;position:fixed;inset:0;z-index:140;background:#11251dcb;align-items:center;justify-content:center;padding:12px;font:15px system-ui;color:#243b31}#second-shop-panel.open{display:flex}#second-shop-panel .ss-card{width:min(480px,95vw);max-height:90vh;overflow:auto;touch-action:pan-y;overscroll-behavior:contain;background:#f4f5e8;padding:18px;border-radius:16px;border:2px solid #e1b641}#second-shop-panel .ss-head{position:sticky;top:-18px;background:#f4f5e8;display:flex;align-items:center;justify-content:space-between;z-index:1;padding:5px 0}#second-shop-panel .ss-head button{width:42px;min-height:38px;margin:0}#second-shop-panel h2{font-size:21px;margin:0}#second-shop-panel p{margin:6px 0}#second-shop-panel .ss-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}#second-shop-panel button{width:100%;min-height:42px;border:0;border-radius:9px;margin:3px 0;background:#28674b;color:white;font:700 14px system-ui}#second-shop-panel .ss-hint{font-size:13px;color:#4b6156}#second-shop-panel h3{font-size:17px;margin:14px 0 6px}#second-shop-panel .ss-product{background:#e4ebdc;border-radius:10px;padding:10px;margin:8px 0}#second-shop-panel .ss-product small{display:block;font-size:13px;margin:4px 0}#second-shop-panel .ss-price,#second-shop-panel .ss-actions{display:flex;align-items:end;gap:8px}#second-shop-panel .ss-price label{flex:1;font-size:13px}#second-shop-panel .ss-price input{box-sizing:border-box;width:100%;height:40px;border:1px solid #869d85;border-radius:7px;padding:6px;font-size:16px;background:#fff;color:#1f342a}#second-shop-panel .ss-price button{width:38%}#second-shop-panel .ss-actions button{width:50%}`;document.head.appendChild(css);
  // Computer in the right-hand corner, behind the checkout. The panel manages this market only.
  const pc=new T.Group();pc.name='İKİNCİ MARKET BİLGİSAYARI';w.scene.add(pc);
  const box=(sx,sy,sz,x,y,z,c)=>{const m=w.b(sx,sy,sz,x,y,z,c,{parent:pc,cast:false,receive:false});m.userData.static=true;return m;};
  const x=57.15,z=67.65;
  box(1.25,.08,.62,x,.75,z,0xc99b6b);for(const dx of [-.55,.55])for(const dz of [-.24,.24])box(.055,.75,.055,x+dx,0,z+dz,0x76563b);
  box(.30,.03,.20,x,.83,z-.12,0x253139);box(.06,.19,.05,x,.86,z-.13,0x253139);box(.66,.42,.06,x,1.03,z-.16,0x253139);
  box(.40,.025,.15,x,.84,z+.13,0x444e50);box(.16,.35,.38,x+.48,.84,z-.10,0x303b3d);
  const tex=w.canvasTex(320,200,(c,W,H)=>{c.fillStyle='#ebf5e8';c.fillRect(0,0,W,H);c.fillStyle='#287b55';c.fillRect(0,0,W,55);c.fillStyle='#fff';c.textAlign='center';c.font='bold 31px sans-serif';c.fillText('MARKET 2',W/2,36);c.fillStyle='#2b493b';c.font='bold 24px sans-serif';c.fillText('SİPARİŞ / STOK',W/2,110);c.fillText('İŞÇİLER',W/2,152);});
  const display=new T.Mesh(w.geo('plane'),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));display.scale.set(.58,.34,1);display.position.set(x,1.25,z-.124);pc.add(display);w.mergeStatic(pc);
  w.colliders.push({minX:x-.62,maxX:x+.62,minZ:z-.31,maxZ:z+.31,secondShopPC:true});
  w.addInteractable({id:'second-shop-manager',label:{tr:'💻 İkinci market bilgisayarı',en:'💻 Second supermarket computer',az:'💻 İkinci market kompüteri',ru:'💻 Компьютер супермаркета'},box:[1.35,1.75,1.0,x,.1,z+.28],action:open});
  // Low-cost 3D inventory: one instanced body, label and (for bottles) cap per fixture.
  // Quantity controls instance count, so the 3D shelf always matches its recorded stock.
  shelfVisual=(()=>{
    const scene=new T.Group();scene.name='İKİNCİ MARKET STOK MODELLERİ';w.scene.add(scene);
    const counts={},meshes={};
    for(const f of shelfSpecs){
      const bottle=f.product==='water'||f.product==='milk';
      const bodyGeo=bottle?new T.CylinderGeometry(.09,.10,.32,8):new T.BoxGeometry(.25,.32,.16);
      const labelGeo=new T.BoxGeometry(.18,.09,.015),capGeo=new T.CylinderGeometry(.045,.045,.05,8);
      const mk=(geo,color)=>{const m=new T.InstancedMesh(geo,new T.MeshLambertMaterial({color}),MAX_SHELF);m.castShadow=false;m.receiveShadow=false;m.frustumCulled=false;scene.add(m);return m;};
      const body=mk(bodyGeo,f.color),label=mk(labelGeo,0xf8f5e9),cap=bottle?mk(capGeo,0x3978a2):null;
      const dummy=new T.Object3D();
      for(let i=0;i<MAX_SHELF;i++){
        const col=i%4,row=Math.floor(i/4),x=48.3+col*2.2,y=(f.id==='fridge-milk'?.4:.44)+row*(f.id==='fridge-milk'?.62:.55),z=f.z;
        dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);dummy.position.set(x,y+.16,z);dummy.updateMatrix();body.setMatrixAt(i,dummy.matrix);
        dummy.position.set(x,y+.16,z+(f.z===72.44||f.z===75.64?.095:-.095));dummy.updateMatrix();label.setMatrixAt(i,dummy.matrix);
        if(cap){dummy.position.set(x,y+.35,z);dummy.updateMatrix();cap.setMatrixAt(i,dummy.matrix);}
      }
      for(const m of [body,label,cap])if(m)m.instanceMatrix.needsUpdate=true;
      meshes[f.id]=[body,label,cap].filter(Boolean);
    }
    return {counts,update(){for(const f of st.fixtures){counts[f.id]=f.qty;for(const m of meshes[f.id])m.count=f.qty;}}};
  })();shelfVisual.update();
  const prior=w.update.bind(w);w.update=function(dt,...args){const result=prior(dt,...args);step(Math.min(.1,Math.max(0,dt)));return result;};
  window.__ikinciMarket={inspect:()=>({owned:own,staff:{cashier:st.cashier,stocker:st.stocker},products:st.products.map(p=>({...p})),fixtures:st.fixtures.map(f=>({...f,capacity:MAX_SHELF,visual:shelfVisual?.counts[f.id]??null})),wages:{cashier:WAGES.cashier,stocker:WAGES.stocker,payDay:st.payDay,total:st.totalWages},cargo:{...st.cargo},worker:{...workerPos,target:workerTarget,phase:workerPhase,area:workerArea,carrying:cargoTotal()>0},sales:st.sales,shoppers:shoppers.map(c=>({state:c.state,x:c.x,z:c.z,product:c.product||null,price:c.price||null,byCar:c.byCar,targetShelf:c.targetShelf,redirects:c.redirects})),waiting:shoppers.filter(c=>c.state==='waiting').length}),open,receive,refresh:fresh,arriveByCar:()=>spawn(true)};
})();
